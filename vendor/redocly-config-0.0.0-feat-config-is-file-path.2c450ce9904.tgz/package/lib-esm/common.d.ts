export declare const colorSchema: {
    readonly type: 'string';
    readonly uiHint: 'color';
};
export declare const ruleTypes: readonly ['rules', 'oas2Rules', 'oas3_0Rules', 'oas3_1Rules', 'oas3_2Rules', 'async2Rules', 'async3Rules', 'arazzo1Rules', 'arazzo1_1Rules', 'overlay1Rules', 'openrpc1Rules', 'graphqlRules'];
export type RuleTypes = (typeof ruleTypes)[number];
export declare const preprocessorTypes: readonly ['preprocessors', 'oas2Preprocessors', 'oas3_0Preprocessors', 'oas3_1Preprocessors', 'oas3_2Preprocessors', 'async2Preprocessors', 'async3Preprocessors', 'arazzo1Preprocessors', 'arazzo1_1Preprocessors', 'overlay1Preprocessors', 'openrpc1Preprocessors'];
export type PreprocessorTypes = (typeof preprocessorTypes)[number];
export declare const decoratorTypes: readonly ['decorators', 'oas2Decorators', 'oas3_0Decorators', 'oas3_1Decorators', 'oas3_2Decorators', 'async2Decorators', 'async3Decorators', 'arazzo1Decorators', 'arazzo1_1Decorators', 'overlay1Decorators', 'openrpc1Decorators'];
export type DecoratorTypes = (typeof decoratorTypes)[number];
export declare const configGovernanceSchema: {
    readonly rules: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: {
            readonly oneOf: readonly [{
                readonly type: 'string';
            }, {
                readonly type: 'object';
            }];
        };
        readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
        readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
    };
    readonly oas2Rules: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: {
            readonly oneOf: readonly [{
                readonly type: 'string';
            }, {
                readonly type: 'object';
            }];
        };
        readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
        readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
    };
    readonly oas3_0Rules: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: {
            readonly oneOf: readonly [{
                readonly type: 'string';
            }, {
                readonly type: 'object';
            }];
        };
        readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
        readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
    };
    readonly oas3_1Rules: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: {
            readonly oneOf: readonly [{
                readonly type: 'string';
            }, {
                readonly type: 'object';
            }];
        };
        readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
        readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
    };
    readonly oas3_2Rules: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: {
            readonly oneOf: readonly [{
                readonly type: 'string';
            }, {
                readonly type: 'object';
            }];
        };
        readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
        readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
    };
    readonly async2Rules: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: {
            readonly oneOf: readonly [{
                readonly type: 'string';
            }, {
                readonly type: 'object';
            }];
        };
        readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
        readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
    };
    readonly async3Rules: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: {
            readonly oneOf: readonly [{
                readonly type: 'string';
            }, {
                readonly type: 'object';
            }];
        };
        readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
        readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
    };
    readonly arazzo1Rules: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: {
            readonly oneOf: readonly [{
                readonly type: 'string';
            }, {
                readonly type: 'object';
            }];
        };
        readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
        readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
    };
    readonly arazzo1_1Rules: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: {
            readonly oneOf: readonly [{
                readonly type: 'string';
            }, {
                readonly type: 'object';
            }];
        };
        readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
        readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
    };
    readonly overlay1Rules: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: {
            readonly oneOf: readonly [{
                readonly type: 'string';
            }, {
                readonly type: 'object';
            }];
        };
        readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
        readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
    };
    readonly openrpc1Rules: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: {
            readonly oneOf: readonly [{
                readonly type: 'string';
            }, {
                readonly type: 'object';
            }];
        };
        readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
        readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
    };
    readonly graphqlRules: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: {
            readonly oneOf: readonly [{
                readonly type: 'string';
            }, {
                readonly type: 'object';
            }];
        };
        readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
        readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
    };
    readonly preprocessors: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly oas2Preprocessors: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly oas3_0Preprocessors: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly oas3_1Preprocessors: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly oas3_2Preprocessors: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly async2Preprocessors: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly async3Preprocessors: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly arazzo1Preprocessors: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly arazzo1_1Preprocessors: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly overlay1Preprocessors: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly openrpc1Preprocessors: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly decorators: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly oas2Decorators: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly oas3_0Decorators: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly oas3_1Decorators: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly oas3_2Decorators: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly async2Decorators: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly async3Decorators: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly arazzo1Decorators: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly arazzo1_1Decorators: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly overlay1Decorators: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly openrpc1Decorators: {
        readonly nodeTypeName: undefined;
        readonly type: 'object';
        readonly additionalProperties: true;
    };
    readonly extends: {
        readonly nodeTypeName: undefined;
        readonly type: 'array';
        readonly items: {
            readonly type: 'string';
        };
        readonly description: 'Use extends to inherit rules and their configurations from other rulesets.';
        readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/extends';
    };
};
