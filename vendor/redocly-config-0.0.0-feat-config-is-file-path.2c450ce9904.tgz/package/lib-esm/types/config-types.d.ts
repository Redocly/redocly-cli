import type { FromSchema } from 'json-schema-to-ts';
import type { themeConfigSchema } from '../default-theme-config-schema.js';
import type { productConfigOverrideSchema } from '../product-override-schema.js';
import type { apiConfigSchema, apigeeAdapterAuthOauth2Schema, apigeeAdapterAuthServiceAccountSchema, apigeeEdgeAdapterConfigSchema, apigeeXAdapterConfigSchema, authProviderConfigSchema, devOnboardingAdapterConfigSchema, graviteeAdapterConfigSchema, l10nConfigSchema, oidcIssuerMetadataSchema, oidcProviderConfigSchema, rbacConfigSchema, rbacScopeItemsSchema, redirectConfigSchema, redirectsConfigSchema, rootRedoclyConfigSchema, skillsConfigSchema, bannerConfigSchema, bannersConfigSchema, saml2ProviderConfigSchema, seoConfigSchema, ssoDirectConfigSchema } from '../root-config-schema.js';
import type { RedocConfigTypes } from './redoc-types.js';
import type { GraphQLConfigTypes } from './graphql-types.js';
import type { productConfigSchema, productGoogleAnalyticsConfigSchema, markdownConfigSchema, amplitudeAnalyticsConfigSchema, rudderstackAnalyticsConfigSchema, segmentAnalyticsConfigSchema, gtmAnalyticsConfigSchema, googleAnalyticsConfigSchema, consentConfigSchema, scorecardConfigSchema, catalogFilterSchema, catalogSchema, searchFacetsConfigSchema } from '../ex-theme-config-schemas.js';
import type { scorecardsConfigSchema } from '../scorecards-config-schema.js';
import type { recheckConfigSchema, recheckMarkdocSchema, recheckRuleSchema } from '../recheck-config-schema.js';
import type { agentConfigSchema, reuniteConfigSchema, mcpServersConfigSchema } from '../reunite-config-schema.js';
import type { optionalEmailSettings, reasonsSettings } from '../feedback-config-schema.js';
import type { AsyncApiConfigTypes } from './asyncapi-types.js';
/**
 * @deprecated left for backwards compatibility. To be removed in Realm 1.0
 */
export type ThemeConfig = Omit<FromSchema<typeof themeConfigSchema>, 'openapi'> & {
    openapi?: RedocConfigTypes;
};
export type RedocConfig = RedocConfigTypes;
export type GraphQLConfig = GraphQLConfigTypes;
export type AsyncApiConfig = AsyncApiConfigTypes;
export type ProductConfig = FromSchema<typeof productConfigSchema>;
export type AgentConfigFile = FromSchema<typeof agentConfigSchema>;
export type ProductGoogleAnalyticsConfig = FromSchema<typeof productGoogleAnalyticsConfigSchema>;
export type MarkdownConfig = FromSchema<typeof markdownConfigSchema>;
export type AmplitudeAnalyticsConfig = FromSchema<typeof amplitudeAnalyticsConfigSchema>;
export type RudderstackAnalyticsConfig = FromSchema<typeof rudderstackAnalyticsConfigSchema>;
export type SegmentAnalyticsConfig = FromSchema<typeof segmentAnalyticsConfigSchema>;
export type GtmAnalyticsConfig = FromSchema<typeof gtmAnalyticsConfigSchema>;
export type GoogleAnalyticsConfig = FromSchema<typeof googleAnalyticsConfigSchema>;
export type ConsentConfig = FromSchema<typeof consentConfigSchema>;
export type CatalogConfig = FromSchema<typeof catalogSchema>;
export type CatalogFilterConfig = FromSchema<typeof catalogFilterSchema>;
export type ReuniteConfig = FromSchema<typeof reuniteConfigSchema>;
export type ScorecardConfig = FromSchema<typeof scorecardConfigSchema>;
export type ScorecardsConfig = FromSchema<typeof scorecardsConfigSchema>;
export type RecheckConfig = FromSchema<typeof recheckConfigSchema>;
export type RecheckRuleConfig = FromSchema<typeof recheckRuleSchema>;
export type RecheckMarkdocConfig = FromSchema<typeof recheckMarkdocSchema>;
export type SearchFacetsConfig = FromSchema<typeof searchFacetsConfigSchema>;
export type SkillsConfig = FromSchema<typeof skillsConfigSchema>;
export type McpServersConfig = FromSchema<typeof mcpServersConfigSchema>;
type RootRedoclyConfig = FromSchema<typeof rootRedoclyConfigSchema>;
export type RedoclyConfig = Omit<RootRedoclyConfig, 'theme' | 'apis' | 'rbac' | 'requiresLogin' | 'sso' | 'idps' | 'residency' | 'logoutReturnUrl'> & {
    /**
     * @deprecated Should use `access.rbac` instead
     */
    rbac?: RootRedoclyConfig['rbac'];
    /**
     * @deprecated Should use `access.requiresLogin` instead
     */
    requiresLogin?: RootRedoclyConfig['requiresLogin'];
    /**
     * @deprecated Should use `access.sso` instead
     */
    sso?: RootRedoclyConfig['sso'];
    /**
     * @deprecated Should use `access.idps` instead
     */
    idps?: RootRedoclyConfig['idps'];
    /**
     * @deprecated Should use `access.residency` instead
     */
    residency?: RootRedoclyConfig['residency'];
    /**
     * @deprecated Should use `access.logoutReturnUrl` instead
     */
    logoutReturnUrl?: RootRedoclyConfig['logoutReturnUrl'];
    /**
     * @deprecated properties moved to the root of the config
     */
    theme?: any;
    apis?: Record<string, ApiConfig>;
};
export type RedirectConfig = FromSchema<typeof redirectConfigSchema>;
export type RedirectsConfig = FromSchema<typeof redirectsConfigSchema>;
export type BannerConfig = FromSchema<typeof bannerConfigSchema>;
export type BannersConfig = FromSchema<typeof bannersConfigSchema>;
export type AuthProviderConfig = FromSchema<typeof authProviderConfigSchema>;
export type OidcProviderConfig = FromSchema<typeof oidcProviderConfigSchema>;
export type Saml2ProviderConfig = FromSchema<typeof saml2ProviderConfigSchema>;
export type SeoConfig = FromSchema<typeof seoConfigSchema>;
export type RbacConfig = FromSchema<typeof rbacConfigSchema>;
export type RbacScopeItems = FromSchema<typeof rbacScopeItemsSchema>;
export type OidcIssuerMetadata = FromSchema<typeof oidcIssuerMetadataSchema>;
export type DevOnboardingAdapterConfig = FromSchema<typeof devOnboardingAdapterConfigSchema>;
export type GraviteeAdapterConfig = FromSchema<typeof graviteeAdapterConfigSchema>;
export type ApigeeAdapterConfig = FromSchema<typeof apigeeXAdapterConfigSchema | typeof apigeeEdgeAdapterConfigSchema>;
export type ApigeeAdapterAuthOauth2 = FromSchema<typeof apigeeAdapterAuthOauth2Schema>;
export type ApigeeAdapterAuthServiceAccount = FromSchema<typeof apigeeAdapterAuthServiceAccountSchema>;
export type SsoConfig = FromSchema<typeof ssoDirectConfigSchema>;
export type L10nConfig = FromSchema<typeof l10nConfigSchema>;
type BasicApiConfig = FromSchema<typeof apiConfigSchema>;
export type ApiConfig = BasicApiConfig & {
    /**
     * @deprecated left for backwards compatibility
     */
    theme?: {
        openapi?: RedocConfig;
        graphql?: GraphQLConfig;
    };
};
export type ProductConfigOverride = FromSchema<typeof productConfigOverrideSchema>;
export type ReasonsSettingsSchema = FromSchema<typeof reasonsSettings>;
export type OptionalEmailSettings = FromSchema<typeof optionalEmailSettings>;
export {};
