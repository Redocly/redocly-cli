import type { RedoclyConfig } from './config-types.js';
import type { PageStaticData } from './portal-shared-types.js';
export type ServerPropsRequest = {
    raw: Request;
    headers: Record<string, any>;
    params: Record<string, any>;
    query: Record<string, any>;
    cookies: Record<string, any>;
    body: ReadableStream<Uint8Array> | null;
};
export type ApiFunctionsContextMethods = {
    status: (code: number) => ApiFunctionsContextMethods;
    setCookie: (name: string, value: string, options?: CookieOptions) => ApiFunctionsContextMethods;
    deleteCookie: (name: string) => ApiFunctionsContextMethods;
    json: (data: object) => Response;
    text: (data: string, code?: number) => Response;
    redirect: (url: string, code?: number) => Response;
};
export type ApiFunctionsUser = {
    teams: string[];
    claims: Record<string, any>;
    email: string | undefined;
    idpAccessToken: string | undefined;
    idpId: string | undefined;
    isAuthenticated: boolean;
};
export type ApiFunctionsContext = {
    user: ApiFunctionsUser;
    config: RedoclyConfig;
    outdir?: string;
    baseUrl?: string;
    params: Record<string, string | string[]>;
    query: Record<string, string | string[]>;
    cookies: Record<string, string>;
    getKv: () => Promise<KvService>;
    /**
     * @deprecated `telemetry` is deprecated.
     */
    telemetry?: {
        sendCustomMessage: (data: {
            name: string;
        } & Record<string, string | number>) => void;
    };
} & ApiFunctionsContextMethods;
export type KvService = {
    get: <T extends KvValue = KvValue>(key: KvKey) => Promise<T | null>;
    getMany: <T extends KvValue = KvValue>(keys: KvKey[]) => Promise<(KvListEntry<T> | null)[]>;
    list: <T extends KvValue = KvValue>(selector: KvListSelector, options?: KvListOptions) => Promise<KvListResponse<T>>;
    set: <T extends KvValue = KvValue>(key: KvKey, value: T, options?: KvSetOptions) => Promise<KvListEntry<T> | null>;
    delete: (key: KvKey) => Promise<void>;
    transaction: <T>(operation: (tx: KvTransaction) => Promise<T>) => Promise<T>;
};
export type KvValue = Record<string, unknown> | unknown[] | unknown;
export type KvKeyPart = string | number | boolean;
export type KvKey = KvKeyPart[];
export type KvSetOptions = {
    ttlInSeconds?: number;
};
export type KvListEntry<T extends KvValue = KvValue> = {
    key: KvKey;
    value: T | null;
};
export type KvListSelector = {
    prefix: KvKey;
} | {
    prefix: KvKey;
    start: KvKey;
} | {
    prefix: KvKey;
    end: KvKey;
} | {
    start: KvKey;
    end: KvKey;
};
export type KvListOptions = {
    limit?: number;
    reverse?: boolean;
    cursor?: string;
};
export type KvListResponse<T extends KvValue = KvValue> = {
    items: KvListEntry<T>[];
    total: number;
    cursor: string | null;
};
export type KvTransaction = {
    get: <T extends KvValue = KvValue>(key: KvKey) => Promise<T | null>;
    getMany: <T extends KvValue = KvValue>(keys: KvKey[]) => Promise<(KvListEntry<T> | null)[]>;
    set: <T extends KvValue = KvValue>(key: KvKey, value: T, options?: KvSetOptions) => Promise<KvListEntry<T> | null>;
    delete: (key: KvKey) => Promise<void>;
};
export type ApiRoutesHandler = (request: Request, context: ApiFunctionsContext, 
/**
 * @deprecated `staticData` is deprecated.
 */
staticData: PageStaticData) => Promise<Response>;
export interface CookieOptions {
    domain?: string;
    expires?: Date;
    httpOnly?: boolean;
    maxAge?: number;
    path?: string;
    secure?: boolean;
    signed?: boolean;
    sameSite?: 'Strict' | 'Lax' | 'None';
}
export type ServerPropsContext = Omit<ApiFunctionsContext, 'getKv'>;
