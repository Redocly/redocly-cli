import type { JSONSchema } from 'json-schema-to-ts';
import type { ApiFunctionsContext, ApiFunctionsContextMethods } from './api-functions-types.js';
/** A JSON Schema (draft-07) object, as accepted by MCP tool definitions. */
export type McpToolJsonSchema = Exclude<JSONSchema, boolean>;
export type McpToolJsonValue = string | number | boolean | null | McpToolJsonValue[] | {
    [key: string]: McpToolJsonValue;
};
/** Structurally compatible with the MCP protocol `CallToolResult`. */
export type McpToolResult = {
    content: Array<{
        type: 'text' | 'image' | 'audio' | 'resource' | 'resource_link';
        text?: string;
        [key: string]: unknown;
    }>;
    structuredContent?: Record<string, unknown>;
    isError?: boolean;
    _meta?: Record<string, unknown>;
};
/** Behavior hints for MCP clients, as defined by the MCP specification. */
export type McpToolAnnotations = {
    title?: string;
    readOnlyHint?: boolean;
    destructiveHint?: boolean;
    idempotentHint?: boolean;
    openWorldHint?: boolean;
};
export type McpToolFileSystem = {
    /**
     * Reads a text file from the built project output (which includes a Markdown
     * twin of every page). A path that escapes the output directory is rejected.
     */
    readFile: (path: string) => Promise<string>;
};
/** Context passed to a custom MCP tool's `execute` and `isAvailable` functions. */
export type McpToolContext = Omit<ApiFunctionsContext, 'telemetry' | 'getKv' | keyof ApiFunctionsContextMethods> & {
    /** Scoped file access to the built project output. */
    fs: McpToolFileSystem;
    /** Product names configured in the project. */
    products?: string[];
    /** Access token of the authenticated MCP connection. */
    accessToken?: string;
    /** Free-form caller metadata, parsed from the `X-Redocly-AI-Metadata` request header. */
    metadata?: Record<string, unknown>;
};
/** MCP protocol metadata passed to a custom MCP tool's `execute` function. */
export type McpToolCallExtra = {
    sessionId?: string;
    requestId: string | number;
    authInfo?: {
        token: string;
        clientId: string;
        scopes: string[];
        expiresAt?: number;
        [key: string]: unknown;
    };
    requestInfo?: {
        headers: Record<string, string | string[] | undefined>;
    };
    _meta?: Record<string, unknown>;
};
/**
 * A custom MCP tool defined by a file in an `@mcp` folder.
 * The file's default export must satisfy this type; the tool name is the file name without extension.
 */
export type McpToolDefinition<TArgs extends Record<string, unknown> = Record<string, unknown>> = {
    /** Human-readable description shown to MCP clients and AI models. */
    description: string;
    /** JSON Schema for the tool's input arguments. Defaults to an empty object schema. */
    inputSchema?: McpToolJsonSchema & {
        type?: 'object';
    };
    outputSchema?: McpToolJsonSchema;
    annotations?: McpToolAnnotations;
    /** Controls whether the tool is advertised to the current MCP connection. */
    isAvailable?: (context: McpToolContext) => boolean | Promise<boolean>;
    /**
     * Runs the tool. A returned string or JSON value is wrapped into an MCP
     * result automatically; throw an `Error` to report a failure.
     */
    execute: (args: TArgs, context: McpToolContext, extra: McpToolCallExtra) => McpToolResult | McpToolJsonValue | Promise<McpToolResult | McpToolJsonValue>;
};
