import type { FromSchema } from 'json-schema-to-ts';
import type { ComponentType } from 'react';
import type { graphqlConfigSchema } from '../graphql-config-schema.js';
import type { Schema, ConfigFunction } from '@markdoc/markdoc/dist/src/types.js';
export type GraphQLConfigTypes = FromSchema<typeof graphqlConfigSchema> & {
    markdocOptions?: {
        tags: Record<string, Schema>;
        nodes: Record<string, Schema>;
        components: Record<string, ComponentType>;
        variables?: Record<string, any>;
        partials?: Record<string, any>;
        functions?: Record<string, ConfigFunction>;
    };
    markdown?: {
        parser?: (md: string) => string;
        highlight?: (code: string, lang: string, options?: Record<string, any>) => string;
    };
};
