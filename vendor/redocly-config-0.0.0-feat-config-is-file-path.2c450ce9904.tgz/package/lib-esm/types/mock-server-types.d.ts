import type { ApiFunctionsContext } from './api-functions-types.js';
export type HttpMethod = 'GET' | 'HEAD' | 'POST' | 'PUT' | 'DELETE' | 'CONNECT' | 'OPTIONS' | 'TRACE' | 'PATCH';
export interface MockSnippetRequest {
    readonly method: HttpMethod;
    readonly path: string;
    readonly params: Record<string, unknown>;
    readonly query: Record<string, unknown>;
    readonly headers: Record<string, string>;
    readonly body?: unknown;
}
export interface MockSnippetState {
    get<T>(resource: string, id: string | number): Promise<T | null>;
    list<T>(resource: string): Promise<T[]>;
    set<T>(resource: string, id: string | number, value: T): Promise<void>;
    delete(resource: string, id: string | number): Promise<void>;
}
export interface MockSnippetContext {
    request: MockSnippetRequest;
    state: MockSnippetState;
}
export interface MockSnippetResult {
    status: number;
    headers?: Record<string, string>;
    body?: unknown;
}
export interface MockJsExecutorOptions {
    timeoutMs?: number;
    maxLifetimeMs?: number;
}
export interface MockJsExecutor {
    run(snippet: string, context: MockSnippetContext, opts?: MockJsExecutorOptions): Promise<MockSnippetResult>;
}
export type MockKey = (string | number)[];
export interface MockStateSetOptions {
    ttlSeconds?: number;
}
export interface MockStateListOptions {
    limit?: number;
    cursor?: string;
}
export interface MockStateListItem<T> {
    key: MockKey;
    value: T;
}
export interface MockStateListResult<T> {
    items: MockStateListItem<T>[];
    total?: number;
    cursor: string | null;
}
export interface MockStateStore {
    get<T>(key: MockKey): Promise<T | null>;
    set<T>(key: MockKey, value: T, opts?: MockStateSetOptions): Promise<void>;
    delete(key: MockKey): Promise<void>;
    list<T>(prefix: MockKey, opts?: MockStateListOptions): Promise<MockStateListResult<T>>;
}
export type MockServerRouteContext = ApiFunctionsContext & {
    executor?: MockJsExecutor;
    store?: MockStateStore;
};
