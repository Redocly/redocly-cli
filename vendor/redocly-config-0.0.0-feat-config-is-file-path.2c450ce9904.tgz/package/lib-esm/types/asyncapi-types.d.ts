import type { ComponentType } from 'react';
import type { FromSchema } from 'json-schema-to-ts';
import type { Schema, ConfigFunction } from '@markdoc/markdoc/dist/src/types';
import type { asyncapiConfigSchema } from '../asyncapi-config-schema.js';
export type AsyncApiConfigTypes = FromSchema<typeof asyncapiConfigSchema> & {
    markdocOptions?: {
        tags: Record<string, Schema>;
        nodes: Record<string, Schema>;
        components: Record<string, ComponentType>;
        variables?: Record<string, any>;
        partials?: Record<string, any>;
        functions?: Record<string, ConfigFunction>;
    };
};
