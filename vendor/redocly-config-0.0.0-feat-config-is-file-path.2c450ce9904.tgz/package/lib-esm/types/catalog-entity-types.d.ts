import type { FromSchema } from 'json-schema-to-ts';
import type { entityCatalogEntityTypeSchema, entityCatalogSpecificCatalogSchema } from '../entities-catalog-config-schema.js';
import type { apiDescriptionMetadataSchema, apiOperationMetadataSchema, dataSchemaMetadataSchema, defaultMetadataSchema, entityContactFileSchema, entityLinkFileSchema, entityRelationFileSchema, slackChannelFileSchema, slackContactFileSchema, userMetadataSchema } from '../entities-catalog-entity-file-schema.js';
export type EntityCatalogSpecificCatalogConfig = FromSchema<typeof entityCatalogSpecificCatalogSchema>;
export type EntityCatalogEntityTypeConfig = FromSchema<typeof entityCatalogEntityTypeSchema>;
export type CatalogConfigEntityExclude = {
    key: string;
};
export type CatalogConfigEntityInclude = {
    type: string;
};
export type CatalogConfigEntityFilter = {
    title: string;
    titleTranslationKey?: string;
    parentFilter?: string;
    valuesMapping?: Record<string, string>;
    missingCategoryName?: string;
    missingCategoryNameTranslationKey?: string;
    property: string;
    type?: 'select' | 'checkboxes' | 'date-range';
    options?: string[];
    hide?: boolean;
    label?: string;
};
export type CatalogEntityConfig = {
    slug?: string;
    hide?: boolean;
    excludes?: CatalogConfigEntityExclude[];
    includes?: CatalogConfigEntityInclude[];
    filters?: CatalogConfigEntityFilter[];
    titleTranslationKey?: string;
    descriptionTranslationKey?: string;
    catalogSwitcherLabelTranslationKey?: string;
};
export type EntitiesCatalogConfig = {
    show?: boolean;
    catalogs?: {
        all?: EntityCatalogSpecificCatalogConfig;
        services?: EntityCatalogSpecificCatalogConfig;
        domains?: EntityCatalogSpecificCatalogConfig;
        teams?: EntityCatalogSpecificCatalogConfig;
        users?: EntityCatalogSpecificCatalogConfig;
        apiDescriptions?: EntityCatalogSpecificCatalogConfig;
        dataSchemas?: EntityCatalogSpecificCatalogConfig;
        apiOperations?: EntityCatalogSpecificCatalogConfig;
        [catalogName: string]: EntityCatalogSpecificCatalogConfig | undefined;
    };
    entityTypes?: Record<string, EntityCatalogEntityTypeConfig>;
};
export type SlackChannelFileSchema = FromSchema<typeof slackChannelFileSchema>;
export type SlackContactFileSchema = FromSchema<typeof slackContactFileSchema>;
export type EntityContactFileSchema = FromSchema<typeof entityContactFileSchema>;
export type EntityLinkFileSchema = FromSchema<typeof entityLinkFileSchema>;
export type EntityRelationFileSchema = FromSchema<typeof entityRelationFileSchema>;
export type EntityBaseFileSchema = {
    type: string;
    version?: string | null;
    key: string;
    title: string;
    summary?: string | null;
    tags?: string[] | null;
    git?: string[] | null;
    contact?: EntityContactFileSchema | null;
    links?: EntityLinkFileSchema[] | null;
    relations?: EntityRelationFileSchema[] | null;
    metadata?: DefaultMetadataSchema | null;
};
export type EntityFileSchema = (Omit<EntityBaseFileSchema, 'type'> & {
    type: 'user';
    metadata: UserMetadataSchema;
}) | (Omit<EntityBaseFileSchema, 'type'> & {
    type: 'api-description';
    metadata: ApiDescriptionMetadataSchema;
}) | (Omit<EntityBaseFileSchema, 'type'> & {
    type: 'api-operation';
    metadata: ApiOperationMetadataSchema;
}) | (Omit<EntityBaseFileSchema, 'type'> & {
    type: 'data-schema';
    metadata: DataSchemaMetadataSchema;
}) | (Omit<EntityBaseFileSchema, 'type'> & {
    type: 'service' | 'domain' | 'team';
});
export type UserMetadataSchema = FromSchema<typeof userMetadataSchema>;
export type ApiDescriptionMetadataSchema = FromSchema<typeof apiDescriptionMetadataSchema>;
export type ApiOperationMetadataSchema = FromSchema<typeof apiOperationMetadataSchema>;
export type DataSchemaMetadataSchema = FromSchema<typeof dataSchemaMetadataSchema>;
export type DefaultMetadataSchema = FromSchema<typeof defaultMetadataSchema>;
