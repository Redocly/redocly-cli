import type { Node } from '@markdoc/markdoc';
import type { FromSchema } from 'json-schema-to-ts';
import type { LayoutVariant, REDOCLY_ROUTE_RBAC, REDOCLY_TEAMS_RBAC } from '../constants/shared.js';
import type { ProductConfig, ProductGoogleAnalyticsConfig, RbacScopeItems, RedoclyConfig, SeoConfig, BannerConfig } from './config-types.js';
import type { CatalogEntityConfig } from './catalog-entity-types.js';
import type { searchConfigSchema } from '../ex-theme-config-schemas.js';
export * from './code-walkthrough-types.js';
export type UiAccessibleConfig = Pick<RedoclyConfig, 'logo' | 'navbar' | 'products' | 'footer' | 'sidebar' | 'scripts' | 'links' | 'feedback' | 'search' | 'aiAssistant' | 'colorMode' | 'palette' | 'navigation' | 'codeSnippet' | 'markdown' | 'openapi' | 'graphql' | 'analytics' | 'consent' | 'userMenu' | 'versionPicker' | 'breadcrumbs' | 'catalog' | 'scorecard' | 'scorecards' | 'scorecardClassic' | 'entitiesCatalog' | 'mcp'> & {
    auth?: {
        idpsInfo?: {
            idpId: string;
            type: string;
            title: string | undefined;
        }[];
        devLogin?: boolean;
    };
    breadcrumbs?: {
        prefixItems?: ResolvedNavLinkItem[];
    };
    products?: {
        [key: string]: ProductUiConfig;
    };
    banner?: ResolvedBannerConfig[];
};
/**
 * @deprecated left for backwards compatibility. To be removed in Realm 1.0
 */
export type ThemeUIConfig = UiAccessibleConfig;
export type ResolvedNavLinkItem = {
    type: 'link';
    fsPath?: string;
    metadata?: Record<string, unknown>;
    link: string;
    label: string;
    labelTranslationKey?: string;
    items?: ResolvedNavItem[];
    sidebar?: ResolvedNavItem[];
    external?: boolean;
    target?: '_self' | '_blank';
    version?: string;
    isDefault?: boolean;
    versionFolderId?: string;
    badges?: ItemBadge[];
    httpVerb?: string;
    separatorLine?: boolean;
    linePosition?: 'top' | 'bottom';
    routeSlug?: string;
    active?: boolean;
    deprecated?: boolean;
    isAdditionalOperation?: boolean;
    icon?: string;
    srcSet?: string;
    [REDOCLY_TEAMS_RBAC]?: RbacScopeItems;
    [REDOCLY_ROUTE_RBAC]?: {
        slug?: string;
        fsPath?: string;
    };
    linkedSidebars?: string[];
    languageInsensitive?: boolean;
    additionalProps?: Record<string, unknown>;
};
export type ItemBadge = {
    name: string;
    color?: string;
    position?: 'before' | 'after';
    icon?: string;
};
export type ResolvedNavGroupItem = {
    type: 'group';
    fsPath?: string;
    metadata?: Record<string, unknown>;
    link?: string;
    label?: string;
    labelTranslationKey?: string;
    items?: ResolvedNavItem[];
    sidebar?: ResolvedNavItem[];
    external?: boolean;
    target?: '_self' | '_blank';
    expanded?: string;
    selectFirstItemOnExpand?: boolean;
    version?: string;
    isDefault?: boolean;
    versionFolderId?: string;
    menuStyle?: MenuStyle;
    separatorLine?: boolean;
    linePosition?: 'top' | 'bottom';
    routeSlug?: string;
    badges?: ItemBadge[];
    active?: boolean;
    icon?: string;
    srcSet?: string;
    [REDOCLY_TEAMS_RBAC]?: RbacScopeItems;
    [REDOCLY_ROUTE_RBAC]?: {
        slug?: string;
        fsPath?: string;
    };
    linkedSidebars?: string[];
    languageInsensitive?: boolean;
    additionalProps?: Record<string, unknown>;
};
export type ResolvedNavItem = ResolvedNavLinkItem | ResolvedNavGroupItem | {
    type: 'separator';
    fsPath?: never;
    metadata?: Record<string, unknown>;
    label?: string;
    labelTranslationKey?: string;
    routeSlug?: never;
    version?: string;
    isDefault?: boolean;
    versionFolderId?: string;
    variant?: 'primary' | 'secondary';
    hideWhenEmpty?: boolean;
    separatorLine?: boolean;
    linePosition?: 'top' | 'bottom';
    link?: undefined;
    items?: ResolvedNavItem[];
    sidebar?: ResolvedNavItem[];
    linkedSidebars?: string[];
    icon?: string;
    external?: boolean;
    srcSet?: string;
    languageInsensitive?: boolean;
    additionalProps?: Record<string, unknown>;
    [REDOCLY_TEAMS_RBAC]?: RbacScopeItems;
    [REDOCLY_ROUTE_RBAC]?: {
        slug?: string;
        fsPath?: string;
    };
} | {
    type: 'error';
    fsPath?: never;
    version?: string;
    isDefault?: boolean;
    versionFolderId?: string;
    metadata?: Record<string, unknown>;
    routeSlug?: never;
    label: string;
    labelTranslationKey?: string;
    link?: undefined;
    items?: ResolvedNavItem[];
    sidebar?: ResolvedNavItem[];
    linkedSidebars?: string[];
    icon?: string;
    srcSet?: string;
    languageInsensitive?: boolean;
    [REDOCLY_TEAMS_RBAC]?: RbacScopeItems;
    [REDOCLY_ROUTE_RBAC]?: {
        slug?: string;
        fsPath?: string;
    };
};
export type ResolvedNavItemWithLink = (ResolvedNavLinkItem | ResolvedNavGroupItem) & {
    link: string;
};
export type ResolvedTabMenuEntry = ResolvedNavLinkItem & {
    tabId: string;
    link: string;
    items: ResolvedNavItem[];
};
export type ResolvedTab = {
    type: 'tab';
    tabId: string;
    label: string;
    labelTranslationKey?: string;
    link?: string;
    routeSlug?: string;
    fsPath?: string;
    icon?: string;
    srcSet?: string;
    items?: ResolvedNavItem[];
    menu?: ResolvedTabMenuEntry[];
    version?: string;
    isDefault?: boolean;
    versionFolderId?: string;
    [REDOCLY_TEAMS_RBAC]?: RbacScopeItems;
    [REDOCLY_ROUTE_RBAC]?: {
        slug?: string;
        fsPath?: string;
    };
};
export type ResolvedSidebar = {
    relatedNavbarItem?: BreadcrumbItem;
    items: ResolvedNavItem[];
    tabs?: ResolvedTab[];
    catalogEntity?: {
        key: string;
        version?: string;
        catalogConfig?: CatalogEntityConfig;
    };
};
export type ResolvedBannerConfig = Omit<BannerConfig, 'content'> & {
    ast: unknown;
    hash: string;
};
export type CompilationError = {
    message: string;
    sourceFileRelativePath: string;
    sourceFileLocation: {
        line: number;
        character?: number;
    };
    codeframe: string;
};
export type PageProps = {
    metadata?: Record<string, unknown>;
    seo?: SeoConfig;
    sharedDataIds?: Record<string, string>;
    frontmatter?: Omit<PageProps, 'frontmatter'> & {
        settings?: any;
    } & Partial<UiAccessibleConfig> & {
        navigation?: Partial<UiAccessibleConfig['navigation']> & {
            nextButton?: {
                link?: string;
                label?: string;
            };
            previousButton?: {
                link?: string;
                label?: string;
            };
        };
    };
    disableAutoScroll?: boolean;
    lastModified?: string | null;
    [k: string]: unknown;
    pagePropGetterError?: {
        message: string;
        name: string;
        stack?: string;
    };
    dynamicMarkdocComponents?: string[];
    compilationErrors?: CompilationError[];
    markdown?: MdOptions;
    apiOptions?: APIOptions;
    definitionId?: string;
    variables?: {
        lang?: string;
        rbac?: {
            teams: string[];
        };
    };
};
export interface MdOptions {
    partials: Record<string, Node>;
    variables?: Record<string, any>;
}
export interface PageStaticData {
    props?: PageProps;
    [k: string]: unknown;
}
export type UserData = {
    isAuthenticated: boolean;
    id?: string;
    sub?: string;
    name: string;
    email?: string;
    picture: string;
    logoutDisabled?: boolean;
    teams?: string[];
};
export interface PageData {
    templateId: string;
    redirectTo?: string;
    slug: string;
    sharedDataIds: Record<string, string>;
    props: PageProps;
    versions?: Version[];
    userData: UserData;
    isPublic: boolean;
}
export type NavItem = {
    page?: string;
    directory?: string;
    group?: string;
    groupTranslationKey?: string;
    label?: string;
    labelTranslationKey?: string;
    href?: string;
    items?: NavItem[];
    separator?: string;
    separatorTranslationKey?: string;
    separatorLine?: boolean;
    linePosition?: 'top' | 'bottom';
    version?: string;
    menuStyle?: MenuStyle;
    external?: boolean;
    target?: '_self' | '_blank';
    expanded?: boolean | 'always';
    selectFirstItemOnExpand?: boolean;
    flatten?: boolean;
    icon?: string | {
        srcSet: string;
    };
    rbac?: RbacScopeItems;
    linkedSidebars?: string[];
    $ref?: string;
    disconnect?: boolean;
    additionalProps?: Record<string, unknown>;
    badges?: ItemBadge[];
    tab?: string;
    tabTranslationKey?: string;
    menu?: NavItem[];
};
export interface LogoConfig {
    image?: string;
    srcSet?: string;
    altText?: string;
    link?: string;
    favicon?: string;
}
export type Version = {
    version: string;
    label: string;
    link: string;
    default: boolean;
    active: boolean;
    folderId: string;
    [REDOCLY_TEAMS_RBAC]?: RbacScopeItems;
    [REDOCLY_ROUTE_RBAC]?: {
        slug?: string;
        fsPath?: string;
    };
};
export type VersionConfigItem = {
    version: string;
    name?: string;
};
export type VersionsConfigType = {
    versions: VersionConfigItem[];
    default?: string;
};
export type VersionedFolderConfig = {
    versionedFiles: Map<string, Set<string>>;
    defaultVersion?: string;
    versions: VersionConfigItem[];
    hasVersionsConfig?: boolean;
};
export type NavGroup = ResolvedNavItem[] | undefined | string | boolean | number;
export type NavGroupRecord = Record<string, NavGroup>;
export type ResolvedConfigLinks = NavGroup | NavGroupRecord;
export type RawNavConfigItem = NavItem | NavItem[] | string | undefined | boolean | number;
export type RawNavConfig = RawNavConfigItem | Record<string, RawNavConfigItem>;
export type APIOptions = {
    showRightPanelToggle?: boolean;
    layout?: LayoutVariant;
    collapsedSidebar?: boolean;
};
export type MenuStyle = 'drilldown' | 'drilldown-header';
export type BreadcrumbItem = {
    label: string;
    labelTranslationKey?: string;
    link?: string;
    icon?: string;
};
export type ProductThemeOverrideConfig = Pick<RedoclyConfig, 'logo' | 'navbar' | 'footer' | 'sidebar' | 'search' | 'codeSnippet' | 'breadcrumbs' | 'feedback' | 'palette' | 'mockServer'> & {
    analytics?: {
        ga?: ProductGoogleAnalyticsConfig;
    };
};
export type ProductUiConfig = ProductConfig & {
    slug: string;
    link: string;
    [REDOCLY_TEAMS_RBAC]?: {
        [key: string]: string;
    };
    [REDOCLY_ROUTE_RBAC]?: {
        [key: string]: string;
    };
    configOverride?: ProductThemeOverrideConfig;
};
export type SearchEngineType = NonNullable<FromSchema<typeof searchConfigSchema>['engine']>;
