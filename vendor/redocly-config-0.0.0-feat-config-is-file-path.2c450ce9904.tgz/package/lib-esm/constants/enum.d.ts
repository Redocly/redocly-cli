export declare const createEnum: <T extends { [K in keyof T]: K; }>(obj: T) => T;
