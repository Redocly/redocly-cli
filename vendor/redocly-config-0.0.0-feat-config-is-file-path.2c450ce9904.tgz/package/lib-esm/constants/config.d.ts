export declare const CONFIG_NODE_TYPE_NAMES: {
    readonly RedirectSource: 'RedirectSource';
    readonly Redirects: 'Redirects';
    readonly ScorecardClassic: 'ScorecardClassic';
    readonly ScorecardClassicLevelList: 'ScorecardClassicLevelList';
    readonly ScorecardClassicLevel: 'ScorecardClassicLevel';
    readonly ScorecardClassicTargetList: 'ScorecardClassicTargetList';
    readonly ScorecardClassicTarget: 'ScorecardClassicTarget';
    readonly ScorecardClassicTargetWhere: 'ScorecardClassicTargetWhere';
    readonly ScorecardClassicTargetWhereMetadata: 'ScorecardClassicTargetWhereMetadata';
    readonly ScorecardClassicTeamMetadataProperty: 'ScorecardClassicTeamMetadataProperty';
};
