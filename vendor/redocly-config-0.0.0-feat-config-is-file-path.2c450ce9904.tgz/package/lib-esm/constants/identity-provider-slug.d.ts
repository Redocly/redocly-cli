export declare const IDENTITY_PROVIDER_SLUG_PATTERN = "^[a-z0-9]+(?:-[a-z0-9]+)*$";
export declare const IDENTITY_PROVIDER_SLUG_REGEX: RegExp;
export declare const IDENTITY_PROVIDER_SLUG_MESSAGE = "Unique ID must be lowercase letters, numbers, and hyphens only";
export declare const IDENTITY_PROVIDER_SLUG_MAX_LENGTH = 63;
export declare const IDENTITY_PROVIDER_SLUG_MAX_LENGTH_MESSAGE = "Unique ID cannot exceed 63 characters";
export declare const REDOCLY_IDP_SLUG = "redocly";
export declare const IDENTITY_PROVIDER_RESERVED_SLUGS: readonly ["redocly", 'corporate', 'guest'];
export declare const IDENTITY_PROVIDER_RESERVED_MESSAGE: string;
export declare const SSO_LOGIN_TYPES: readonly ['REDOCLY', 'CORPORATE', 'GUEST'];
