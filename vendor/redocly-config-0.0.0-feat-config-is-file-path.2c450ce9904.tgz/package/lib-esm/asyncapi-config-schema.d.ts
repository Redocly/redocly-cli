export declare const asyncapiConfigSchema: {
    readonly type: 'object';
    readonly properties: {
        readonly downloadUrls: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'object';
                readonly properties: {
                    readonly title: {
                        readonly type: 'string';
                    };
                    readonly url: {
                        readonly type: 'string';
                    };
                };
                readonly required: readonly ["url"];
                readonly additionalProperties: false;
            };
        };
        readonly apiLogo: {
            readonly type: 'object';
            readonly properties: {
                readonly imageUrl: {
                    readonly type: 'string';
                };
                readonly href: {
                    readonly type: 'string';
                };
                readonly altText: {
                    readonly type: 'string';
                };
                readonly backgroundColor: {
                    readonly type: 'string';
                };
            };
        };
        readonly jsonSamplesDepth: {
            readonly type: 'number';
        };
        readonly excludeFromSearch: {
            readonly type: 'boolean';
        };
        readonly samplesMaxInlineArgs: {
            readonly type: 'number';
        };
        readonly fieldExpandLevel: {
            readonly type: 'number';
        };
        readonly baseUrlPath: {
            readonly type: 'string';
        };
        readonly feedback: {
            readonly type: 'object';
            readonly properties: {
                readonly hide: {
                    readonly type: 'boolean';
                };
                readonly type: {
                    readonly type: 'string';
                    readonly enum: readonly ["rating", "sentiment", "comment", "reasons", "mood", "scale"];
                };
                readonly settings: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly label: {
                            readonly type: 'string';
                        };
                        readonly submitText: {
                            readonly type: 'string';
                        };
                        readonly buttonText: {
                            readonly type: 'string';
                        };
                        readonly component: {
                            readonly type: 'string';
                            readonly enum: readonly ["radio", "checkbox"];
                        };
                        readonly items: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'string';
                            };
                            readonly minItems: 1;
                        };
                        readonly leftScaleLabel: {
                            readonly type: 'string';
                        };
                        readonly rightScaleLabel: {
                            readonly type: 'string';
                        };
                        readonly reasons: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly hide: {
                                    readonly type: 'boolean';
                                };
                                readonly component: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["radio", "checkbox"];
                                };
                                readonly label: {
                                    readonly type: 'string';
                                };
                                readonly items: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'string';
                                    };
                                };
                                readonly like: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly component: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["radio", "checkbox"];
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly dislike: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly component: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["radio", "checkbox"];
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly satisfied: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly component: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["radio", "checkbox"];
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly neutral: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly component: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["radio", "checkbox"];
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly dissatisfied: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly component: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["radio", "checkbox"];
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                            };
                            readonly additionalProperties: false;
                        };
                        readonly comment: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly hide: {
                                    readonly type: 'boolean';
                                };
                                readonly label: {
                                    readonly type: 'string';
                                };
                                readonly likeLabel: {
                                    readonly type: 'string';
                                };
                                readonly dislikeLabel: {
                                    readonly type: 'string';
                                };
                                readonly satisfiedLabel: {
                                    readonly type: 'string';
                                };
                                readonly neutralLabel: {
                                    readonly type: 'string';
                                };
                                readonly dissatisfiedLabel: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProperties: false;
                        };
                        readonly optionalEmail: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly hide: {
                                    readonly type: 'boolean';
                                };
                                readonly label: {
                                    readonly type: 'string';
                                };
                                readonly placeholder: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProperties: false;
                        };
                    };
                    readonly additionalProperties: false;
                };
            };
            readonly additionalProperties: false;
        };
        readonly layout: {
            readonly type: 'string';
            readonly enum: readonly ["stacked", "three-panel"];
        };
    };
    readonly additionalProperties: false;
};
