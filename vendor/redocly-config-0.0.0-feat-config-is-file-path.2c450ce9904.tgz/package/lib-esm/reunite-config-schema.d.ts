export declare const mcpServersConfigSchema: {
    readonly type: 'object';
    readonly additionalProperties: {
        readonly type: 'object';
        readonly properties: {
            readonly type: {
                readonly type: 'string';
                readonly enum: readonly ["http"];
            };
            readonly url: {
                readonly type: 'string';
                readonly pattern: '^https?://[^\\s/$.?#].[^\\s]*$';
            };
            readonly description: {
                readonly type: 'string';
            };
            readonly headers: {
                readonly type: 'object';
                readonly additionalProperties: {
                    readonly type: 'string';
                };
            };
        };
        readonly required: readonly ["url"];
        readonly additionalProperties: false;
    };
};
export declare const agentConfigSchema: {
    readonly type: 'object';
    readonly properties: {
        readonly enabled: {
            readonly type: 'boolean';
        };
        readonly defaultReviewers: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'string';
                readonly minLength: 1;
            };
        };
        readonly rules: {
            readonly type: 'object';
            readonly properties: {
                readonly custom: {
                    readonly type: 'string';
                };
                readonly style: {
                    readonly type: 'string';
                };
            };
            readonly additionalProperties: false;
        };
        readonly duties: {
            readonly type: 'array';
            readonly items: {
                readonly oneOf: readonly [{
                    readonly type: 'object';
                    readonly properties: {
                        readonly name: {
                            readonly type: 'string';
                            readonly enum: readonly ["feedback", "discovery", "followUpOnPullRequest", "updateFromCodeChanges"];
                        };
                        readonly enabled: {
                            readonly type: 'boolean';
                        };
                    };
                    readonly required: readonly ["name"];
                    readonly additionalProperties: false;
                }, {
                    readonly type: 'object';
                    readonly properties: {
                        readonly name: {
                            readonly type: 'string';
                            readonly enum: readonly ["review"];
                        };
                        readonly enabled: {
                            readonly type: 'boolean';
                        };
                        readonly rules: {
                            readonly type: 'string';
                        };
                        readonly sourceRepositories: {
                            readonly oneOf: readonly [{
                                readonly type: 'string';
                                readonly enum: readonly ["none", "all"];
                            }, {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly provider: {
                                            readonly type: 'string';
                                            readonly minLength: 1;
                                        };
                                        readonly repository: {
                                            readonly type: 'string';
                                            readonly minLength: 1;
                                        };
                                        readonly branch: {
                                            readonly type: 'string';
                                            readonly minLength: 1;
                                        };
                                        readonly path: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly required: readonly ["provider", "repository"];
                                    readonly additionalProperties: false;
                                };
                            }];
                        };
                        readonly specialists: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'object';
                                readonly properties: {
                                    readonly name: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["config", "apiDescription", "owasp", "docs"];
                                    };
                                    readonly enabled: {
                                        readonly type: 'boolean';
                                    };
                                };
                                readonly required: readonly ["name", "enabled"];
                                readonly additionalProperties: false;
                            };
                        };
                    };
                    readonly required: readonly ["name"];
                    readonly additionalProperties: false;
                }];
            };
        };
        readonly mcpServers: {
            readonly type: 'object';
            readonly additionalProperties: {
                readonly type: 'object';
                readonly properties: {
                    readonly type: {
                        readonly type: 'string';
                        readonly enum: readonly ["http"];
                    };
                    readonly url: {
                        readonly type: 'string';
                        readonly pattern: '^https?://[^\\s/$.?#].[^\\s]*$';
                    };
                    readonly description: {
                        readonly type: 'string';
                    };
                    readonly headers: {
                        readonly type: 'object';
                        readonly additionalProperties: {
                            readonly type: 'string';
                        };
                    };
                };
                readonly required: readonly ["url"];
                readonly additionalProperties: false;
            };
        };
    };
    readonly additionalProperties: false;
};
export declare const reuniteConfigSchema: {
    readonly type: 'object';
    readonly properties: {
        readonly ignoreLint: {
            readonly oneOf: readonly [{
                readonly type: 'boolean';
            }, {
                readonly type: 'object';
                readonly additionalProperties: {
                    readonly type: 'boolean';
                };
            }];
        };
        readonly ignoreLinkChecker: {
            readonly type: 'boolean';
        };
        readonly ignoreMarkdocErrors: {
            readonly type: 'boolean';
        };
        readonly ignoreRespectMonitoring: {
            readonly type: 'boolean';
        };
        readonly jobs: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'object';
                readonly properties: {
                    readonly path: {
                        readonly type: 'string';
                        readonly format: 'uri-reference';
                        readonly pattern: '^(?!\\/|\\.\\./)';
                    };
                    readonly agent: {
                        readonly type: 'string';
                        readonly enum: readonly ["respect"];
                    };
                    readonly trigger: {
                        readonly oneOf: readonly [{
                            readonly type: 'object';
                            readonly properties: {
                                readonly event: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["schedule"];
                                };
                                readonly interval: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["1m", "2m", "5m", "10m", "15m", "30m", "1h", "3h", "6h", "12h", "1d", "7d"];
                                };
                            };
                            readonly required: readonly ["event"];
                            readonly additionalProperties: false;
                        }, {
                            readonly type: 'object';
                            readonly properties: {
                                readonly event: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["build"];
                                };
                            };
                            readonly required: readonly ["event"];
                            readonly additionalProperties: false;
                        }];
                    };
                    readonly inputs: {
                        readonly type: 'object';
                        readonly additionalProperties: {
                            readonly type: 'string';
                        };
                    };
                    readonly servers: {
                        readonly type: 'object';
                        readonly additionalProperties: false;
                        readonly patternProperties: {
                            readonly '^[a-zA-Z0-9_-]+$': {
                                readonly type: 'string';
                                readonly pattern: '^https?://[^\\s/$.?#].[^\\s]*$';
                            };
                        };
                    };
                    readonly severity: {
                        readonly type: 'object';
                        readonly additionalProperties: false;
                        readonly properties: {
                            readonly schemaCheck: {
                                readonly type: 'string';
                                readonly enum: readonly ["error", "warn", "off"];
                            };
                            readonly statusCodeCheck: {
                                readonly type: 'string';
                                readonly enum: readonly ["error", "warn", "off"];
                            };
                            readonly contentTypeCheck: {
                                readonly type: 'string';
                                readonly enum: readonly ["error", "warn", "off"];
                            };
                            readonly successCriteriaCheck: {
                                readonly type: 'string';
                                readonly enum: readonly ["error", "warn", "off"];
                            };
                        };
                    };
                    readonly slo: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly warn: {
                                readonly type: 'number';
                            };
                            readonly error: {
                                readonly type: 'number';
                            };
                        };
                        readonly additionalProperties: false;
                    };
                };
                readonly required: readonly ["path", "trigger", "agent"];
                readonly additionalProperties: false;
            };
        };
        readonly agent: {
            readonly type: 'object';
            readonly properties: {
                readonly enabled: {
                    readonly type: 'boolean';
                };
                readonly defaultReviewers: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                        readonly minLength: 1;
                    };
                };
                readonly rules: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly custom: {
                            readonly type: 'string';
                        };
                        readonly style: {
                            readonly type: 'string';
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly duties: {
                    readonly type: 'array';
                    readonly items: {
                        readonly oneOf: readonly [{
                            readonly type: 'object';
                            readonly properties: {
                                readonly name: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["feedback", "discovery", "followUpOnPullRequest", "updateFromCodeChanges"];
                                };
                                readonly enabled: {
                                    readonly type: 'boolean';
                                };
                            };
                            readonly required: readonly ["name"];
                            readonly additionalProperties: false;
                        }, {
                            readonly type: 'object';
                            readonly properties: {
                                readonly name: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["review"];
                                };
                                readonly enabled: {
                                    readonly type: 'boolean';
                                };
                                readonly rules: {
                                    readonly type: 'string';
                                };
                                readonly sourceRepositories: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                        readonly enum: readonly ["none", "all"];
                                    }, {
                                        readonly type: 'array';
                                        readonly items: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly provider: {
                                                    readonly type: 'string';
                                                    readonly minLength: 1;
                                                };
                                                readonly repository: {
                                                    readonly type: 'string';
                                                    readonly minLength: 1;
                                                };
                                                readonly branch: {
                                                    readonly type: 'string';
                                                    readonly minLength: 1;
                                                };
                                                readonly path: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly required: readonly ["provider", "repository"];
                                            readonly additionalProperties: false;
                                        };
                                    }];
                                };
                                readonly specialists: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly properties: {
                                            readonly name: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["config", "apiDescription", "owasp", "docs"];
                                            };
                                            readonly enabled: {
                                                readonly type: 'boolean';
                                            };
                                        };
                                        readonly required: readonly ["name", "enabled"];
                                        readonly additionalProperties: false;
                                    };
                                };
                            };
                            readonly required: readonly ["name"];
                            readonly additionalProperties: false;
                        }];
                    };
                };
                readonly mcpServers: {
                    readonly type: 'object';
                    readonly additionalProperties: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly type: {
                                readonly type: 'string';
                                readonly enum: readonly ["http"];
                            };
                            readonly url: {
                                readonly type: 'string';
                                readonly pattern: '^https?://[^\\s/$.?#].[^\\s]*$';
                            };
                            readonly description: {
                                readonly type: 'string';
                            };
                            readonly headers: {
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly type: 'string';
                                };
                            };
                        };
                        readonly required: readonly ["url"];
                        readonly additionalProperties: false;
                    };
                };
            };
            readonly additionalProperties: false;
        };
    };
    readonly additionalProperties: false;
};
