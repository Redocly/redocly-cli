export declare const scorecardSchema: {
    readonly type: 'object';
    readonly properties: {
        readonly name: {
            readonly type: 'string';
        };
        readonly key: {
            readonly type: 'string';
        };
        readonly description: {
            readonly type: 'string';
        };
        readonly entities: {
            readonly oneOf: readonly [{
                readonly type: 'array';
                readonly items: {
                    readonly oneOf: readonly [{
                        readonly type: 'object';
                        readonly properties: {
                            readonly field: {
                                readonly type: 'string';
                            };
                            readonly operator: {
                                readonly type: 'string';
                                readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                            };
                            readonly value: {
                                readonly oneOf: readonly [{
                                    readonly type: 'boolean';
                                }, {
                                    readonly type: 'string';
                                }, {
                                    readonly type: 'number';
                                }];
                            };
                            readonly modifier: {
                                readonly type: 'string';
                                readonly enum: readonly ["not"];
                            };
                            readonly match: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly field: {
                                            readonly type: 'string';
                                        };
                                        readonly operator: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                        };
                                        readonly value: {
                                            readonly oneOf: readonly [{
                                                readonly type: 'boolean';
                                            }, {
                                                readonly type: 'string';
                                            }, {
                                                readonly type: 'number';
                                            }];
                                        };
                                        readonly modifier: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["not"];
                                        };
                                    };
                                };
                            };
                        };
                    }, {
                        readonly type: 'object';
                        readonly properties: {
                            readonly operator: {
                                readonly type: 'string';
                                readonly enum: readonly ["and", "or"];
                            };
                            readonly conditions: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'object';
                                        readonly properties: {
                                            readonly field: {
                                                readonly type: 'string';
                                            };
                                            readonly operator: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                            };
                                            readonly value: {
                                                readonly oneOf: readonly [{
                                                    readonly type: 'boolean';
                                                }, {
                                                    readonly type: 'string';
                                                }, {
                                                    readonly type: 'number';
                                                }];
                                            };
                                            readonly modifier: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["not"];
                                            };
                                            readonly match: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly field: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly operator: {
                                                            readonly type: 'string';
                                                            readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                        };
                                                        readonly value: {
                                                            readonly oneOf: readonly [{
                                                                readonly type: 'boolean';
                                                            }, {
                                                                readonly type: 'string';
                                                            }, {
                                                                readonly type: 'number';
                                                            }];
                                                        };
                                                        readonly modifier: {
                                                            readonly type: 'string';
                                                            readonly enum: readonly ["not"];
                                                        };
                                                    };
                                                };
                                            };
                                        };
                                    }, {
                                        readonly type: 'object';
                                        readonly properties: {
                                            readonly operator: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["and", "or"];
                                            };
                                            readonly conditions: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly field: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly operator: {
                                                            readonly type: 'string';
                                                            readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                        };
                                                        readonly value: {
                                                            readonly oneOf: readonly [{
                                                                readonly type: 'boolean';
                                                            }, {
                                                                readonly type: 'string';
                                                            }, {
                                                                readonly type: 'number';
                                                            }];
                                                        };
                                                        readonly modifier: {
                                                            readonly type: 'string';
                                                            readonly enum: readonly ["not"];
                                                        };
                                                        readonly match: {
                                                            readonly type: 'array';
                                                            readonly items: {
                                                                readonly type: 'object';
                                                                readonly properties: {
                                                                    readonly field: {
                                                                        readonly type: 'string';
                                                                    };
                                                                    readonly operator: {
                                                                        readonly type: 'string';
                                                                        readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                    };
                                                                    readonly value: {
                                                                        readonly oneOf: readonly [{
                                                                            readonly type: 'boolean';
                                                                        }, {
                                                                            readonly type: 'string';
                                                                        }, {
                                                                            readonly type: 'number';
                                                                        }];
                                                                    };
                                                                    readonly modifier: {
                                                                        readonly type: 'string';
                                                                        readonly enum: readonly ["not"];
                                                                    };
                                                                };
                                                            };
                                                        };
                                                    };
                                                };
                                            };
                                        };
                                        readonly required: readonly ["operator", "conditions"];
                                        readonly additionalProperties: false;
                                    }];
                                };
                            };
                        };
                        readonly required: readonly ["operator", "conditions"];
                        readonly additionalProperties: false;
                    }];
                };
            }, {
                readonly type: 'object';
                readonly properties: {
                    readonly operator: {
                        readonly type: 'string';
                        readonly enum: readonly ["and", "or"];
                    };
                    readonly conditions: {
                        readonly type: 'array';
                        readonly items: {
                            readonly oneOf: readonly [{
                                readonly type: 'object';
                                readonly properties: {
                                    readonly field: {
                                        readonly type: 'string';
                                    };
                                    readonly operator: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                    };
                                    readonly value: {
                                        readonly oneOf: readonly [{
                                            readonly type: 'boolean';
                                        }, {
                                            readonly type: 'string';
                                        }, {
                                            readonly type: 'number';
                                        }];
                                    };
                                    readonly modifier: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["not"];
                                    };
                                    readonly match: {
                                        readonly type: 'array';
                                        readonly items: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly field: {
                                                    readonly type: 'string';
                                                };
                                                readonly operator: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                };
                                                readonly value: {
                                                    readonly oneOf: readonly [{
                                                        readonly type: 'boolean';
                                                    }, {
                                                        readonly type: 'string';
                                                    }, {
                                                        readonly type: 'number';
                                                    }];
                                                };
                                                readonly modifier: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["not"];
                                                };
                                            };
                                        };
                                    };
                                };
                            }, {
                                readonly type: 'object';
                                readonly properties: {
                                    readonly operator: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["and", "or"];
                                    };
                                    readonly conditions: {
                                        readonly type: 'array';
                                        readonly items: {
                                            readonly oneOf: readonly [{
                                                readonly type: 'object';
                                                readonly properties: {
                                                    readonly field: {
                                                        readonly type: 'string';
                                                    };
                                                    readonly operator: {
                                                        readonly type: 'string';
                                                        readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                    };
                                                    readonly value: {
                                                        readonly oneOf: readonly [{
                                                            readonly type: 'boolean';
                                                        }, {
                                                            readonly type: 'string';
                                                        }, {
                                                            readonly type: 'number';
                                                        }];
                                                    };
                                                    readonly modifier: {
                                                        readonly type: 'string';
                                                        readonly enum: readonly ["not"];
                                                    };
                                                    readonly match: {
                                                        readonly type: 'array';
                                                        readonly items: {
                                                            readonly type: 'object';
                                                            readonly properties: {
                                                                readonly field: {
                                                                    readonly type: 'string';
                                                                };
                                                                readonly operator: {
                                                                    readonly type: 'string';
                                                                    readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                };
                                                                readonly value: {
                                                                    readonly oneOf: readonly [{
                                                                        readonly type: 'boolean';
                                                                    }, {
                                                                        readonly type: 'string';
                                                                    }, {
                                                                        readonly type: 'number';
                                                                    }];
                                                                };
                                                                readonly modifier: {
                                                                    readonly type: 'string';
                                                                    readonly enum: readonly ["not"];
                                                                };
                                                            };
                                                        };
                                                    };
                                                };
                                            }, {
                                                readonly type: 'object';
                                                readonly properties: {
                                                    readonly operator: {
                                                        readonly type: 'string';
                                                        readonly enum: readonly ["and", "or"];
                                                    };
                                                    readonly conditions: {
                                                        readonly type: 'array';
                                                        readonly items: {
                                                            readonly type: 'object';
                                                            readonly properties: {
                                                                readonly field: {
                                                                    readonly type: 'string';
                                                                };
                                                                readonly operator: {
                                                                    readonly type: 'string';
                                                                    readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                };
                                                                readonly value: {
                                                                    readonly oneOf: readonly [{
                                                                        readonly type: 'boolean';
                                                                    }, {
                                                                        readonly type: 'string';
                                                                    }, {
                                                                        readonly type: 'number';
                                                                    }];
                                                                };
                                                                readonly modifier: {
                                                                    readonly type: 'string';
                                                                    readonly enum: readonly ["not"];
                                                                };
                                                                readonly match: {
                                                                    readonly type: 'array';
                                                                    readonly items: {
                                                                        readonly type: 'object';
                                                                        readonly properties: {
                                                                            readonly field: {
                                                                                readonly type: 'string';
                                                                            };
                                                                            readonly operator: {
                                                                                readonly type: 'string';
                                                                                readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                            };
                                                                            readonly value: {
                                                                                readonly oneOf: readonly [{
                                                                                    readonly type: 'boolean';
                                                                                }, {
                                                                                    readonly type: 'string';
                                                                                }, {
                                                                                    readonly type: 'number';
                                                                                }];
                                                                            };
                                                                            readonly modifier: {
                                                                                readonly type: 'string';
                                                                                readonly enum: readonly ["not"];
                                                                            };
                                                                        };
                                                                    };
                                                                };
                                                            };
                                                        };
                                                    };
                                                };
                                                readonly required: readonly ["operator", "conditions"];
                                                readonly additionalProperties: false;
                                            }];
                                        };
                                    };
                                };
                                readonly required: readonly ["operator", "conditions"];
                                readonly additionalProperties: false;
                            }];
                        };
                    };
                };
                readonly required: readonly ["operator", "conditions"];
                readonly additionalProperties: false;
            }];
        };
        readonly levels: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'object';
                readonly properties: {
                    readonly name: {
                        readonly type: 'string';
                    };
                    readonly extends: {
                        readonly nodeTypeName: undefined;
                        readonly type: 'array';
                        readonly items: {
                            readonly type: 'string';
                        };
                        readonly description: 'Use extends to inherit rules and their configurations from other rulesets.';
                        readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/extends';
                    };
                    readonly rules: {
                        readonly type: 'object';
                        readonly additionalProperties: {
                            readonly oneOf: readonly [{
                                readonly type: 'string';
                            }, {
                                readonly type: 'object';
                                readonly properties: {
                                    readonly severity: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["error", "warn", "off"];
                                    };
                                    readonly weight: {
                                        readonly type: 'number';
                                    };
                                };
                                readonly additionalProperties: true;
                            }, {
                                readonly type: 'object';
                                readonly properties: {
                                    readonly title: {
                                        readonly type: 'string';
                                    };
                                    readonly subject: {
                                        readonly type: 'object';
                                        readonly properties: {
                                            readonly type: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["Entity", "EntityMetadata", "EntityRelations", "EntityRelation"];
                                            };
                                            readonly property: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly required: readonly ["type", "property"];
                                        readonly additionalProperties: false;
                                    };
                                    readonly severity: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["error", "warn", "off"];
                                    };
                                    readonly message: {
                                        readonly type: 'string';
                                    };
                                    readonly assertions: {
                                        readonly type: 'object';
                                        readonly properties: {
                                            readonly defined: {
                                                readonly type: 'boolean';
                                            };
                                            readonly nonEmpty: {
                                                readonly type: 'boolean';
                                            };
                                            readonly eq: {
                                                readonly oneOf: readonly [{
                                                    readonly type: 'boolean';
                                                }, {
                                                    readonly type: 'string';
                                                }, {
                                                    readonly type: 'number';
                                                }];
                                            };
                                            readonly gt: {
                                                readonly type: 'number';
                                            };
                                            readonly gte: {
                                                readonly type: 'number';
                                            };
                                            readonly lt: {
                                                readonly type: 'number';
                                            };
                                            readonly lte: {
                                                readonly type: 'number';
                                            };
                                            readonly const: {
                                                readonly oneOf: readonly [{
                                                    readonly type: 'boolean';
                                                }, {
                                                    readonly type: 'string';
                                                }, {
                                                    readonly type: 'number';
                                                }];
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                    readonly where: {
                                        readonly type: 'array';
                                        readonly items: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly subject: {
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly type: {
                                                            readonly type: 'string';
                                                            readonly enum: readonly ["Entity", "EntityMetadata", "EntityRelations", "EntityRelation"];
                                                        };
                                                        readonly property: {
                                                            readonly type: 'string';
                                                        };
                                                    };
                                                    readonly required: readonly ["type", "property"];
                                                    readonly additionalProperties: false;
                                                };
                                                readonly assertions: {
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly defined: {
                                                            readonly type: 'boolean';
                                                        };
                                                        readonly nonEmpty: {
                                                            readonly type: 'boolean';
                                                        };
                                                        readonly eq: {
                                                            readonly oneOf: readonly [{
                                                                readonly type: 'boolean';
                                                            }, {
                                                                readonly type: 'string';
                                                            }, {
                                                                readonly type: 'number';
                                                            }];
                                                        };
                                                        readonly gt: {
                                                            readonly type: 'number';
                                                        };
                                                        readonly gte: {
                                                            readonly type: 'number';
                                                        };
                                                        readonly lt: {
                                                            readonly type: 'number';
                                                        };
                                                        readonly lte: {
                                                            readonly type: 'number';
                                                        };
                                                        readonly const: {
                                                            readonly oneOf: readonly [{
                                                                readonly type: 'boolean';
                                                            }, {
                                                                readonly type: 'string';
                                                            }, {
                                                                readonly type: 'number';
                                                            }];
                                                        };
                                                    };
                                                    readonly additionalProperties: false;
                                                };
                                            };
                                            readonly required: readonly ["subject", "assertions"];
                                            readonly additionalProperties: false;
                                        };
                                    };
                                    readonly weight: {
                                        readonly type: 'number';
                                    };
                                };
                                readonly required: readonly ["subject", "assertions"];
                                readonly additionalProperties: false;
                            }];
                        };
                    };
                };
                readonly required: readonly ["name"];
                readonly additionalProperties: false;
            };
            readonly minItems: 1;
        };
        readonly trigger: {
            readonly oneOf: readonly [{
                readonly type: 'object';
                readonly properties: {
                    readonly event: {
                        readonly type: 'string';
                        readonly enum: readonly ["runtime", "manual"];
                    };
                };
                readonly required: readonly ["event"];
                readonly additionalProperties: false;
            }, {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly event: {
                            readonly type: 'string';
                            readonly enum: readonly ["runtime", "manual"];
                        };
                    };
                    readonly required: readonly ["event"];
                    readonly additionalProperties: false;
                };
            }];
        };
    };
    readonly required: readonly ["name", "key", "entities", "levels"];
    readonly additionalProperties: false;
};
export declare const scorecardsConfigSchema: {
    readonly type: 'array';
    readonly items: {
        readonly type: 'object';
        readonly properties: {
            readonly name: {
                readonly type: 'string';
            };
            readonly key: {
                readonly type: 'string';
            };
            readonly description: {
                readonly type: 'string';
            };
            readonly entities: {
                readonly oneOf: readonly [{
                    readonly type: 'array';
                    readonly items: {
                        readonly oneOf: readonly [{
                            readonly type: 'object';
                            readonly properties: {
                                readonly field: {
                                    readonly type: 'string';
                                };
                                readonly operator: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                };
                                readonly value: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'boolean';
                                    }, {
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'number';
                                    }];
                                };
                                readonly modifier: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["not"];
                                };
                                readonly match: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly properties: {
                                            readonly field: {
                                                readonly type: 'string';
                                            };
                                            readonly operator: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                            };
                                            readonly value: {
                                                readonly oneOf: readonly [{
                                                    readonly type: 'boolean';
                                                }, {
                                                    readonly type: 'string';
                                                }, {
                                                    readonly type: 'number';
                                                }];
                                            };
                                            readonly modifier: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["not"];
                                            };
                                        };
                                    };
                                };
                            };
                        }, {
                            readonly type: 'object';
                            readonly properties: {
                                readonly operator: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["and", "or"];
                                };
                                readonly conditions: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly oneOf: readonly [{
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly field: {
                                                    readonly type: 'string';
                                                };
                                                readonly operator: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                };
                                                readonly value: {
                                                    readonly oneOf: readonly [{
                                                        readonly type: 'boolean';
                                                    }, {
                                                        readonly type: 'string';
                                                    }, {
                                                        readonly type: 'number';
                                                    }];
                                                };
                                                readonly modifier: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["not"];
                                                };
                                                readonly match: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'object';
                                                        readonly properties: {
                                                            readonly field: {
                                                                readonly type: 'string';
                                                            };
                                                            readonly operator: {
                                                                readonly type: 'string';
                                                                readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                            };
                                                            readonly value: {
                                                                readonly oneOf: readonly [{
                                                                    readonly type: 'boolean';
                                                                }, {
                                                                    readonly type: 'string';
                                                                }, {
                                                                    readonly type: 'number';
                                                                }];
                                                            };
                                                            readonly modifier: {
                                                                readonly type: 'string';
                                                                readonly enum: readonly ["not"];
                                                            };
                                                        };
                                                    };
                                                };
                                            };
                                        }, {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly operator: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["and", "or"];
                                                };
                                                readonly conditions: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'object';
                                                        readonly properties: {
                                                            readonly field: {
                                                                readonly type: 'string';
                                                            };
                                                            readonly operator: {
                                                                readonly type: 'string';
                                                                readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                            };
                                                            readonly value: {
                                                                readonly oneOf: readonly [{
                                                                    readonly type: 'boolean';
                                                                }, {
                                                                    readonly type: 'string';
                                                                }, {
                                                                    readonly type: 'number';
                                                                }];
                                                            };
                                                            readonly modifier: {
                                                                readonly type: 'string';
                                                                readonly enum: readonly ["not"];
                                                            };
                                                            readonly match: {
                                                                readonly type: 'array';
                                                                readonly items: {
                                                                    readonly type: 'object';
                                                                    readonly properties: {
                                                                        readonly field: {
                                                                            readonly type: 'string';
                                                                        };
                                                                        readonly operator: {
                                                                            readonly type: 'string';
                                                                            readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                        };
                                                                        readonly value: {
                                                                            readonly oneOf: readonly [{
                                                                                readonly type: 'boolean';
                                                                            }, {
                                                                                readonly type: 'string';
                                                                            }, {
                                                                                readonly type: 'number';
                                                                            }];
                                                                        };
                                                                        readonly modifier: {
                                                                            readonly type: 'string';
                                                                            readonly enum: readonly ["not"];
                                                                        };
                                                                    };
                                                                };
                                                            };
                                                        };
                                                    };
                                                };
                                            };
                                            readonly required: readonly ["operator", "conditions"];
                                            readonly additionalProperties: false;
                                        }];
                                    };
                                };
                            };
                            readonly required: readonly ["operator", "conditions"];
                            readonly additionalProperties: false;
                        }];
                    };
                }, {
                    readonly type: 'object';
                    readonly properties: {
                        readonly operator: {
                            readonly type: 'string';
                            readonly enum: readonly ["and", "or"];
                        };
                        readonly conditions: {
                            readonly type: 'array';
                            readonly items: {
                                readonly oneOf: readonly [{
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly field: {
                                            readonly type: 'string';
                                        };
                                        readonly operator: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                        };
                                        readonly value: {
                                            readonly oneOf: readonly [{
                                                readonly type: 'boolean';
                                            }, {
                                                readonly type: 'string';
                                            }, {
                                                readonly type: 'number';
                                            }];
                                        };
                                        readonly modifier: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["not"];
                                        };
                                        readonly match: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'object';
                                                readonly properties: {
                                                    readonly field: {
                                                        readonly type: 'string';
                                                    };
                                                    readonly operator: {
                                                        readonly type: 'string';
                                                        readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                    };
                                                    readonly value: {
                                                        readonly oneOf: readonly [{
                                                            readonly type: 'boolean';
                                                        }, {
                                                            readonly type: 'string';
                                                        }, {
                                                            readonly type: 'number';
                                                        }];
                                                    };
                                                    readonly modifier: {
                                                        readonly type: 'string';
                                                        readonly enum: readonly ["not"];
                                                    };
                                                };
                                            };
                                        };
                                    };
                                }, {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly operator: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["and", "or"];
                                        };
                                        readonly conditions: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly oneOf: readonly [{
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly field: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly operator: {
                                                            readonly type: 'string';
                                                            readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                        };
                                                        readonly value: {
                                                            readonly oneOf: readonly [{
                                                                readonly type: 'boolean';
                                                            }, {
                                                                readonly type: 'string';
                                                            }, {
                                                                readonly type: 'number';
                                                            }];
                                                        };
                                                        readonly modifier: {
                                                            readonly type: 'string';
                                                            readonly enum: readonly ["not"];
                                                        };
                                                        readonly match: {
                                                            readonly type: 'array';
                                                            readonly items: {
                                                                readonly type: 'object';
                                                                readonly properties: {
                                                                    readonly field: {
                                                                        readonly type: 'string';
                                                                    };
                                                                    readonly operator: {
                                                                        readonly type: 'string';
                                                                        readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                    };
                                                                    readonly value: {
                                                                        readonly oneOf: readonly [{
                                                                            readonly type: 'boolean';
                                                                        }, {
                                                                            readonly type: 'string';
                                                                        }, {
                                                                            readonly type: 'number';
                                                                        }];
                                                                    };
                                                                    readonly modifier: {
                                                                        readonly type: 'string';
                                                                        readonly enum: readonly ["not"];
                                                                    };
                                                                };
                                                            };
                                                        };
                                                    };
                                                }, {
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly operator: {
                                                            readonly type: 'string';
                                                            readonly enum: readonly ["and", "or"];
                                                        };
                                                        readonly conditions: {
                                                            readonly type: 'array';
                                                            readonly items: {
                                                                readonly type: 'object';
                                                                readonly properties: {
                                                                    readonly field: {
                                                                        readonly type: 'string';
                                                                    };
                                                                    readonly operator: {
                                                                        readonly type: 'string';
                                                                        readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                    };
                                                                    readonly value: {
                                                                        readonly oneOf: readonly [{
                                                                            readonly type: 'boolean';
                                                                        }, {
                                                                            readonly type: 'string';
                                                                        }, {
                                                                            readonly type: 'number';
                                                                        }];
                                                                    };
                                                                    readonly modifier: {
                                                                        readonly type: 'string';
                                                                        readonly enum: readonly ["not"];
                                                                    };
                                                                    readonly match: {
                                                                        readonly type: 'array';
                                                                        readonly items: {
                                                                            readonly type: 'object';
                                                                            readonly properties: {
                                                                                readonly field: {
                                                                                    readonly type: 'string';
                                                                                };
                                                                                readonly operator: {
                                                                                    readonly type: 'string';
                                                                                    readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                                };
                                                                                readonly value: {
                                                                                    readonly oneOf: readonly [{
                                                                                        readonly type: 'boolean';
                                                                                    }, {
                                                                                        readonly type: 'string';
                                                                                    }, {
                                                                                        readonly type: 'number';
                                                                                    }];
                                                                                };
                                                                                readonly modifier: {
                                                                                    readonly type: 'string';
                                                                                    readonly enum: readonly ["not"];
                                                                                };
                                                                            };
                                                                        };
                                                                    };
                                                                };
                                                            };
                                                        };
                                                    };
                                                    readonly required: readonly ["operator", "conditions"];
                                                    readonly additionalProperties: false;
                                                }];
                                            };
                                        };
                                    };
                                    readonly required: readonly ["operator", "conditions"];
                                    readonly additionalProperties: false;
                                }];
                            };
                        };
                    };
                    readonly required: readonly ["operator", "conditions"];
                    readonly additionalProperties: false;
                }];
            };
            readonly levels: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly name: {
                            readonly type: 'string';
                        };
                        readonly extends: {
                            readonly nodeTypeName: undefined;
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'string';
                            };
                            readonly description: 'Use extends to inherit rules and their configurations from other rulesets.';
                            readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/extends';
                        };
                        readonly rules: {
                            readonly type: 'object';
                            readonly additionalProperties: {
                                readonly oneOf: readonly [{
                                    readonly type: 'string';
                                }, {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly severity: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["error", "warn", "off"];
                                        };
                                        readonly weight: {
                                            readonly type: 'number';
                                        };
                                    };
                                    readonly additionalProperties: true;
                                }, {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly title: {
                                            readonly type: 'string';
                                        };
                                        readonly subject: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly type: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["Entity", "EntityMetadata", "EntityRelations", "EntityRelation"];
                                                };
                                                readonly property: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly required: readonly ["type", "property"];
                                            readonly additionalProperties: false;
                                        };
                                        readonly severity: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["error", "warn", "off"];
                                        };
                                        readonly message: {
                                            readonly type: 'string';
                                        };
                                        readonly assertions: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly defined: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly nonEmpty: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly eq: {
                                                    readonly oneOf: readonly [{
                                                        readonly type: 'boolean';
                                                    }, {
                                                        readonly type: 'string';
                                                    }, {
                                                        readonly type: 'number';
                                                    }];
                                                };
                                                readonly gt: {
                                                    readonly type: 'number';
                                                };
                                                readonly gte: {
                                                    readonly type: 'number';
                                                };
                                                readonly lt: {
                                                    readonly type: 'number';
                                                };
                                                readonly lte: {
                                                    readonly type: 'number';
                                                };
                                                readonly const: {
                                                    readonly oneOf: readonly [{
                                                        readonly type: 'boolean';
                                                    }, {
                                                        readonly type: 'string';
                                                    }, {
                                                        readonly type: 'number';
                                                    }];
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                        readonly where: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'object';
                                                readonly properties: {
                                                    readonly subject: {
                                                        readonly type: 'object';
                                                        readonly properties: {
                                                            readonly type: {
                                                                readonly type: 'string';
                                                                readonly enum: readonly ["Entity", "EntityMetadata", "EntityRelations", "EntityRelation"];
                                                            };
                                                            readonly property: {
                                                                readonly type: 'string';
                                                            };
                                                        };
                                                        readonly required: readonly ["type", "property"];
                                                        readonly additionalProperties: false;
                                                    };
                                                    readonly assertions: {
                                                        readonly type: 'object';
                                                        readonly properties: {
                                                            readonly defined: {
                                                                readonly type: 'boolean';
                                                            };
                                                            readonly nonEmpty: {
                                                                readonly type: 'boolean';
                                                            };
                                                            readonly eq: {
                                                                readonly oneOf: readonly [{
                                                                    readonly type: 'boolean';
                                                                }, {
                                                                    readonly type: 'string';
                                                                }, {
                                                                    readonly type: 'number';
                                                                }];
                                                            };
                                                            readonly gt: {
                                                                readonly type: 'number';
                                                            };
                                                            readonly gte: {
                                                                readonly type: 'number';
                                                            };
                                                            readonly lt: {
                                                                readonly type: 'number';
                                                            };
                                                            readonly lte: {
                                                                readonly type: 'number';
                                                            };
                                                            readonly const: {
                                                                readonly oneOf: readonly [{
                                                                    readonly type: 'boolean';
                                                                }, {
                                                                    readonly type: 'string';
                                                                }, {
                                                                    readonly type: 'number';
                                                                }];
                                                            };
                                                        };
                                                        readonly additionalProperties: false;
                                                    };
                                                };
                                                readonly required: readonly ["subject", "assertions"];
                                                readonly additionalProperties: false;
                                            };
                                        };
                                        readonly weight: {
                                            readonly type: 'number';
                                        };
                                    };
                                    readonly required: readonly ["subject", "assertions"];
                                    readonly additionalProperties: false;
                                }];
                            };
                        };
                    };
                    readonly required: readonly ["name"];
                    readonly additionalProperties: false;
                };
                readonly minItems: 1;
            };
            readonly trigger: {
                readonly oneOf: readonly [{
                    readonly type: 'object';
                    readonly properties: {
                        readonly event: {
                            readonly type: 'string';
                            readonly enum: readonly ["runtime", "manual"];
                        };
                    };
                    readonly required: readonly ["event"];
                    readonly additionalProperties: false;
                }, {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly event: {
                                readonly type: 'string';
                                readonly enum: readonly ["runtime", "manual"];
                            };
                        };
                        readonly required: readonly ["event"];
                        readonly additionalProperties: false;
                    };
                }];
            };
        };
        readonly required: readonly ["name", "key", "entities", "levels"];
        readonly additionalProperties: false;
    };
};
