export declare const recheckSeveritySchema: {
    readonly type: 'string';
    readonly enum: readonly ["off", "info", "warn", "error"];
};
export declare const recheckRuleObjectSchema: {
    readonly type: 'object';
    readonly properties: {
        readonly severity: {
            readonly type: 'string';
            readonly enum: readonly ["off", "info", "warn", "error"];
        };
        readonly message: {
            readonly type: 'string';
            readonly minLength: 1;
        };
        readonly fix: {
            readonly type: 'boolean';
        };
        readonly tags: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'string';
            };
        };
        readonly description: {
            readonly type: 'string';
        };
        readonly link: {
            readonly type: 'string';
        };
        readonly scope: {
            readonly oneOf: readonly [{
                readonly type: 'string';
                readonly minLength: 1;
            }, {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                    readonly minLength: 1;
                };
                readonly minItems: 1;
            }];
        };
        readonly appliesTo: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'string';
            };
        };
        readonly excludes: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'string';
            };
        };
        readonly exceptions: {
            readonly type: 'object';
            readonly properties: {
                readonly files: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                    };
                };
                readonly lines: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                    };
                };
            };
            readonly additionalProperties: false;
        };
        readonly assertions: {
            readonly type: 'object';
            readonly additionalProperties: true;
        };
    };
    readonly additionalProperties: false;
};
export declare const recheckRuleSchema: {
    readonly oneOf: readonly [{
        readonly type: 'string';
        readonly enum: readonly ["off", "info", "warn", "error"];
    }, {
        readonly type: 'object';
        readonly properties: {
            readonly severity: {
                readonly type: 'string';
                readonly enum: readonly ["off", "info", "warn", "error"];
            };
            readonly message: {
                readonly type: 'string';
                readonly minLength: 1;
            };
            readonly fix: {
                readonly type: 'boolean';
            };
            readonly tags: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                };
            };
            readonly description: {
                readonly type: 'string';
            };
            readonly link: {
                readonly type: 'string';
            };
            readonly scope: {
                readonly oneOf: readonly [{
                    readonly type: 'string';
                    readonly minLength: 1;
                }, {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                        readonly minLength: 1;
                    };
                    readonly minItems: 1;
                }];
            };
            readonly appliesTo: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                };
            };
            readonly excludes: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                };
            };
            readonly exceptions: {
                readonly type: 'object';
                readonly properties: {
                    readonly files: {
                        readonly type: 'array';
                        readonly items: {
                            readonly type: 'string';
                        };
                    };
                    readonly lines: {
                        readonly type: 'array';
                        readonly items: {
                            readonly type: 'string';
                        };
                    };
                };
                readonly additionalProperties: false;
            };
            readonly assertions: {
                readonly type: 'object';
                readonly additionalProperties: true;
            };
        };
        readonly additionalProperties: false;
    }];
};
export declare const recheckRulesSchema: {
    readonly type: 'object';
    readonly additionalProperties: {
        readonly oneOf: readonly [{
            readonly type: 'string';
            readonly enum: readonly ["off", "info", "warn", "error"];
        }, {
            readonly type: 'object';
            readonly properties: {
                readonly severity: {
                    readonly type: 'string';
                    readonly enum: readonly ["off", "info", "warn", "error"];
                };
                readonly message: {
                    readonly type: 'string';
                    readonly minLength: 1;
                };
                readonly fix: {
                    readonly type: 'boolean';
                };
                readonly tags: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                    };
                };
                readonly description: {
                    readonly type: 'string';
                };
                readonly link: {
                    readonly type: 'string';
                };
                readonly scope: {
                    readonly oneOf: readonly [{
                        readonly type: 'string';
                        readonly minLength: 1;
                    }, {
                        readonly type: 'array';
                        readonly items: {
                            readonly type: 'string';
                            readonly minLength: 1;
                        };
                        readonly minItems: 1;
                    }];
                };
                readonly appliesTo: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                    };
                };
                readonly excludes: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                    };
                };
                readonly exceptions: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly files: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'string';
                            };
                        };
                        readonly lines: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'string';
                            };
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly assertions: {
                    readonly type: 'object';
                    readonly additionalProperties: true;
                };
            };
            readonly additionalProperties: false;
        }];
    };
};
export declare const recheckMarkdocAttributeSchema: {
    readonly type: 'object';
    readonly properties: {
        readonly type: {
            readonly type: 'string';
            readonly enum: readonly ["string", "number", "boolean"];
        };
        readonly required: {
            readonly type: 'boolean';
        };
        readonly default: {
            readonly oneOf: readonly [{
                readonly type: 'string';
            }, {
                readonly type: 'number';
            }, {
                readonly type: 'boolean';
            }];
        };
        readonly enum: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'string';
            };
            readonly minItems: 1;
        };
        readonly dynamic: {
            readonly type: 'boolean';
        };
    };
    readonly required: readonly ["type"];
    readonly additionalProperties: false;
};
export declare const recheckMarkdocTagSchema: {
    readonly type: 'object';
    readonly properties: {
        readonly selfClosing: {
            readonly type: 'boolean';
        };
        readonly attributes: {
            readonly type: 'object';
            readonly additionalProperties: {
                readonly type: 'object';
                readonly properties: {
                    readonly type: {
                        readonly type: 'string';
                        readonly enum: readonly ["string", "number", "boolean"];
                    };
                    readonly required: {
                        readonly type: 'boolean';
                    };
                    readonly default: {
                        readonly oneOf: readonly [{
                            readonly type: 'string';
                        }, {
                            readonly type: 'number';
                        }, {
                            readonly type: 'boolean';
                        }];
                    };
                    readonly enum: {
                        readonly type: 'array';
                        readonly items: {
                            readonly type: 'string';
                        };
                        readonly minItems: 1;
                    };
                    readonly dynamic: {
                        readonly type: 'boolean';
                    };
                };
                readonly required: readonly ["type"];
                readonly additionalProperties: false;
            };
        };
    };
    readonly additionalProperties: false;
};
export declare const recheckMarkdocObjectSchema: {
    readonly type: 'object';
    readonly properties: {
        readonly schema: {
            readonly oneOf: readonly [{
                readonly type: 'string';
                readonly enum: readonly ["realm"];
            }, {
                readonly type: 'boolean';
            }];
        };
        readonly extend: {
            readonly type: 'object';
            readonly properties: {
                readonly tags: {
                    readonly type: 'object';
                    readonly additionalProperties: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly selfClosing: {
                                readonly type: 'boolean';
                            };
                            readonly attributes: {
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly type: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["string", "number", "boolean"];
                                        };
                                        readonly required: {
                                            readonly type: 'boolean';
                                        };
                                        readonly default: {
                                            readonly oneOf: readonly [{
                                                readonly type: 'string';
                                            }, {
                                                readonly type: 'number';
                                            }, {
                                                readonly type: 'boolean';
                                            }];
                                        };
                                        readonly enum: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                            readonly minItems: 1;
                                        };
                                        readonly dynamic: {
                                            readonly type: 'boolean';
                                        };
                                    };
                                    readonly required: readonly ["type"];
                                    readonly additionalProperties: false;
                                };
                            };
                        };
                        readonly additionalProperties: false;
                    };
                };
                readonly tagsFile: {
                    readonly type: 'string';
                    readonly format: 'uri-reference';
                    readonly minLength: 1;
                };
            };
            readonly additionalProperties: false;
        };
    };
    readonly required: readonly ["schema"];
    readonly additionalProperties: false;
};
export declare const recheckMarkdocSchema: {
    readonly oneOf: readonly [{
        readonly type: 'boolean';
    }, {
        readonly type: 'object';
        readonly properties: {
            readonly schema: {
                readonly oneOf: readonly [{
                    readonly type: 'string';
                    readonly enum: readonly ["realm"];
                }, {
                    readonly type: 'boolean';
                }];
            };
            readonly extend: {
                readonly type: 'object';
                readonly properties: {
                    readonly tags: {
                        readonly type: 'object';
                        readonly additionalProperties: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly selfClosing: {
                                    readonly type: 'boolean';
                                };
                                readonly attributes: {
                                    readonly type: 'object';
                                    readonly additionalProperties: {
                                        readonly type: 'object';
                                        readonly properties: {
                                            readonly type: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["string", "number", "boolean"];
                                            };
                                            readonly required: {
                                                readonly type: 'boolean';
                                            };
                                            readonly default: {
                                                readonly oneOf: readonly [{
                                                    readonly type: 'string';
                                                }, {
                                                    readonly type: 'number';
                                                }, {
                                                    readonly type: 'boolean';
                                                }];
                                            };
                                            readonly enum: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                                readonly minItems: 1;
                                            };
                                            readonly dynamic: {
                                                readonly type: 'boolean';
                                            };
                                        };
                                        readonly required: readonly ["type"];
                                        readonly additionalProperties: false;
                                    };
                                };
                            };
                            readonly additionalProperties: false;
                        };
                    };
                    readonly tagsFile: {
                        readonly type: 'string';
                        readonly format: 'uri-reference';
                        readonly minLength: 1;
                    };
                };
                readonly additionalProperties: false;
            };
        };
        readonly required: readonly ["schema"];
        readonly additionalProperties: false;
    }];
};
export declare const recheckConfigSchema: {
    readonly type: 'object';
    readonly properties: {
        readonly rules: {
            readonly type: 'object';
            readonly additionalProperties: {
                readonly oneOf: readonly [{
                    readonly type: 'string';
                    readonly enum: readonly ["off", "info", "warn", "error"];
                }, {
                    readonly type: 'object';
                    readonly properties: {
                        readonly severity: {
                            readonly type: 'string';
                            readonly enum: readonly ["off", "info", "warn", "error"];
                        };
                        readonly message: {
                            readonly type: 'string';
                            readonly minLength: 1;
                        };
                        readonly fix: {
                            readonly type: 'boolean';
                        };
                        readonly tags: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'string';
                            };
                        };
                        readonly description: {
                            readonly type: 'string';
                        };
                        readonly link: {
                            readonly type: 'string';
                        };
                        readonly scope: {
                            readonly oneOf: readonly [{
                                readonly type: 'string';
                                readonly minLength: 1;
                            }, {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'string';
                                    readonly minLength: 1;
                                };
                                readonly minItems: 1;
                            }];
                        };
                        readonly appliesTo: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'string';
                            };
                        };
                        readonly excludes: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'string';
                            };
                        };
                        readonly exceptions: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly files: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'string';
                                    };
                                };
                                readonly lines: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'string';
                                    };
                                };
                            };
                            readonly additionalProperties: false;
                        };
                        readonly assertions: {
                            readonly type: 'object';
                            readonly additionalProperties: true;
                        };
                    };
                    readonly additionalProperties: false;
                }];
            };
        };
        readonly excludes: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'string';
                readonly minLength: 1;
            };
        };
        readonly markdoc: {
            readonly oneOf: readonly [{
                readonly type: 'boolean';
            }, {
                readonly type: 'object';
                readonly properties: {
                    readonly schema: {
                        readonly oneOf: readonly [{
                            readonly type: 'string';
                            readonly enum: readonly ["realm"];
                        }, {
                            readonly type: 'boolean';
                        }];
                    };
                    readonly extend: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly tags: {
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly selfClosing: {
                                            readonly type: 'boolean';
                                        };
                                        readonly attributes: {
                                            readonly type: 'object';
                                            readonly additionalProperties: {
                                                readonly type: 'object';
                                                readonly properties: {
                                                    readonly type: {
                                                        readonly type: 'string';
                                                        readonly enum: readonly ["string", "number", "boolean"];
                                                    };
                                                    readonly required: {
                                                        readonly type: 'boolean';
                                                    };
                                                    readonly default: {
                                                        readonly oneOf: readonly [{
                                                            readonly type: 'string';
                                                        }, {
                                                            readonly type: 'number';
                                                        }, {
                                                            readonly type: 'boolean';
                                                        }];
                                                    };
                                                    readonly enum: {
                                                        readonly type: 'array';
                                                        readonly items: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly minItems: 1;
                                                    };
                                                    readonly dynamic: {
                                                        readonly type: 'boolean';
                                                    };
                                                };
                                                readonly required: readonly ["type"];
                                                readonly additionalProperties: false;
                                            };
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                            };
                            readonly tagsFile: {
                                readonly type: 'string';
                                readonly format: 'uri-reference';
                                readonly minLength: 1;
                            };
                        };
                        readonly additionalProperties: false;
                    };
                };
                readonly required: readonly ["schema"];
                readonly additionalProperties: false;
            }];
        };
        readonly apiDescriptions: {
            readonly type: 'object';
            readonly properties: {
                readonly rules: {
                    readonly type: 'object';
                    readonly additionalProperties: {
                        readonly oneOf: readonly [{
                            readonly type: 'string';
                            readonly enum: readonly ["off", "info", "warn", "error"];
                        }, {
                            readonly type: 'object';
                            readonly properties: {
                                readonly severity: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["off", "info", "warn", "error"];
                                };
                                readonly message: {
                                    readonly type: 'string';
                                    readonly minLength: 1;
                                };
                                readonly fix: {
                                    readonly type: 'boolean';
                                };
                                readonly tags: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'string';
                                    };
                                };
                                readonly description: {
                                    readonly type: 'string';
                                };
                                readonly link: {
                                    readonly type: 'string';
                                };
                                readonly scope: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                        readonly minLength: 1;
                                    }, {
                                        readonly type: 'array';
                                        readonly items: {
                                            readonly type: 'string';
                                            readonly minLength: 1;
                                        };
                                        readonly minItems: 1;
                                    }];
                                };
                                readonly appliesTo: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'string';
                                    };
                                };
                                readonly excludes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'string';
                                    };
                                };
                                readonly exceptions: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly files: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly lines: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly assertions: {
                                    readonly type: 'object';
                                    readonly additionalProperties: true;
                                };
                            };
                            readonly additionalProperties: false;
                        }];
                    };
                };
            };
            readonly additionalProperties: false;
        };
    };
    readonly additionalProperties: false;
};
