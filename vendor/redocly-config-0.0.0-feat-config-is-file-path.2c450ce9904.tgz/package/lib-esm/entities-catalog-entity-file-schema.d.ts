export declare const userMetadataSchema: {
    readonly type: 'object';
    readonly nodeTypeName: "UserEntityMetadata";
    readonly properties: {
        readonly email: {
            readonly type: 'string';
            readonly description: 'Email of the user';
        };
    };
    readonly required: readonly ["email"];
    readonly additionalProperties: true;
};
export declare const apiDescriptionMetadataSchema: {
    readonly type: 'object';
    readonly nodeTypeName: "ApiDescriptionEntityMetadata";
    readonly properties: {
        readonly specType: {
            readonly type: 'string';
            readonly enum: readonly ["jsonschema", "openapi", "asyncapi", "avro", "zod", "graphql", "protobuf", "arazzo"];
            readonly description: 'Type of the API description';
        };
        readonly descriptionFile: {
            readonly type: 'string';
            readonly description: 'Path to the file containing the API description';
        };
    };
    readonly required: readonly ["specType", "descriptionFile"];
    readonly additionalProperties: true;
};
export declare const apiOperationMetadataSchema: {
    readonly type: 'object';
    readonly nodeTypeName: "ApiOperationEntityMetadata";
    readonly properties: {
        readonly method: {
            readonly type: 'string';
            readonly enum: readonly ["GET", "POST", "PUT", "DELETE", "PATCH", "MUTATION", "QUERY", "SUBSCRIBE", "PUBLISH"];
            readonly description: 'HTTP method of the API operation';
        };
        readonly path: {
            readonly type: 'string';
            readonly description: 'Path of the API operation';
        };
        readonly payload: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'string';
                readonly description: 'Related dataSchema name';
            };
        };
        readonly responses: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'string';
                readonly description: 'Related dataSchema name';
            };
        };
    };
    readonly required: readonly ["method", "path"];
    readonly additionalProperties: true;
};
export declare const dataSchemaMetadataSchema: {
    readonly type: 'object';
    readonly nodeTypeName: "DataSchemaEntityMetadata";
    readonly properties: {
        readonly specType: {
            readonly type: 'string';
            readonly enum: readonly ["jsonschema", "openapi", "asyncapi", "avro", "zod", "graphql", "protobuf", "arazzo"];
            readonly description: 'Specification type of the data schema';
        };
        readonly schema: {
            readonly type: 'string';
            readonly description: 'Inline schema of the data structure';
        };
        readonly sdl: {
            readonly type: 'string';
            readonly description: 'SDL of the data structure';
        };
    };
    readonly required: readonly ["specType"];
    readonly additionalProperties: true;
};
export declare const defaultMetadataSchema: {
    readonly type: 'object';
    readonly properties: {};
    readonly nodeTypeName: "EntityMetadata";
    readonly additionalProperties: true;
};
export declare const slackChannelFileSchema: {
    readonly type: 'object';
    readonly nodeTypeName: "EntitySlackChannel";
    readonly properties: {
        readonly name: {
            readonly type: 'string';
            readonly minLength: 2;
            readonly maxLength: 150;
        };
        readonly url: {
            readonly type: 'string';
        };
    };
    readonly required: readonly ["name"];
    readonly additionalProperties: false;
};
export declare const slackContactFileSchema: {
    readonly type: 'object';
    readonly nodeTypeName: "EntitySlackContact";
    readonly properties: {
        readonly channels: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'object';
                readonly nodeTypeName: "EntitySlackChannel";
                readonly properties: {
                    readonly name: {
                        readonly type: 'string';
                        readonly minLength: 2;
                        readonly maxLength: 150;
                    };
                    readonly url: {
                        readonly type: 'string';
                    };
                };
                readonly required: readonly ["name"];
                readonly additionalProperties: false;
            };
        };
    };
    readonly required: readonly ["channels"];
    readonly additionalProperties: false;
};
export declare const entityContactFileSchema: {
    readonly type: 'object';
    readonly nodeTypeName: "EntityContact";
    readonly properties: {
        readonly slack: {
            readonly type: 'object';
            readonly nodeTypeName: "EntitySlackContact";
            readonly properties: {
                readonly channels: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'object';
                        readonly nodeTypeName: "EntitySlackChannel";
                        readonly properties: {
                            readonly name: {
                                readonly type: 'string';
                                readonly minLength: 2;
                                readonly maxLength: 150;
                            };
                            readonly url: {
                                readonly type: 'string';
                            };
                        };
                        readonly required: readonly ["name"];
                        readonly additionalProperties: false;
                    };
                };
            };
            readonly required: readonly ["channels"];
            readonly additionalProperties: false;
        };
    };
    readonly additionalProperties: false;
};
export declare const entityLinkFileSchema: {
    readonly type: 'object';
    readonly nodeTypeName: "EntityLink";
    readonly properties: {
        readonly label: {
            readonly type: 'string';
            readonly minLength: 2;
            readonly maxLength: 150;
        };
        readonly url: {
            readonly type: 'string';
        };
    };
    readonly required: readonly ["label", "url"];
    readonly additionalProperties: false;
};
export declare const entityRelationFileSchema: {
    readonly type: 'object';
    readonly nodeTypeName: "EntityRelation";
    readonly properties: {
        readonly type: {
            readonly type: 'string';
            readonly enum: readonly ["partOf", "hasParts", "creates", "createdBy", "owns", "ownedBy", "implements", "implementedBy", "dependsOn", "dependencyOf", "uses", "usedBy", "produces", "consumes", "linksTo", "supersedes", "supersededBy", "compatibleWith", "extends", "extendedBy", "relatesTo", "hasMember", "memberOf", "triggers", "triggeredBy", "returns", "returnedBy"];
        };
        readonly key: {
            readonly type: 'string';
            readonly minLength: 2;
            readonly maxLength: 100;
        };
        readonly version: {
            readonly type: 'string';
        };
        readonly revision: {
            readonly type: 'string';
        };
    };
    readonly required: readonly ["type", "key"];
    readonly additionalProperties: false;
};
export declare const entityBaseProperties: {
    readonly version: {
        readonly type: 'string';
    };
    readonly key: {
        readonly type: 'string';
        readonly pattern: '^[a-z0-9]+(?:-[a-z0-9]+)*$';
        readonly minLength: 2;
        readonly maxLength: 150;
    };
    readonly type: {
        readonly type: 'string';
        readonly enum: readonly ["user", "data-schema", "api-operation", "api-description", "service", "domain", "team"];
    };
    readonly title: {
        readonly type: 'string';
        readonly minLength: 2;
        readonly maxLength: 200;
    };
    readonly summary: {
        readonly type: 'string';
        readonly minLength: 1;
        readonly maxLength: 500;
    };
    readonly tags: {
        readonly type: 'array';
        readonly items: {
            readonly type: 'string';
            readonly minLength: 1;
            readonly maxLength: 50;
        };
    };
    readonly git: {
        readonly type: 'array';
        readonly items: {
            readonly type: 'string';
        };
    };
    readonly contact: {
        readonly type: 'object';
        readonly nodeTypeName: "EntityContact";
        readonly properties: {
            readonly slack: {
                readonly type: 'object';
                readonly nodeTypeName: "EntitySlackContact";
                readonly properties: {
                    readonly channels: {
                        readonly type: 'array';
                        readonly items: {
                            readonly type: 'object';
                            readonly nodeTypeName: "EntitySlackChannel";
                            readonly properties: {
                                readonly name: {
                                    readonly type: 'string';
                                    readonly minLength: 2;
                                    readonly maxLength: 150;
                                };
                                readonly url: {
                                    readonly type: 'string';
                                };
                            };
                            readonly required: readonly ["name"];
                            readonly additionalProperties: false;
                        };
                    };
                };
                readonly required: readonly ["channels"];
                readonly additionalProperties: false;
            };
        };
        readonly additionalProperties: false;
    };
    readonly links: {
        readonly type: 'array';
        readonly nodeTypeName: "EntityLinkList";
        readonly items: {
            readonly type: 'object';
            readonly nodeTypeName: "EntityLink";
            readonly properties: {
                readonly label: {
                    readonly type: 'string';
                    readonly minLength: 2;
                    readonly maxLength: 150;
                };
                readonly url: {
                    readonly type: 'string';
                };
            };
            readonly required: readonly ["label", "url"];
            readonly additionalProperties: false;
        };
    };
    readonly relations: {
        readonly type: 'array';
        readonly nodeTypeName: "EntityRelationList";
        readonly items: {
            readonly type: 'object';
            readonly nodeTypeName: "EntityRelation";
            readonly properties: {
                readonly type: {
                    readonly type: 'string';
                    readonly enum: readonly ["partOf", "hasParts", "creates", "createdBy", "owns", "ownedBy", "implements", "implementedBy", "dependsOn", "dependencyOf", "uses", "usedBy", "produces", "consumes", "linksTo", "supersedes", "supersededBy", "compatibleWith", "extends", "extendedBy", "relatesTo", "hasMember", "memberOf", "triggers", "triggeredBy", "returns", "returnedBy"];
                };
                readonly key: {
                    readonly type: 'string';
                    readonly minLength: 2;
                    readonly maxLength: 100;
                };
                readonly version: {
                    readonly type: 'string';
                };
                readonly revision: {
                    readonly type: 'string';
                };
            };
            readonly required: readonly ["type", "key"];
            readonly additionalProperties: false;
        };
    };
    readonly metadata: {
        readonly type: 'object';
        readonly properties: {};
        readonly nodeTypeName: "EntityMetadata";
        readonly additionalProperties: true;
    };
};
export declare const entityFileSchema: {
    readonly type: 'object';
    readonly discriminator: {
        readonly propertyName: 'type';
    };
    readonly oneOf: readonly [{
        readonly type: 'object';
        readonly properties: {
            readonly version: {
                readonly type: 'string';
            };
            readonly key: {
                readonly type: 'string';
                readonly pattern: '^[a-z0-9]+(?:-[a-z0-9]+)*$';
                readonly minLength: 2;
                readonly maxLength: 150;
            };
            readonly title: {
                readonly type: 'string';
                readonly minLength: 2;
                readonly maxLength: 200;
            };
            readonly summary: {
                readonly type: 'string';
                readonly minLength: 1;
                readonly maxLength: 500;
            };
            readonly tags: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                    readonly minLength: 1;
                    readonly maxLength: 50;
                };
            };
            readonly git: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                };
            };
            readonly contact: {
                readonly type: 'object';
                readonly nodeTypeName: "EntityContact";
                readonly properties: {
                    readonly slack: {
                        readonly type: 'object';
                        readonly nodeTypeName: "EntitySlackContact";
                        readonly properties: {
                            readonly channels: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'object';
                                    readonly nodeTypeName: "EntitySlackChannel";
                                    readonly properties: {
                                        readonly name: {
                                            readonly type: 'string';
                                            readonly minLength: 2;
                                            readonly maxLength: 150;
                                        };
                                        readonly url: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly required: readonly ["name"];
                                    readonly additionalProperties: false;
                                };
                            };
                        };
                        readonly required: readonly ["channels"];
                        readonly additionalProperties: false;
                    };
                };
                readonly additionalProperties: false;
            };
            readonly links: {
                readonly type: 'array';
                readonly nodeTypeName: "EntityLinkList";
                readonly items: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntityLink";
                    readonly properties: {
                        readonly label: {
                            readonly type: 'string';
                            readonly minLength: 2;
                            readonly maxLength: 150;
                        };
                        readonly url: {
                            readonly type: 'string';
                        };
                    };
                    readonly required: readonly ["label", "url"];
                    readonly additionalProperties: false;
                };
            };
            readonly relations: {
                readonly type: 'array';
                readonly nodeTypeName: "EntityRelationList";
                readonly items: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntityRelation";
                    readonly properties: {
                        readonly type: {
                            readonly type: 'string';
                            readonly enum: readonly ["partOf", "hasParts", "creates", "createdBy", "owns", "ownedBy", "implements", "implementedBy", "dependsOn", "dependencyOf", "uses", "usedBy", "produces", "consumes", "linksTo", "supersedes", "supersededBy", "compatibleWith", "extends", "extendedBy", "relatesTo", "hasMember", "memberOf", "triggers", "triggeredBy", "returns", "returnedBy"];
                        };
                        readonly key: {
                            readonly type: 'string';
                            readonly minLength: 2;
                            readonly maxLength: 100;
                        };
                        readonly version: {
                            readonly type: 'string';
                        };
                        readonly revision: {
                            readonly type: 'string';
                        };
                    };
                    readonly required: readonly ["type", "key"];
                    readonly additionalProperties: false;
                };
            };
            readonly type: {
                readonly type: 'string';
                readonly const: 'user';
            };
            readonly metadata: {
                readonly type: 'object';
                readonly nodeTypeName: "UserEntityMetadata";
                readonly properties: {
                    readonly email: {
                        readonly type: 'string';
                        readonly description: 'Email of the user';
                    };
                };
                readonly required: readonly ["email"];
                readonly additionalProperties: true;
            };
        };
        readonly required: readonly ["key", "title", "type", "metadata"];
        readonly additionalProperties: false;
        readonly nodeTypeName: "UserEntity";
    }, {
        readonly type: 'object';
        readonly nodeTypeName: "ApiOperationEntity";
        readonly properties: {
            readonly version: {
                readonly type: 'string';
            };
            readonly key: {
                readonly type: 'string';
                readonly pattern: '^[a-z0-9]+(?:-[a-z0-9]+)*$';
                readonly minLength: 2;
                readonly maxLength: 150;
            };
            readonly title: {
                readonly type: 'string';
                readonly minLength: 2;
                readonly maxLength: 200;
            };
            readonly summary: {
                readonly type: 'string';
                readonly minLength: 1;
                readonly maxLength: 500;
            };
            readonly tags: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                    readonly minLength: 1;
                    readonly maxLength: 50;
                };
            };
            readonly git: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                };
            };
            readonly contact: {
                readonly type: 'object';
                readonly nodeTypeName: "EntityContact";
                readonly properties: {
                    readonly slack: {
                        readonly type: 'object';
                        readonly nodeTypeName: "EntitySlackContact";
                        readonly properties: {
                            readonly channels: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'object';
                                    readonly nodeTypeName: "EntitySlackChannel";
                                    readonly properties: {
                                        readonly name: {
                                            readonly type: 'string';
                                            readonly minLength: 2;
                                            readonly maxLength: 150;
                                        };
                                        readonly url: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly required: readonly ["name"];
                                    readonly additionalProperties: false;
                                };
                            };
                        };
                        readonly required: readonly ["channels"];
                        readonly additionalProperties: false;
                    };
                };
                readonly additionalProperties: false;
            };
            readonly links: {
                readonly type: 'array';
                readonly nodeTypeName: "EntityLinkList";
                readonly items: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntityLink";
                    readonly properties: {
                        readonly label: {
                            readonly type: 'string';
                            readonly minLength: 2;
                            readonly maxLength: 150;
                        };
                        readonly url: {
                            readonly type: 'string';
                        };
                    };
                    readonly required: readonly ["label", "url"];
                    readonly additionalProperties: false;
                };
            };
            readonly relations: {
                readonly type: 'array';
                readonly nodeTypeName: "EntityRelationList";
                readonly items: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntityRelation";
                    readonly properties: {
                        readonly type: {
                            readonly type: 'string';
                            readonly enum: readonly ["partOf", "hasParts", "creates", "createdBy", "owns", "ownedBy", "implements", "implementedBy", "dependsOn", "dependencyOf", "uses", "usedBy", "produces", "consumes", "linksTo", "supersedes", "supersededBy", "compatibleWith", "extends", "extendedBy", "relatesTo", "hasMember", "memberOf", "triggers", "triggeredBy", "returns", "returnedBy"];
                        };
                        readonly key: {
                            readonly type: 'string';
                            readonly minLength: 2;
                            readonly maxLength: 100;
                        };
                        readonly version: {
                            readonly type: 'string';
                        };
                        readonly revision: {
                            readonly type: 'string';
                        };
                    };
                    readonly required: readonly ["type", "key"];
                    readonly additionalProperties: false;
                };
            };
            readonly type: {
                readonly type: 'string';
                readonly const: 'api-operation';
            };
            readonly metadata: {
                readonly type: 'object';
                readonly nodeTypeName: "ApiOperationEntityMetadata";
                readonly properties: {
                    readonly method: {
                        readonly type: 'string';
                        readonly enum: readonly ["GET", "POST", "PUT", "DELETE", "PATCH", "MUTATION", "QUERY", "SUBSCRIBE", "PUBLISH"];
                        readonly description: 'HTTP method of the API operation';
                    };
                    readonly path: {
                        readonly type: 'string';
                        readonly description: 'Path of the API operation';
                    };
                    readonly payload: {
                        readonly type: 'array';
                        readonly items: {
                            readonly type: 'string';
                            readonly description: 'Related dataSchema name';
                        };
                    };
                    readonly responses: {
                        readonly type: 'array';
                        readonly items: {
                            readonly type: 'string';
                            readonly description: 'Related dataSchema name';
                        };
                    };
                };
                readonly required: readonly ["method", "path"];
                readonly additionalProperties: true;
            };
        };
        readonly required: readonly ["key", "title", "type", "metadata"];
        readonly additionalProperties: false;
    }, {
        readonly type: 'object';
        readonly nodeTypeName: "DataSchemaEntity";
        readonly properties: {
            readonly version: {
                readonly type: 'string';
            };
            readonly key: {
                readonly type: 'string';
                readonly pattern: '^[a-z0-9]+(?:-[a-z0-9]+)*$';
                readonly minLength: 2;
                readonly maxLength: 150;
            };
            readonly title: {
                readonly type: 'string';
                readonly minLength: 2;
                readonly maxLength: 200;
            };
            readonly summary: {
                readonly type: 'string';
                readonly minLength: 1;
                readonly maxLength: 500;
            };
            readonly tags: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                    readonly minLength: 1;
                    readonly maxLength: 50;
                };
            };
            readonly git: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                };
            };
            readonly contact: {
                readonly type: 'object';
                readonly nodeTypeName: "EntityContact";
                readonly properties: {
                    readonly slack: {
                        readonly type: 'object';
                        readonly nodeTypeName: "EntitySlackContact";
                        readonly properties: {
                            readonly channels: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'object';
                                    readonly nodeTypeName: "EntitySlackChannel";
                                    readonly properties: {
                                        readonly name: {
                                            readonly type: 'string';
                                            readonly minLength: 2;
                                            readonly maxLength: 150;
                                        };
                                        readonly url: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly required: readonly ["name"];
                                    readonly additionalProperties: false;
                                };
                            };
                        };
                        readonly required: readonly ["channels"];
                        readonly additionalProperties: false;
                    };
                };
                readonly additionalProperties: false;
            };
            readonly links: {
                readonly type: 'array';
                readonly nodeTypeName: "EntityLinkList";
                readonly items: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntityLink";
                    readonly properties: {
                        readonly label: {
                            readonly type: 'string';
                            readonly minLength: 2;
                            readonly maxLength: 150;
                        };
                        readonly url: {
                            readonly type: 'string';
                        };
                    };
                    readonly required: readonly ["label", "url"];
                    readonly additionalProperties: false;
                };
            };
            readonly relations: {
                readonly type: 'array';
                readonly nodeTypeName: "EntityRelationList";
                readonly items: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntityRelation";
                    readonly properties: {
                        readonly type: {
                            readonly type: 'string';
                            readonly enum: readonly ["partOf", "hasParts", "creates", "createdBy", "owns", "ownedBy", "implements", "implementedBy", "dependsOn", "dependencyOf", "uses", "usedBy", "produces", "consumes", "linksTo", "supersedes", "supersededBy", "compatibleWith", "extends", "extendedBy", "relatesTo", "hasMember", "memberOf", "triggers", "triggeredBy", "returns", "returnedBy"];
                        };
                        readonly key: {
                            readonly type: 'string';
                            readonly minLength: 2;
                            readonly maxLength: 100;
                        };
                        readonly version: {
                            readonly type: 'string';
                        };
                        readonly revision: {
                            readonly type: 'string';
                        };
                    };
                    readonly required: readonly ["type", "key"];
                    readonly additionalProperties: false;
                };
            };
            readonly type: {
                readonly type: 'string';
                readonly const: 'data-schema';
            };
            readonly metadata: {
                readonly type: 'object';
                readonly nodeTypeName: "DataSchemaEntityMetadata";
                readonly properties: {
                    readonly specType: {
                        readonly type: 'string';
                        readonly enum: readonly ["jsonschema", "openapi", "asyncapi", "avro", "zod", "graphql", "protobuf", "arazzo"];
                        readonly description: 'Specification type of the data schema';
                    };
                    readonly schema: {
                        readonly type: 'string';
                        readonly description: 'Inline schema of the data structure';
                    };
                    readonly sdl: {
                        readonly type: 'string';
                        readonly description: 'SDL of the data structure';
                    };
                };
                readonly required: readonly ["specType"];
                readonly additionalProperties: true;
            };
        };
        readonly required: readonly ["key", "title", "type", "metadata"];
        readonly additionalProperties: false;
    }, {
        readonly type: 'object';
        readonly nodeTypeName: "ApiDescriptionEntity";
        readonly properties: {
            readonly version: {
                readonly type: 'string';
            };
            readonly key: {
                readonly type: 'string';
                readonly pattern: '^[a-z0-9]+(?:-[a-z0-9]+)*$';
                readonly minLength: 2;
                readonly maxLength: 150;
            };
            readonly title: {
                readonly type: 'string';
                readonly minLength: 2;
                readonly maxLength: 200;
            };
            readonly summary: {
                readonly type: 'string';
                readonly minLength: 1;
                readonly maxLength: 500;
            };
            readonly tags: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                    readonly minLength: 1;
                    readonly maxLength: 50;
                };
            };
            readonly git: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                };
            };
            readonly contact: {
                readonly type: 'object';
                readonly nodeTypeName: "EntityContact";
                readonly properties: {
                    readonly slack: {
                        readonly type: 'object';
                        readonly nodeTypeName: "EntitySlackContact";
                        readonly properties: {
                            readonly channels: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'object';
                                    readonly nodeTypeName: "EntitySlackChannel";
                                    readonly properties: {
                                        readonly name: {
                                            readonly type: 'string';
                                            readonly minLength: 2;
                                            readonly maxLength: 150;
                                        };
                                        readonly url: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly required: readonly ["name"];
                                    readonly additionalProperties: false;
                                };
                            };
                        };
                        readonly required: readonly ["channels"];
                        readonly additionalProperties: false;
                    };
                };
                readonly additionalProperties: false;
            };
            readonly links: {
                readonly type: 'array';
                readonly nodeTypeName: "EntityLinkList";
                readonly items: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntityLink";
                    readonly properties: {
                        readonly label: {
                            readonly type: 'string';
                            readonly minLength: 2;
                            readonly maxLength: 150;
                        };
                        readonly url: {
                            readonly type: 'string';
                        };
                    };
                    readonly required: readonly ["label", "url"];
                    readonly additionalProperties: false;
                };
            };
            readonly relations: {
                readonly type: 'array';
                readonly nodeTypeName: "EntityRelationList";
                readonly items: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntityRelation";
                    readonly properties: {
                        readonly type: {
                            readonly type: 'string';
                            readonly enum: readonly ["partOf", "hasParts", "creates", "createdBy", "owns", "ownedBy", "implements", "implementedBy", "dependsOn", "dependencyOf", "uses", "usedBy", "produces", "consumes", "linksTo", "supersedes", "supersededBy", "compatibleWith", "extends", "extendedBy", "relatesTo", "hasMember", "memberOf", "triggers", "triggeredBy", "returns", "returnedBy"];
                        };
                        readonly key: {
                            readonly type: 'string';
                            readonly minLength: 2;
                            readonly maxLength: 100;
                        };
                        readonly version: {
                            readonly type: 'string';
                        };
                        readonly revision: {
                            readonly type: 'string';
                        };
                    };
                    readonly required: readonly ["type", "key"];
                    readonly additionalProperties: false;
                };
            };
            readonly type: {
                readonly type: 'string';
                readonly const: 'api-description';
            };
            readonly metadata: {
                readonly type: 'object';
                readonly nodeTypeName: "ApiDescriptionEntityMetadata";
                readonly properties: {
                    readonly specType: {
                        readonly type: 'string';
                        readonly enum: readonly ["jsonschema", "openapi", "asyncapi", "avro", "zod", "graphql", "protobuf", "arazzo"];
                        readonly description: 'Type of the API description';
                    };
                    readonly descriptionFile: {
                        readonly type: 'string';
                        readonly description: 'Path to the file containing the API description';
                    };
                };
                readonly required: readonly ["specType", "descriptionFile"];
                readonly additionalProperties: true;
            };
        };
        readonly required: readonly ["key", "title", "type", "metadata"];
        readonly additionalProperties: false;
    }, {
        readonly type: 'object';
        readonly nodeTypeName: "ServiceEntity";
        readonly properties: {
            readonly version: {
                readonly type: 'string';
            };
            readonly key: {
                readonly type: 'string';
                readonly pattern: '^[a-z0-9]+(?:-[a-z0-9]+)*$';
                readonly minLength: 2;
                readonly maxLength: 150;
            };
            readonly title: {
                readonly type: 'string';
                readonly minLength: 2;
                readonly maxLength: 200;
            };
            readonly summary: {
                readonly type: 'string';
                readonly minLength: 1;
                readonly maxLength: 500;
            };
            readonly tags: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                    readonly minLength: 1;
                    readonly maxLength: 50;
                };
            };
            readonly git: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                };
            };
            readonly contact: {
                readonly type: 'object';
                readonly nodeTypeName: "EntityContact";
                readonly properties: {
                    readonly slack: {
                        readonly type: 'object';
                        readonly nodeTypeName: "EntitySlackContact";
                        readonly properties: {
                            readonly channels: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'object';
                                    readonly nodeTypeName: "EntitySlackChannel";
                                    readonly properties: {
                                        readonly name: {
                                            readonly type: 'string';
                                            readonly minLength: 2;
                                            readonly maxLength: 150;
                                        };
                                        readonly url: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly required: readonly ["name"];
                                    readonly additionalProperties: false;
                                };
                            };
                        };
                        readonly required: readonly ["channels"];
                        readonly additionalProperties: false;
                    };
                };
                readonly additionalProperties: false;
            };
            readonly links: {
                readonly type: 'array';
                readonly nodeTypeName: "EntityLinkList";
                readonly items: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntityLink";
                    readonly properties: {
                        readonly label: {
                            readonly type: 'string';
                            readonly minLength: 2;
                            readonly maxLength: 150;
                        };
                        readonly url: {
                            readonly type: 'string';
                        };
                    };
                    readonly required: readonly ["label", "url"];
                    readonly additionalProperties: false;
                };
            };
            readonly relations: {
                readonly type: 'array';
                readonly nodeTypeName: "EntityRelationList";
                readonly items: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntityRelation";
                    readonly properties: {
                        readonly type: {
                            readonly type: 'string';
                            readonly enum: readonly ["partOf", "hasParts", "creates", "createdBy", "owns", "ownedBy", "implements", "implementedBy", "dependsOn", "dependencyOf", "uses", "usedBy", "produces", "consumes", "linksTo", "supersedes", "supersededBy", "compatibleWith", "extends", "extendedBy", "relatesTo", "hasMember", "memberOf", "triggers", "triggeredBy", "returns", "returnedBy"];
                        };
                        readonly key: {
                            readonly type: 'string';
                            readonly minLength: 2;
                            readonly maxLength: 100;
                        };
                        readonly version: {
                            readonly type: 'string';
                        };
                        readonly revision: {
                            readonly type: 'string';
                        };
                    };
                    readonly required: readonly ["type", "key"];
                    readonly additionalProperties: false;
                };
            };
            readonly metadata: {
                readonly type: 'object';
                readonly properties: {};
                readonly nodeTypeName: "EntityMetadata";
                readonly additionalProperties: true;
            };
            readonly type: {
                readonly type: 'string';
                readonly const: 'service';
            };
        };
        readonly required: readonly ["key", "title", "type"];
        readonly additionalProperties: false;
    }, {
        readonly type: 'object';
        readonly nodeTypeName: "DomainEntity";
        readonly properties: {
            readonly version: {
                readonly type: 'string';
            };
            readonly key: {
                readonly type: 'string';
                readonly pattern: '^[a-z0-9]+(?:-[a-z0-9]+)*$';
                readonly minLength: 2;
                readonly maxLength: 150;
            };
            readonly title: {
                readonly type: 'string';
                readonly minLength: 2;
                readonly maxLength: 200;
            };
            readonly summary: {
                readonly type: 'string';
                readonly minLength: 1;
                readonly maxLength: 500;
            };
            readonly tags: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                    readonly minLength: 1;
                    readonly maxLength: 50;
                };
            };
            readonly git: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                };
            };
            readonly contact: {
                readonly type: 'object';
                readonly nodeTypeName: "EntityContact";
                readonly properties: {
                    readonly slack: {
                        readonly type: 'object';
                        readonly nodeTypeName: "EntitySlackContact";
                        readonly properties: {
                            readonly channels: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'object';
                                    readonly nodeTypeName: "EntitySlackChannel";
                                    readonly properties: {
                                        readonly name: {
                                            readonly type: 'string';
                                            readonly minLength: 2;
                                            readonly maxLength: 150;
                                        };
                                        readonly url: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly required: readonly ["name"];
                                    readonly additionalProperties: false;
                                };
                            };
                        };
                        readonly required: readonly ["channels"];
                        readonly additionalProperties: false;
                    };
                };
                readonly additionalProperties: false;
            };
            readonly links: {
                readonly type: 'array';
                readonly nodeTypeName: "EntityLinkList";
                readonly items: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntityLink";
                    readonly properties: {
                        readonly label: {
                            readonly type: 'string';
                            readonly minLength: 2;
                            readonly maxLength: 150;
                        };
                        readonly url: {
                            readonly type: 'string';
                        };
                    };
                    readonly required: readonly ["label", "url"];
                    readonly additionalProperties: false;
                };
            };
            readonly relations: {
                readonly type: 'array';
                readonly nodeTypeName: "EntityRelationList";
                readonly items: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntityRelation";
                    readonly properties: {
                        readonly type: {
                            readonly type: 'string';
                            readonly enum: readonly ["partOf", "hasParts", "creates", "createdBy", "owns", "ownedBy", "implements", "implementedBy", "dependsOn", "dependencyOf", "uses", "usedBy", "produces", "consumes", "linksTo", "supersedes", "supersededBy", "compatibleWith", "extends", "extendedBy", "relatesTo", "hasMember", "memberOf", "triggers", "triggeredBy", "returns", "returnedBy"];
                        };
                        readonly key: {
                            readonly type: 'string';
                            readonly minLength: 2;
                            readonly maxLength: 100;
                        };
                        readonly version: {
                            readonly type: 'string';
                        };
                        readonly revision: {
                            readonly type: 'string';
                        };
                    };
                    readonly required: readonly ["type", "key"];
                    readonly additionalProperties: false;
                };
            };
            readonly metadata: {
                readonly type: 'object';
                readonly properties: {};
                readonly nodeTypeName: "EntityMetadata";
                readonly additionalProperties: true;
            };
            readonly type: {
                readonly type: 'string';
                readonly const: 'domain';
            };
        };
        readonly required: readonly ["key", "title", "type"];
        readonly additionalProperties: false;
    }, {
        readonly type: 'object';
        readonly nodeTypeName: "TeamEntity";
        readonly properties: {
            readonly version: {
                readonly type: 'string';
            };
            readonly key: {
                readonly type: 'string';
                readonly pattern: '^[a-z0-9]+(?:-[a-z0-9]+)*$';
                readonly minLength: 2;
                readonly maxLength: 150;
            };
            readonly title: {
                readonly type: 'string';
                readonly minLength: 2;
                readonly maxLength: 200;
            };
            readonly summary: {
                readonly type: 'string';
                readonly minLength: 1;
                readonly maxLength: 500;
            };
            readonly tags: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                    readonly minLength: 1;
                    readonly maxLength: 50;
                };
            };
            readonly git: {
                readonly type: 'array';
                readonly items: {
                    readonly type: 'string';
                };
            };
            readonly contact: {
                readonly type: 'object';
                readonly nodeTypeName: "EntityContact";
                readonly properties: {
                    readonly slack: {
                        readonly type: 'object';
                        readonly nodeTypeName: "EntitySlackContact";
                        readonly properties: {
                            readonly channels: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'object';
                                    readonly nodeTypeName: "EntitySlackChannel";
                                    readonly properties: {
                                        readonly name: {
                                            readonly type: 'string';
                                            readonly minLength: 2;
                                            readonly maxLength: 150;
                                        };
                                        readonly url: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly required: readonly ["name"];
                                    readonly additionalProperties: false;
                                };
                            };
                        };
                        readonly required: readonly ["channels"];
                        readonly additionalProperties: false;
                    };
                };
                readonly additionalProperties: false;
            };
            readonly links: {
                readonly type: 'array';
                readonly nodeTypeName: "EntityLinkList";
                readonly items: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntityLink";
                    readonly properties: {
                        readonly label: {
                            readonly type: 'string';
                            readonly minLength: 2;
                            readonly maxLength: 150;
                        };
                        readonly url: {
                            readonly type: 'string';
                        };
                    };
                    readonly required: readonly ["label", "url"];
                    readonly additionalProperties: false;
                };
            };
            readonly relations: {
                readonly type: 'array';
                readonly nodeTypeName: "EntityRelationList";
                readonly items: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntityRelation";
                    readonly properties: {
                        readonly type: {
                            readonly type: 'string';
                            readonly enum: readonly ["partOf", "hasParts", "creates", "createdBy", "owns", "ownedBy", "implements", "implementedBy", "dependsOn", "dependencyOf", "uses", "usedBy", "produces", "consumes", "linksTo", "supersedes", "supersededBy", "compatibleWith", "extends", "extendedBy", "relatesTo", "hasMember", "memberOf", "triggers", "triggeredBy", "returns", "returnedBy"];
                        };
                        readonly key: {
                            readonly type: 'string';
                            readonly minLength: 2;
                            readonly maxLength: 100;
                        };
                        readonly version: {
                            readonly type: 'string';
                        };
                        readonly revision: {
                            readonly type: 'string';
                        };
                    };
                    readonly required: readonly ["type", "key"];
                    readonly additionalProperties: false;
                };
            };
            readonly metadata: {
                readonly type: 'object';
                readonly properties: {};
                readonly nodeTypeName: "EntityMetadata";
                readonly additionalProperties: true;
            };
            readonly type: {
                readonly type: 'string';
                readonly const: 'team';
            };
        };
        readonly required: readonly ["key", "title", "type"];
        readonly additionalProperties: false;
    }];
};
export declare const entityFileDefaultSchema: {
    readonly type: 'object';
    readonly nodeTypeName: "Entity";
    readonly properties: {
        readonly version: {
            readonly type: 'string';
        };
        readonly key: {
            readonly type: 'string';
            readonly pattern: '^[a-z0-9]+(?:-[a-z0-9]+)*$';
            readonly minLength: 2;
            readonly maxLength: 150;
        };
        readonly type: {
            readonly type: 'string';
            readonly enum: readonly ["user", "data-schema", "api-operation", "api-description", "service", "domain", "team"];
        };
        readonly title: {
            readonly type: 'string';
            readonly minLength: 2;
            readonly maxLength: 200;
        };
        readonly summary: {
            readonly type: 'string';
            readonly minLength: 1;
            readonly maxLength: 500;
        };
        readonly tags: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'string';
                readonly minLength: 1;
                readonly maxLength: 50;
            };
        };
        readonly git: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'string';
            };
        };
        readonly contact: {
            readonly type: 'object';
            readonly nodeTypeName: "EntityContact";
            readonly properties: {
                readonly slack: {
                    readonly type: 'object';
                    readonly nodeTypeName: "EntitySlackContact";
                    readonly properties: {
                        readonly channels: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'object';
                                readonly nodeTypeName: "EntitySlackChannel";
                                readonly properties: {
                                    readonly name: {
                                        readonly type: 'string';
                                        readonly minLength: 2;
                                        readonly maxLength: 150;
                                    };
                                    readonly url: {
                                        readonly type: 'string';
                                    };
                                };
                                readonly required: readonly ["name"];
                                readonly additionalProperties: false;
                            };
                        };
                    };
                    readonly required: readonly ["channels"];
                    readonly additionalProperties: false;
                };
            };
            readonly additionalProperties: false;
        };
        readonly links: {
            readonly type: 'array';
            readonly nodeTypeName: "EntityLinkList";
            readonly items: {
                readonly type: 'object';
                readonly nodeTypeName: "EntityLink";
                readonly properties: {
                    readonly label: {
                        readonly type: 'string';
                        readonly minLength: 2;
                        readonly maxLength: 150;
                    };
                    readonly url: {
                        readonly type: 'string';
                    };
                };
                readonly required: readonly ["label", "url"];
                readonly additionalProperties: false;
            };
        };
        readonly relations: {
            readonly type: 'array';
            readonly nodeTypeName: "EntityRelationList";
            readonly items: {
                readonly type: 'object';
                readonly nodeTypeName: "EntityRelation";
                readonly properties: {
                    readonly type: {
                        readonly type: 'string';
                        readonly enum: readonly ["partOf", "hasParts", "creates", "createdBy", "owns", "ownedBy", "implements", "implementedBy", "dependsOn", "dependencyOf", "uses", "usedBy", "produces", "consumes", "linksTo", "supersedes", "supersededBy", "compatibleWith", "extends", "extendedBy", "relatesTo", "hasMember", "memberOf", "triggers", "triggeredBy", "returns", "returnedBy"];
                    };
                    readonly key: {
                        readonly type: 'string';
                        readonly minLength: 2;
                        readonly maxLength: 100;
                    };
                    readonly version: {
                        readonly type: 'string';
                    };
                    readonly revision: {
                        readonly type: 'string';
                    };
                };
                readonly required: readonly ["type", "key"];
                readonly additionalProperties: false;
            };
        };
        readonly metadata: {
            readonly type: 'object';
            readonly properties: {};
            readonly nodeTypeName: "EntityMetadata";
            readonly additionalProperties: true;
        };
    };
    readonly required: readonly ["key", "title", "type"];
    readonly additionalProperties: false;
};
