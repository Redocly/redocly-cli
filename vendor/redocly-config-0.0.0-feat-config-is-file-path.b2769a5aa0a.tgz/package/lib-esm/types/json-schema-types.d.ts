/**
 * This type is a subset of JSON Schema that aligns with [json-schema-adapter](https://github.com/Redocly/redocly-cli/blob/main/packages/core/src/types/json-schema-adapter.ts)
 * which translates JSON Schema to the Redocly CLI's internal NodeType tree format.
 *
 * */
export type RedoclyConfigJSONSchema = Base & (SchemaObject | SchemaArray | SchemaString | SchemaNumber | SchemaBoolean | SchemaOneOf);
type Base = {
    $id?: string;
    type?: Type;
    description?: string;
    /** Redocly extension: link to the option's documentation page. */
    documentationLink?: string;
    /** Redocly extension: suggests a form control the schema type cannot imply on its own. */
    uiHint?: 'color' | 'file' | 'list' | 'textarea';
    /** Redocly extension: overrides the generated `NodeType` name. */
    nodeTypeName?: string;
    /** @deprecated Not supported by the `NodeType` adapter; avoid in new schemas. */
    not?: any;
};
type Type = 'object' | 'array' | 'string' | 'number' | 'integer' | 'boolean';
type SchemaObject = {
    type: 'object';
    properties?: Record<string, RedoclyConfigJSONSchema>;
    additionalProperties?: boolean | RedoclyConfigJSONSchema;
    unevaluatedProperties?: boolean | RedoclyConfigJSONSchema;
    patternProperties?: Record<string, RedoclyConfigJSONSchema>;
    required?: readonly string[];
} & SchemaOneOfFragment;
type SchemaArray = {
    type: 'array';
    items?: RedoclyConfigJSONSchema;
    minItems?: number;
    /** @deprecated Not supported by the `NodeType` adapter; avoid in new schemas. */
    uniqueItems?: boolean;
};
type SchemaString = {
    type: 'string';
    pattern?: string;
    minLength?: number;
    maxLength?: number;
    format?: 'uri' | 'email' | 'date-time' | 'uri-reference' | 'glob' | 'srcset';
    enum?: readonly (string | number | boolean | null)[];
    const?: string | number | boolean | null;
};
type SchemaNumber = {
    type: 'number' | 'integer';
    minimum?: number;
};
type SchemaBoolean = {
    type: 'boolean';
};
/** A standalone `oneOf` schema whose branches are full schemas. */
type SchemaOneOf = {
    oneOf: readonly RedoclyConfigJSONSchema[];
    discriminator?: {
        propertyName: string;
        mapping?: Record<string, RedoclyConfigJSONSchema>;
    };
};
/** A `oneOf` inside an object schema; branches only narrow `required`. */
type SchemaOneOfFragment = {
    oneOf?: readonly SchemaObjectFragment[];
    discriminator?: {
        propertyName: string;
        mapping?: Record<string, RedoclyConfigJSONSchema>;
    };
};
type SchemaObjectFragment = {
    required: readonly string[];
};
export {};
