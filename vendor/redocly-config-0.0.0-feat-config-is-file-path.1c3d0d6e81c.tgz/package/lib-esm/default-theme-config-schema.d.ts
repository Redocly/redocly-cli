export declare const themeConfigSchema: {
    readonly type: 'object';
    readonly properties: {
        /**
         * @deprecated Should use `plugins` instead
         */
        readonly imports: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'string';
            };
        };
        readonly logo: {
            readonly type: 'object';
            readonly properties: {
                readonly image: {
                    readonly type: 'string';
                    readonly format: 'uri-reference';
                    readonly uiHint: 'file';
                };
                readonly srcSet: {
                    readonly type: 'string';
                };
                readonly altText: {
                    readonly type: 'string';
                };
                readonly link: {
                    readonly type: 'string';
                };
                readonly favicon: {
                    readonly type: 'string';
                    readonly format: 'uri-reference';
                    readonly uiHint: 'file';
                };
            };
            readonly additionalProperties: false;
        };
        readonly navbar: {
            readonly type: 'object';
            readonly properties: {
                readonly hide: {
                    readonly type: 'boolean';
                };
                readonly items: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly page: {
                                readonly type: 'string';
                                readonly format: 'uri-reference';
                                readonly uiHint: 'file';
                            };
                            readonly directory: {
                                readonly type: 'string';
                                readonly format: 'uri-reference';
                                readonly uiHint: 'file';
                            };
                            readonly disconnect: {
                                readonly type: 'boolean';
                            };
                            readonly group: {
                                readonly type: 'string';
                            };
                            readonly label: {
                                readonly type: 'string';
                            };
                            readonly href: {
                                readonly type: 'string';
                            };
                            readonly external: {
                                readonly type: 'boolean';
                            };
                            readonly labelTranslationKey: {
                                readonly type: 'string';
                            };
                            readonly groupTranslationKey: {
                                readonly type: 'string';
                            };
                            readonly icon: {
                                readonly oneOf: readonly [{
                                    readonly type: 'string';
                                }, {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly srcSet: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly required: readonly ["srcSet"];
                                }];
                            };
                            readonly separator: {
                                readonly type: 'string';
                            };
                            readonly separatorLine: {
                                readonly type: 'boolean';
                            };
                            readonly linePosition: {
                                readonly type: 'string';
                                readonly enum: readonly ["top", "bottom"];
                            };
                            readonly version: {
                                readonly type: 'string';
                            };
                            readonly menuStyle: {
                                readonly type: 'string';
                                readonly enum: readonly ["drilldown"];
                            };
                            readonly expanded: {
                                readonly type: 'string';
                                readonly const: 'always';
                            };
                            readonly selectFirstItemOnExpand: {
                                readonly type: 'boolean';
                            };
                            readonly flatten: {
                                readonly type: 'boolean';
                            };
                            readonly includeByMetadata: {
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'string';
                                    };
                                };
                            };
                            readonly linkedSidebars: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'string';
                                    readonly format: 'uri-reference';
                                };
                            };
                            readonly rbac: {
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProps: {
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly items: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly page: {
                                            readonly type: 'string';
                                            readonly format: 'uri-reference';
                                            readonly uiHint: 'file';
                                        };
                                        readonly directory: {
                                            readonly type: 'string';
                                            readonly format: 'uri-reference';
                                            readonly uiHint: 'file';
                                        };
                                        readonly disconnect: {
                                            readonly type: 'boolean';
                                        };
                                        readonly group: {
                                            readonly type: 'string';
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly href: {
                                            readonly type: 'string';
                                        };
                                        readonly external: {
                                            readonly type: 'boolean';
                                        };
                                        readonly labelTranslationKey: {
                                            readonly type: 'string';
                                        };
                                        readonly groupTranslationKey: {
                                            readonly type: 'string';
                                        };
                                        readonly icon: {
                                            readonly oneOf: readonly [{
                                                readonly type: 'string';
                                            }, {
                                                readonly type: 'object';
                                                readonly properties: {
                                                    readonly srcSet: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                                readonly required: readonly ["srcSet"];
                                            }];
                                        };
                                        readonly separator: {
                                            readonly type: 'string';
                                        };
                                        readonly separatorLine: {
                                            readonly type: 'boolean';
                                        };
                                        readonly linePosition: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["top", "bottom"];
                                        };
                                        readonly version: {
                                            readonly type: 'string';
                                        };
                                        readonly menuStyle: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["drilldown"];
                                        };
                                        readonly expanded: {
                                            readonly type: 'string';
                                            readonly const: 'always';
                                        };
                                        readonly selectFirstItemOnExpand: {
                                            readonly type: 'boolean';
                                        };
                                        readonly flatten: {
                                            readonly type: 'boolean';
                                        };
                                        readonly includeByMetadata: {
                                            readonly type: 'object';
                                            readonly additionalProperties: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly linkedSidebars: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                                readonly format: 'uri-reference';
                                            };
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'object';
                                                readonly additionalProperties: true;
                                            };
                                        };
                                        readonly rbac: {
                                            readonly type: 'object';
                                            readonly additionalProperties: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProps: {
                                            readonly type: 'object';
                                            readonly additionalProperties: true;
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };
            readonly additionalProperties: false;
        };
        readonly products: {
            readonly type: 'object';
            readonly additionalProperties: {
                readonly type: 'object';
                readonly properties: {
                    readonly name: {
                        readonly type: 'string';
                    };
                    readonly icon: {
                        readonly type: 'string';
                        readonly format: 'uri-reference';
                    };
                    readonly folder: {
                        readonly type: 'string';
                        readonly format: 'uri-reference';
                    };
                };
                readonly additionalProperties: false;
                readonly required: readonly ["name", "folder"];
            };
        };
        readonly footer: {
            readonly type: 'object';
            readonly properties: {
                readonly hide: {
                    readonly type: 'boolean';
                };
                readonly items: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly page: {
                                readonly type: 'string';
                                readonly format: 'uri-reference';
                                readonly uiHint: 'file';
                            };
                            readonly directory: {
                                readonly type: 'string';
                                readonly format: 'uri-reference';
                                readonly uiHint: 'file';
                            };
                            readonly disconnect: {
                                readonly type: 'boolean';
                            };
                            readonly group: {
                                readonly type: 'string';
                            };
                            readonly label: {
                                readonly type: 'string';
                            };
                            readonly href: {
                                readonly type: 'string';
                            };
                            readonly external: {
                                readonly type: 'boolean';
                            };
                            readonly labelTranslationKey: {
                                readonly type: 'string';
                            };
                            readonly groupTranslationKey: {
                                readonly type: 'string';
                            };
                            readonly icon: {
                                readonly oneOf: readonly [{
                                    readonly type: 'string';
                                }, {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly srcSet: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly required: readonly ["srcSet"];
                                }];
                            };
                            readonly separator: {
                                readonly type: 'string';
                            };
                            readonly separatorLine: {
                                readonly type: 'boolean';
                            };
                            readonly linePosition: {
                                readonly type: 'string';
                                readonly enum: readonly ["top", "bottom"];
                            };
                            readonly version: {
                                readonly type: 'string';
                            };
                            readonly menuStyle: {
                                readonly type: 'string';
                                readonly enum: readonly ["drilldown"];
                            };
                            readonly expanded: {
                                readonly type: 'string';
                                readonly const: 'always';
                            };
                            readonly selectFirstItemOnExpand: {
                                readonly type: 'boolean';
                            };
                            readonly flatten: {
                                readonly type: 'boolean';
                            };
                            readonly includeByMetadata: {
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'string';
                                    };
                                };
                            };
                            readonly linkedSidebars: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'string';
                                    readonly format: 'uri-reference';
                                };
                            };
                            readonly rbac: {
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProps: {
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly items: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly page: {
                                            readonly type: 'string';
                                            readonly format: 'uri-reference';
                                            readonly uiHint: 'file';
                                        };
                                        readonly directory: {
                                            readonly type: 'string';
                                            readonly format: 'uri-reference';
                                            readonly uiHint: 'file';
                                        };
                                        readonly disconnect: {
                                            readonly type: 'boolean';
                                        };
                                        readonly group: {
                                            readonly type: 'string';
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly href: {
                                            readonly type: 'string';
                                        };
                                        readonly external: {
                                            readonly type: 'boolean';
                                        };
                                        readonly labelTranslationKey: {
                                            readonly type: 'string';
                                        };
                                        readonly groupTranslationKey: {
                                            readonly type: 'string';
                                        };
                                        readonly icon: {
                                            readonly oneOf: readonly [{
                                                readonly type: 'string';
                                            }, {
                                                readonly type: 'object';
                                                readonly properties: {
                                                    readonly srcSet: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                                readonly required: readonly ["srcSet"];
                                            }];
                                        };
                                        readonly separator: {
                                            readonly type: 'string';
                                        };
                                        readonly separatorLine: {
                                            readonly type: 'boolean';
                                        };
                                        readonly linePosition: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["top", "bottom"];
                                        };
                                        readonly version: {
                                            readonly type: 'string';
                                        };
                                        readonly menuStyle: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["drilldown"];
                                        };
                                        readonly expanded: {
                                            readonly type: 'string';
                                            readonly const: 'always';
                                        };
                                        readonly selectFirstItemOnExpand: {
                                            readonly type: 'boolean';
                                        };
                                        readonly flatten: {
                                            readonly type: 'boolean';
                                        };
                                        readonly includeByMetadata: {
                                            readonly type: 'object';
                                            readonly additionalProperties: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly linkedSidebars: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                                readonly format: 'uri-reference';
                                            };
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'object';
                                                readonly additionalProperties: true;
                                            };
                                        };
                                        readonly rbac: {
                                            readonly type: 'object';
                                            readonly additionalProperties: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProps: {
                                            readonly type: 'object';
                                            readonly additionalProperties: true;
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
                readonly copyrightText: {
                    readonly type: 'string';
                    readonly uiHint: 'textarea';
                };
                readonly logo: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                    };
                    readonly additionalProperties: false;
                };
            };
            readonly additionalProperties: false;
        };
        readonly sidebar: {
            readonly type: 'object';
            readonly properties: {
                readonly hide: {
                    readonly type: 'boolean';
                };
                readonly separatorLine: {
                    readonly type: 'boolean';
                };
                readonly linePosition: {
                    readonly type: 'string';
                    readonly enum: readonly ["top", "bottom"];
                };
            };
            readonly additionalProperties: false;
        };
        readonly scripts: {
            readonly type: 'object';
            readonly properties: {
                readonly head: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly src: {
                                readonly type: 'string';
                                readonly format: 'uri-reference';
                            };
                            readonly async: {
                                readonly type: 'boolean';
                            };
                            readonly crossorigin: {
                                readonly type: 'string';
                            };
                            readonly defer: {
                                readonly type: 'boolean';
                            };
                            readonly fetchpriority: {
                                readonly type: 'string';
                            };
                            readonly integrity: {
                                readonly type: 'string';
                            };
                            readonly module: {
                                readonly type: 'boolean';
                            };
                            readonly nomodule: {
                                readonly type: 'boolean';
                            };
                            readonly nonce: {
                                readonly type: 'string';
                            };
                            readonly referrerpolicy: {
                                readonly type: 'string';
                            };
                            readonly type: {
                                readonly type: 'string';
                            };
                            readonly consent: {
                                readonly type: 'string';
                                readonly enum: readonly ["analytics", "marketing"];
                            };
                        };
                        readonly required: readonly ["src"];
                        readonly additionalProperties: true;
                    };
                };
                readonly body: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly src: {
                                readonly type: 'string';
                                readonly format: 'uri-reference';
                            };
                            readonly async: {
                                readonly type: 'boolean';
                            };
                            readonly crossorigin: {
                                readonly type: 'string';
                            };
                            readonly defer: {
                                readonly type: 'boolean';
                            };
                            readonly fetchpriority: {
                                readonly type: 'string';
                            };
                            readonly integrity: {
                                readonly type: 'string';
                            };
                            readonly module: {
                                readonly type: 'boolean';
                            };
                            readonly nomodule: {
                                readonly type: 'boolean';
                            };
                            readonly nonce: {
                                readonly type: 'string';
                            };
                            readonly referrerpolicy: {
                                readonly type: 'string';
                            };
                            readonly type: {
                                readonly type: 'string';
                            };
                            readonly consent: {
                                readonly type: 'string';
                                readonly enum: readonly ["analytics", "marketing"];
                            };
                        };
                        readonly required: readonly ["src"];
                        readonly additionalProperties: true;
                    };
                };
            };
            readonly additionalProperties: false;
        };
        readonly links: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'object';
                readonly properties: {
                    readonly href: {
                        readonly type: 'string';
                        readonly format: 'uri-reference';
                    };
                    readonly as: {
                        readonly type: 'string';
                    };
                    readonly crossorigin: {
                        readonly type: 'string';
                    };
                    readonly fetchpriority: {
                        readonly type: 'string';
                    };
                    readonly hreflang: {
                        readonly type: 'string';
                    };
                    readonly imagesizes: {
                        readonly type: 'string';
                    };
                    readonly imagesrcset: {
                        readonly type: 'string';
                    };
                    readonly integrity: {
                        readonly type: 'string';
                    };
                    readonly media: {
                        readonly type: 'string';
                    };
                    readonly prefetch: {
                        readonly type: 'string';
                    };
                    readonly referrerpolicy: {
                        readonly type: 'string';
                    };
                    readonly rel: {
                        readonly type: 'string';
                    };
                    readonly sizes: {
                        readonly type: 'string';
                    };
                    readonly title: {
                        readonly type: 'string';
                    };
                    readonly type: {
                        readonly type: 'string';
                    };
                };
                readonly required: readonly ["href"];
                readonly additionalProperties: true;
            };
        };
        readonly feedback: {
            readonly type: 'object';
            readonly properties: {
                readonly hide: {
                    readonly type: 'boolean';
                };
                readonly type: {
                    readonly type: 'string';
                    readonly enum: readonly ["rating", "sentiment", "comment", "reasons", "mood", "scale"];
                };
                readonly settings: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly label: {
                            readonly type: 'string';
                        };
                        readonly submitText: {
                            readonly type: 'string';
                        };
                        readonly buttonText: {
                            readonly type: 'string';
                        };
                        readonly component: {
                            readonly type: 'string';
                            readonly enum: readonly ["radio", "checkbox"];
                        };
                        readonly items: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'string';
                            };
                            readonly minItems: 1;
                        };
                        readonly leftScaleLabel: {
                            readonly type: 'string';
                        };
                        readonly rightScaleLabel: {
                            readonly type: 'string';
                        };
                        readonly reasons: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly hide: {
                                    readonly type: 'boolean';
                                };
                                readonly component: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["radio", "checkbox"];
                                };
                                readonly label: {
                                    readonly type: 'string';
                                };
                                readonly items: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'string';
                                    };
                                };
                                readonly like: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly component: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["radio", "checkbox"];
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly dislike: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly component: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["radio", "checkbox"];
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly satisfied: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly component: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["radio", "checkbox"];
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly neutral: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly component: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["radio", "checkbox"];
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly dissatisfied: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly component: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["radio", "checkbox"];
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                            };
                            readonly additionalProperties: false;
                        };
                        readonly comment: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly hide: {
                                    readonly type: 'boolean';
                                };
                                readonly label: {
                                    readonly type: 'string';
                                };
                                readonly likeLabel: {
                                    readonly type: 'string';
                                };
                                readonly dislikeLabel: {
                                    readonly type: 'string';
                                };
                                readonly satisfiedLabel: {
                                    readonly type: 'string';
                                };
                                readonly neutralLabel: {
                                    readonly type: 'string';
                                };
                                readonly dissatisfiedLabel: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProperties: false;
                        };
                        readonly optionalEmail: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly hide: {
                                    readonly type: 'boolean';
                                };
                                readonly label: {
                                    readonly type: 'string';
                                };
                                readonly placeholder: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProperties: false;
                        };
                    };
                    readonly additionalProperties: false;
                };
            };
            readonly additionalProperties: false;
        };
        readonly search: {
            readonly type: 'object';
            readonly properties: {
                readonly hide: {
                    readonly type: 'boolean';
                };
                readonly engine: {
                    readonly type: 'string';
                    readonly enum: readonly ["flexsearch", "typesense"];
                };
                readonly ai: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                        readonly suggestions: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'string';
                            };
                        };
                        readonly prompt: {
                            readonly type: 'string';
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly filters: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                        readonly facets: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'object';
                                readonly required: readonly ["name", "field", "type"];
                                readonly properties: {
                                    readonly name: {
                                        readonly type: 'string';
                                    };
                                    readonly field: {
                                        readonly type: 'string';
                                    };
                                    readonly type: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["multi-select", "select", "tags"];
                                    };
                                };
                                readonly additionalProperties: false;
                            };
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly placement: {
                    readonly type: 'string';
                };
                readonly shortcuts: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                    };
                };
                readonly suggestedPages: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly page: {
                                readonly type: 'string';
                                readonly format: 'uri-reference';
                                readonly uiHint: 'file';
                            };
                            readonly label: {
                                readonly type: 'string';
                            };
                            readonly labelTranslationKey: {
                                readonly type: 'string';
                            };
                        };
                        readonly required: readonly ["page"];
                    };
                };
            };
            readonly additionalProperties: false;
        };
        readonly aiAssistant: {
            readonly type: 'object';
            readonly properties: {
                readonly hide: {
                    readonly type: 'boolean';
                };
                readonly suggestions: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                    };
                };
                readonly prompt: {
                    readonly type: 'string';
                    readonly uiHint: 'textarea';
                };
                readonly trigger: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                        readonly inputType: {
                            readonly type: 'string';
                            readonly enum: readonly ["button", "icon"];
                        };
                        readonly inputIcon: {
                            readonly type: 'string';
                            readonly enum: readonly ["chat", "sparkles", "redocly"];
                        };
                    };
                    readonly additionalProperties: false;
                };
            };
            readonly additionalProperties: false;
        };
        readonly colorMode: {
            readonly type: 'object';
            readonly properties: {
                readonly hide: {
                    readonly type: 'boolean';
                };
                readonly ignoreDetection: {
                    readonly type: 'boolean';
                };
                readonly modes: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                    };
                };
            };
            readonly additionalProperties: false;
        };
        readonly palette: {
            readonly type: 'string';
            readonly enum: readonly ["slate", "pink", "coral", "amber", "jade", "cyan", "ocean", "indigo", "iris"];
        };
        readonly navigation: {
            readonly type: 'object';
            readonly properties: {
                readonly nextButton: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                        readonly text: {
                            readonly type: 'string';
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly previousButton: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                        readonly text: {
                            readonly type: 'string';
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly actions: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                        readonly items: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'string';
                                readonly enum: readonly ["copy", "view", "chatgpt", "claude", "docs-mcp-cursor", "docs-mcp-vscode"];
                            };
                        };
                    };
                    readonly additionalProperties: false;
                };
            };
            readonly additionalProperties: false;
        };
        readonly codeSnippet: {
            readonly type: 'object';
            readonly properties: {
                readonly elementFormat: {
                    readonly type: 'string';
                };
                readonly copy: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly report: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                        readonly tooltipText: {
                            readonly type: 'string';
                        };
                        readonly buttonText: {
                            readonly type: 'string';
                        };
                        readonly label: {
                            readonly type: 'string';
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly expand: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly collapse: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                    };
                    readonly additionalProperties: false;
                };
            };
            readonly additionalProperties: false;
        };
        readonly markdown: {
            readonly type: 'object';
            readonly properties: {
                readonly frontMatterKeysToResolve: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                    };
                };
                readonly partialsFolders: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                        readonly format: 'glob';
                    };
                };
                readonly lastUpdatedBlock: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                        readonly format: {
                            readonly type: 'string';
                            readonly enum: readonly ["timeago", "iso", "long", "short"];
                        };
                        readonly locale: {
                            readonly type: 'string';
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly toc: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                        readonly header: {
                            readonly type: 'string';
                        };
                        readonly depth: {
                            readonly type: 'integer';
                            readonly minimum: 1;
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly editPage: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                        readonly baseUrl: {
                            readonly type: 'string';
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly template: {
                    readonly type: 'object';
                    readonly uiHint: 'list';
                    readonly additionalProperties: {
                        readonly type: 'string';
                    };
                };
            };
            readonly additionalProperties: false;
        };
        readonly openapi: {
            readonly type: 'object';
            readonly additionalProperties: false;
            readonly properties: {
                readonly licenseKey: {
                    readonly type: 'string';
                };
                readonly hideLoading: {
                    readonly type: 'boolean';
                };
                readonly feedback: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                        readonly type: {
                            readonly type: 'string';
                            readonly enum: readonly ["rating", "sentiment", "comment", "reasons", "mood", "scale"];
                        };
                        readonly settings: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly label: {
                                    readonly type: 'string';
                                };
                                readonly submitText: {
                                    readonly type: 'string';
                                };
                                readonly buttonText: {
                                    readonly type: 'string';
                                };
                                readonly component: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["radio", "checkbox"];
                                };
                                readonly items: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'string';
                                    };
                                    readonly minItems: 1;
                                };
                                readonly leftScaleLabel: {
                                    readonly type: 'string';
                                };
                                readonly rightScaleLabel: {
                                    readonly type: 'string';
                                };
                                readonly reasons: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly component: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["radio", "checkbox"];
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly like: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                        readonly dislike: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                        readonly satisfied: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                        readonly neutral: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                        readonly dissatisfied: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly comment: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly likeLabel: {
                                            readonly type: 'string';
                                        };
                                        readonly dislikeLabel: {
                                            readonly type: 'string';
                                        };
                                        readonly satisfiedLabel: {
                                            readonly type: 'string';
                                        };
                                        readonly neutralLabel: {
                                            readonly type: 'string';
                                        };
                                        readonly dissatisfiedLabel: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly optionalEmail: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly placeholder: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                            };
                            readonly additionalProperties: false;
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly hideReplay: {
                    readonly type: 'boolean';
                };
                readonly oAuth2RedirectURI: {
                    readonly type: 'string';
                };
                readonly corsProxyUrl: {
                    readonly type: 'string';
                };
                readonly sortRequiredPropsFirst: {
                    readonly type: 'boolean';
                };
                readonly sanitize: {
                    readonly type: 'boolean';
                };
                readonly hideDownloadButtons: {
                    readonly type: 'boolean';
                };
                readonly downloadUrls: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly title: {
                                readonly type: 'string';
                            };
                            readonly url: {
                                readonly type: 'string';
                            };
                        };
                        readonly required: readonly ["url"];
                        readonly additionalProperties: false;
                    };
                };
                readonly onlyRequiredInSamples: {
                    readonly type: 'boolean';
                };
                readonly generatedSamplesMaxDepth: {
                    readonly oneOf: readonly [{
                        readonly type: 'number';
                    }, {
                        readonly type: 'string';
                    }];
                };
                readonly showExtensions: {
                    readonly oneOf: readonly [{
                        readonly type: 'boolean';
                    }, {
                        readonly type: 'string';
                    }, {
                        readonly type: 'array';
                        readonly items: {
                            readonly type: 'string';
                        };
                    }];
                };
                readonly hideSchemaTitles: {
                    readonly type: 'boolean';
                };
                readonly jsonSamplesExpandLevel: {
                    readonly oneOf: readonly [{
                        readonly type: 'number';
                    }, {
                        readonly type: 'string';
                    }];
                };
                readonly schemasExpansionLevel: {
                    readonly oneOf: readonly [{
                        readonly type: 'number';
                    }, {
                        readonly type: 'string';
                    }];
                };
                readonly mockServer: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly url: {
                            readonly type: 'string';
                        };
                        readonly position: {
                            readonly type: 'string';
                            readonly enum: readonly ["first", "last", "replace", "off"];
                        };
                        readonly description: {
                            readonly type: 'string';
                        };
                    };
                };
                readonly maxDisplayedEnumValues: {
                    readonly type: 'number';
                };
                readonly schemaDefinitionsTagName: {
                    readonly type: 'string';
                };
                readonly layout: {
                    readonly type: 'string';
                    readonly enum: readonly ["stacked", "three-panel"];
                };
                readonly hideInfoMetadata: {
                    readonly type: 'boolean';
                };
                readonly events: {
                    readonly type: 'object';
                };
                readonly skipBundle: {
                    readonly type: 'boolean';
                };
                readonly routingBasePath: {
                    readonly type: 'string';
                };
                readonly codeSamples: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly languages: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'object';
                                readonly properties: {
                                    readonly lang: {
                                        readonly type: 'string';
                                    };
                                    readonly label: {
                                        readonly type: 'string';
                                    };
                                    readonly options: {
                                        readonly type: 'object';
                                        readonly properties: {
                                            readonly indent: {
                                                readonly type: 'string';
                                            };
                                            readonly withImports: {
                                                readonly type: 'boolean';
                                            };
                                            readonly withComments: {
                                                readonly type: 'boolean';
                                            };
                                            readonly binary: {
                                                readonly type: 'boolean';
                                            };
                                            readonly credentials: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["omit", "same-origin", "include"];
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly required: readonly ["lang"];
                                readonly additionalProperties: false;
                            };
                        };
                        readonly skipOptionalParameters: {
                            readonly type: 'boolean';
                        };
                        readonly withOAuth2Call: {
                            readonly type: 'boolean';
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly ignoreNamedSchemas: {
                    readonly oneOf: readonly [{
                        readonly type: 'array';
                        readonly items: {
                            readonly type: 'string';
                        };
                    }, {
                        readonly type: 'string';
                    }];
                };
                readonly hidePropertiesPrefix: {
                    readonly type: 'boolean';
                };
                readonly excludeFromSearch: {
                    readonly type: 'boolean';
                };
                readonly showSchemaCatalogLinks: {
                    readonly type: 'boolean';
                };
                readonly theme: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly breakpoints: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly small: {
                                    readonly type: 'string';
                                };
                                readonly medium: {
                                    readonly type: 'string';
                                };
                                readonly large: {
                                    readonly type: 'string';
                                };
                            };
                        };
                        readonly codeBlock: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly backgroundColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly borderRadius: {
                                    readonly type: 'string';
                                };
                                readonly tokens: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly fontFamily: {
                                            readonly type: 'string';
                                        };
                                        readonly fontSize: {
                                            readonly type: 'string';
                                        };
                                        readonly fontWeight: {
                                            readonly type: 'string';
                                        };
                                        readonly lineHeight: {
                                            readonly type: 'string';
                                        };
                                        readonly color: {
                                            readonly type: 'string';
                                            readonly uiHint: 'color';
                                        };
                                    };
                                };
                            };
                        };
                        readonly colors: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly accent: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly main: {
                                            readonly type: 'string';
                                        };
                                        readonly light: {
                                            readonly type: 'string';
                                        };
                                        readonly dark: {
                                            readonly type: 'string';
                                        };
                                        readonly contrastText: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly border: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly main: {
                                            readonly type: 'string';
                                        };
                                        readonly light: {
                                            readonly type: 'string';
                                        };
                                        readonly dark: {
                                            readonly type: 'string';
                                        };
                                        readonly contrastText: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly error: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly main: {
                                            readonly type: 'string';
                                        };
                                        readonly light: {
                                            readonly type: 'string';
                                        };
                                        readonly dark: {
                                            readonly type: 'string';
                                        };
                                        readonly contrastText: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly http: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly basic: {
                                            readonly type: 'string';
                                        };
                                        readonly delete: {
                                            readonly type: 'string';
                                        };
                                        readonly get: {
                                            readonly type: 'string';
                                        };
                                        readonly head: {
                                            readonly type: 'string';
                                        };
                                        readonly link: {
                                            readonly type: 'string';
                                        };
                                        readonly options: {
                                            readonly type: 'string';
                                        };
                                        readonly patch: {
                                            readonly type: 'string';
                                        };
                                        readonly post: {
                                            readonly type: 'string';
                                        };
                                        readonly put: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly primary: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly main: {
                                            readonly type: 'string';
                                        };
                                        readonly light: {
                                            readonly type: 'string';
                                        };
                                        readonly dark: {
                                            readonly type: 'string';
                                        };
                                        readonly contrastText: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly responses: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly error: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly backgroundColor: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                                readonly borderColor: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                                readonly color: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                                readonly tabTextColor: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                            };
                                        };
                                        readonly info: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly backgroundColor: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                                readonly borderColor: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                                readonly color: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                                readonly tabTextColor: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                            };
                                        };
                                        readonly redirect: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly backgroundColor: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                                readonly borderColor: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                                readonly color: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                                readonly tabTextColor: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                            };
                                        };
                                        readonly success: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly backgroundColor: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                                readonly borderColor: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                                readonly color: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                                readonly tabTextColor: {
                                                    readonly type: 'string';
                                                    readonly uiHint: 'color';
                                                };
                                            };
                                        };
                                    };
                                };
                                readonly secondary: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly main: {
                                            readonly type: 'string';
                                        };
                                        readonly light: {
                                            readonly type: 'string';
                                        };
                                        readonly dark: {
                                            readonly type: 'string';
                                        };
                                        readonly contrastText: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly success: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly main: {
                                            readonly type: 'string';
                                        };
                                        readonly light: {
                                            readonly type: 'string';
                                        };
                                        readonly dark: {
                                            readonly type: 'string';
                                        };
                                        readonly contrastText: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly text: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly primary: {
                                            readonly type: 'string';
                                        };
                                        readonly secondary: {
                                            readonly type: 'string';
                                        };
                                        readonly light: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly tonalOffset: {
                                    readonly type: 'number';
                                };
                                readonly warning: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly main: {
                                            readonly type: 'string';
                                        };
                                        readonly light: {
                                            readonly type: 'string';
                                        };
                                        readonly dark: {
                                            readonly type: 'string';
                                        };
                                        readonly contrastText: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                            };
                        };
                        readonly components: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly buttons: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly fontFamily: {
                                            readonly type: 'string';
                                        };
                                        readonly fontSize: {
                                            readonly type: 'string';
                                        };
                                        readonly fontWeight: {
                                            readonly type: 'string';
                                        };
                                        readonly lineHeight: {
                                            readonly type: 'string';
                                        };
                                        readonly borderRadius: {
                                            readonly type: 'string';
                                        };
                                        readonly hoverStyle: {
                                            readonly type: 'string';
                                        };
                                        readonly boxShadow: {
                                            readonly type: 'string';
                                        };
                                        readonly hoverBoxShadow: {
                                            readonly type: 'string';
                                        };
                                        readonly sizes: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly small: {
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly fontSize: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly padding: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly minWidth: {
                                                            readonly type: 'string';
                                                        };
                                                    };
                                                };
                                                readonly medium: {
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly fontSize: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly padding: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly minWidth: {
                                                            readonly type: 'string';
                                                        };
                                                    };
                                                };
                                                readonly large: {
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly fontSize: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly padding: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly minWidth: {
                                                            readonly type: 'string';
                                                        };
                                                    };
                                                };
                                                readonly xlarge: {
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly fontSize: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly padding: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly minWidth: {
                                                            readonly type: 'string';
                                                        };
                                                    };
                                                };
                                            };
                                        };
                                    };
                                };
                                readonly httpBadges: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly fontFamily: {
                                            readonly type: 'string';
                                        };
                                        readonly fontSize: {
                                            readonly type: 'string';
                                        };
                                        readonly fontWeight: {
                                            readonly type: 'string';
                                        };
                                        readonly lineHeight: {
                                            readonly type: 'string';
                                        };
                                        readonly borderRadius: {
                                            readonly type: 'string';
                                        };
                                        readonly color: {
                                            readonly type: 'string';
                                            readonly uiHint: 'color';
                                        };
                                        readonly sizes: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly medium: {
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly fontFamily: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly fontSize: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly fontWeight: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly lineHeight: {
                                                            readonly type: 'string';
                                                        };
                                                    };
                                                };
                                                readonly small: {
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly fontFamily: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly fontSize: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly fontWeight: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly lineHeight: {
                                                            readonly type: 'string';
                                                        };
                                                    };
                                                };
                                            };
                                        };
                                    };
                                };
                                readonly layoutControls: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly top: {
                                            readonly type: 'string';
                                        };
                                        readonly width: {
                                            readonly type: 'string';
                                        };
                                        readonly height: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly panels: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly borderRadius: {
                                            readonly type: 'string';
                                        };
                                        readonly backgroundColor: {
                                            readonly type: 'string';
                                            readonly uiHint: 'color';
                                        };
                                    };
                                };
                                readonly tryItButton: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly fullWidth: {
                                            readonly type: 'boolean';
                                        };
                                    };
                                };
                                readonly tryItSendButton: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly fullWidth: {
                                            readonly type: 'boolean';
                                        };
                                    };
                                };
                            };
                        };
                        readonly layout: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly showDarkRightPanel: {
                                    readonly type: 'boolean';
                                };
                                readonly stacked: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly maxWidth: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly small: {
                                                    readonly type: 'string';
                                                };
                                                readonly medium: {
                                                    readonly type: 'string';
                                                };
                                                readonly large: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                    };
                                };
                                readonly 'three-panel': {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly maxWidth: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly small: {
                                                    readonly type: 'string';
                                                };
                                                readonly medium: {
                                                    readonly type: 'string';
                                                };
                                                readonly large: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly middlePanelMaxWidth: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly small: {
                                                    readonly type: 'string';
                                                };
                                                readonly medium: {
                                                    readonly type: 'string';
                                                };
                                                readonly large: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                    };
                                };
                            };
                        };
                        readonly logo: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly gutter: {
                                    readonly type: 'string';
                                };
                                readonly maxHeight: {
                                    readonly type: 'string';
                                };
                                readonly maxWidth: {
                                    readonly type: 'string';
                                };
                            };
                        };
                        readonly fab: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly backgroundColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly color: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                            };
                        };
                        readonly overrides: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly DownloadButton: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly custom: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly NextSectionButton: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly custom: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                            };
                        };
                        readonly rightPanel: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly backgroundColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly panelBackgroundColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly panelControlsBackgroundColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly showAtBreakpoint: {
                                    readonly type: 'string';
                                };
                                readonly textColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly width: {
                                    readonly type: 'string';
                                };
                            };
                        };
                        readonly schema: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly breakFieldNames: {
                                    readonly type: 'boolean';
                                };
                                readonly caretColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly caretSize: {
                                    readonly type: 'string';
                                };
                                readonly constraints: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly backgroundColor: {
                                            readonly type: 'string';
                                            readonly uiHint: 'color';
                                        };
                                        readonly border: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly defaultDetailsWidth: {
                                    readonly type: 'string';
                                };
                                readonly examples: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly backgroundColor: {
                                            readonly type: 'string';
                                            readonly uiHint: 'color';
                                        };
                                        readonly border: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly labelsTextSize: {
                                    readonly type: 'string';
                                };
                                readonly linesColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly nestedBackground: {
                                    readonly type: 'string';
                                };
                                readonly nestingSpacing: {
                                    readonly type: 'string';
                                };
                                readonly requireLabelColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly typeNameColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly typeTitleColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                            };
                        };
                        readonly shape: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly borderRadius: {
                                    readonly type: 'string';
                                };
                            };
                        };
                        readonly sidebar: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly fontFamily: {
                                    readonly type: 'string';
                                };
                                readonly fontSize: {
                                    readonly type: 'string';
                                };
                                readonly fontWeight: {
                                    readonly type: 'string';
                                };
                                readonly lineHeight: {
                                    readonly type: 'string';
                                };
                                readonly activeBgColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly activeTextColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly backgroundColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly borderRadius: {
                                    readonly type: 'string';
                                };
                                readonly breakPath: {
                                    readonly type: 'boolean';
                                };
                                readonly caretColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly caretSize: {
                                    readonly type: 'string';
                                };
                                readonly groupItems: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly subItemsColor: {
                                            readonly type: 'string';
                                            readonly uiHint: 'color';
                                        };
                                        readonly textTransform: {
                                            readonly type: 'string';
                                        };
                                        readonly fontWeight: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly level1items: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly subItemsColor: {
                                            readonly type: 'string';
                                            readonly uiHint: 'color';
                                        };
                                        readonly textTransform: {
                                            readonly type: 'string';
                                        };
                                        readonly fontWeight: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly rightLineColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly separatorLabelColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly showAtBreakpoint: {
                                    readonly type: 'string';
                                };
                                readonly spacing: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly unit: {
                                            readonly type: 'number';
                                        };
                                        readonly paddingHorizontal: {
                                            readonly type: 'string';
                                        };
                                        readonly paddingVertical: {
                                            readonly type: 'string';
                                        };
                                        readonly offsetTop: {
                                            readonly type: 'string';
                                        };
                                        readonly offsetLeft: {
                                            readonly type: 'string';
                                        };
                                        readonly offsetNesting: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly textColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                                readonly width: {
                                    readonly type: 'string';
                                };
                            };
                        };
                        readonly spacing: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly sectionHorizontal: {
                                    readonly type: 'number';
                                };
                                readonly sectionVertical: {
                                    readonly type: 'number';
                                };
                                readonly unit: {
                                    readonly type: 'number';
                                };
                            };
                        };
                        readonly typography: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly fontFamily: {
                                    readonly type: 'string';
                                };
                                readonly fontSize: {
                                    readonly type: 'string';
                                };
                                readonly fontWeight: {
                                    readonly type: 'string';
                                };
                                readonly code: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly fontFamily: {
                                            readonly type: 'string';
                                        };
                                        readonly fontSize: {
                                            readonly type: 'string';
                                        };
                                        readonly fontWeight: {
                                            readonly type: 'string';
                                        };
                                        readonly lineHeight: {
                                            readonly type: 'string';
                                        };
                                        readonly backgroundColor: {
                                            readonly type: 'string';
                                            readonly uiHint: 'color';
                                        };
                                        readonly color: {
                                            readonly type: 'string';
                                            readonly uiHint: 'color';
                                        };
                                        readonly wordBreak: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["break-all", "break-word", "keep-all", "normal", "revert", "unset", "inherit", "initial"];
                                        };
                                        readonly wrap: {
                                            readonly type: 'boolean';
                                        };
                                    };
                                };
                                readonly fieldName: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly fontFamily: {
                                            readonly type: 'string';
                                        };
                                        readonly fontSize: {
                                            readonly type: 'string';
                                        };
                                        readonly fontWeight: {
                                            readonly type: 'string';
                                        };
                                        readonly lineHeight: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly fontWeightBold: {
                                    readonly type: 'string';
                                };
                                readonly fontWeightLight: {
                                    readonly type: 'string';
                                };
                                readonly fontWeightRegular: {
                                    readonly type: 'string';
                                };
                                readonly heading1: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly fontFamily: {
                                            readonly type: 'string';
                                        };
                                        readonly fontSize: {
                                            readonly type: 'string';
                                        };
                                        readonly fontWeight: {
                                            readonly type: 'string';
                                        };
                                        readonly lineHeight: {
                                            readonly type: 'string';
                                        };
                                        readonly color: {
                                            readonly type: 'string';
                                            readonly uiHint: 'color';
                                        };
                                        readonly transform: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly heading2: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly fontFamily: {
                                            readonly type: 'string';
                                        };
                                        readonly fontSize: {
                                            readonly type: 'string';
                                        };
                                        readonly fontWeight: {
                                            readonly type: 'string';
                                        };
                                        readonly lineHeight: {
                                            readonly type: 'string';
                                        };
                                        readonly color: {
                                            readonly type: 'string';
                                            readonly uiHint: 'color';
                                        };
                                        readonly transform: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly heading3: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly fontFamily: {
                                            readonly type: 'string';
                                        };
                                        readonly fontSize: {
                                            readonly type: 'string';
                                        };
                                        readonly fontWeight: {
                                            readonly type: 'string';
                                        };
                                        readonly lineHeight: {
                                            readonly type: 'string';
                                        };
                                        readonly color: {
                                            readonly type: 'string';
                                            readonly uiHint: 'color';
                                        };
                                        readonly transform: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly headings: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly fontFamily: {
                                            readonly type: 'string';
                                        };
                                        readonly fontSize: {
                                            readonly type: 'string';
                                        };
                                        readonly fontWeight: {
                                            readonly type: 'string';
                                        };
                                        readonly lineHeight: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly lineHeight: {
                                    readonly type: 'string';
                                };
                                readonly links: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly color: {
                                            readonly type: 'string';
                                            readonly uiHint: 'color';
                                        };
                                        readonly hover: {
                                            readonly type: 'string';
                                        };
                                        readonly textDecoration: {
                                            readonly type: 'string';
                                        };
                                        readonly hoverTextDecoration: {
                                            readonly type: 'string';
                                        };
                                        readonly visited: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly optimizeSpeed: {
                                    readonly type: 'boolean';
                                };
                                readonly rightPanelHeading: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly fontFamily: {
                                            readonly type: 'string';
                                        };
                                        readonly fontSize: {
                                            readonly type: 'string';
                                        };
                                        readonly fontWeight: {
                                            readonly type: 'string';
                                        };
                                        readonly lineHeight: {
                                            readonly type: 'string';
                                        };
                                        readonly color: {
                                            readonly type: 'string';
                                            readonly uiHint: 'color';
                                        };
                                        readonly transform: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly smoothing: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["auto", "none", "antialiased", "subpixel-antialiased", "grayscale"];
                                };
                            };
                        };
                        readonly links: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly color: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                            };
                        };
                        readonly codeSample: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly backgroundColor: {
                                    readonly type: 'string';
                                    readonly uiHint: 'color';
                                };
                            };
                        };
                    };
                };
                readonly ctrlFHijack: {
                    readonly type: 'boolean';
                };
                readonly defaultSampleLanguage: {
                    readonly type: 'string';
                };
                readonly disableDeepLinks: {
                    readonly type: 'boolean';
                };
                readonly disableSearch: {
                    readonly type: 'boolean';
                };
                readonly disableSidebar: {
                    readonly type: 'boolean';
                };
                readonly downloadDefinitionUrl: {
                    readonly type: 'string';
                };
                readonly expandDefaultServerVariables: {
                    readonly type: 'boolean';
                };
                readonly enumSkipQuotes: {
                    readonly type: 'boolean';
                };
                readonly expandDefaultRequest: {
                    readonly type: 'boolean';
                };
                readonly expandDefaultResponse: {
                    readonly type: 'boolean';
                };
                readonly expandResponses: {
                    readonly type: 'string';
                };
                readonly expandSingleSchemaField: {
                    readonly type: 'boolean';
                };
                readonly generateCodeSamples: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly skipOptionalParameters: {
                            readonly type: 'boolean';
                        };
                        readonly languages: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'object';
                                readonly properties: {
                                    readonly label: {
                                        readonly type: 'string';
                                    };
                                    readonly lang: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["curl", "C#", "Go", "Java", "Java8+Apache", "JavaScript", "Node.js", "PHP", "Python", "R", "Ruby"];
                                    };
                                };
                                readonly required: readonly ["lang"];
                            };
                        };
                    };
                    readonly required: readonly ["languages"];
                };
                readonly generatedPayloadSamplesMaxDepth: {
                    readonly type: 'number';
                };
                readonly hideDownloadButton: {
                    readonly type: 'boolean';
                };
                readonly hideHostname: {
                    readonly type: 'boolean';
                };
                readonly hideInfoSection: {
                    readonly type: 'boolean';
                };
                readonly hideLogo: {
                    readonly type: 'boolean';
                };
                readonly hideRequestPayloadSample: {
                    readonly type: 'boolean';
                };
                readonly hideRightPanel: {
                    readonly type: 'boolean';
                };
                readonly hideSchemaPattern: {
                    readonly type: 'boolean';
                };
                readonly hideSingleRequestSampleTab: {
                    readonly type: 'boolean';
                };
                readonly hideSecuritySection: {
                    readonly type: 'boolean';
                };
                readonly hideTryItPanel: {
                    readonly type: 'boolean';
                };
                readonly hideFab: {
                    readonly type: 'boolean';
                };
                readonly hideOneOfDescription: {
                    readonly type: 'boolean';
                };
                readonly htmlTemplate: {
                    readonly type: 'string';
                    readonly format: 'uri-reference';
                };
                readonly jsonSampleExpandLevel: {
                    readonly oneOf: readonly [{
                        readonly type: 'number';
                        readonly minimum: 1;
                    }, {
                        readonly type: 'string';
                    }];
                };
                readonly labels: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly enum: {
                            readonly type: 'string';
                        };
                        readonly enumSingleValue: {
                            readonly type: 'string';
                        };
                        readonly enumArray: {
                            readonly type: 'string';
                        };
                        readonly default: {
                            readonly type: 'string';
                        };
                        readonly deprecated: {
                            readonly type: 'string';
                        };
                        readonly example: {
                            readonly type: 'string';
                        };
                        readonly examples: {
                            readonly type: 'string';
                        };
                        readonly nullable: {
                            readonly type: 'string';
                        };
                        readonly recursive: {
                            readonly type: 'string';
                        };
                        readonly arrayOf: {
                            readonly type: 'string';
                        };
                        readonly webhook: {
                            readonly type: 'string';
                        };
                        readonly authorizations: {
                            readonly type: 'string';
                        };
                        readonly tryItAuthBasicUsername: {
                            readonly type: 'string';
                        };
                        readonly tryItAuthBasicPassword: {
                            readonly type: 'string';
                        };
                    };
                };
                readonly menuToggle: {
                    readonly type: 'boolean';
                };
                readonly nativeScrollbars: {
                    readonly type: 'boolean';
                };
                readonly noAutoAuth: {
                    readonly type: 'boolean';
                };
                readonly onDeepLinkClick: {
                    readonly type: 'object';
                };
                readonly pagination: {
                    readonly type: 'string';
                    readonly enum: readonly ["none", "section", "item"];
                };
                readonly pathInMiddlePanel: {
                    readonly type: 'boolean';
                };
                readonly payloadSampleIdx: {
                    readonly type: 'number';
                    readonly minimum: 0;
                };
                readonly requiredPropsFirst: {
                    readonly type: 'boolean';
                };
                readonly routingStrategy: {
                    readonly type: 'string';
                };
                readonly samplesTabsMaxCount: {
                    readonly type: 'number';
                };
                readonly schemaExpansionLevel: {
                    readonly oneOf: readonly [{
                        readonly type: 'number';
                        readonly minimum: 0;
                    }, {
                        readonly type: 'string';
                    }];
                };
                readonly minCharacterLengthToInitSearch: {
                    readonly type: 'number';
                    readonly minimum: 1;
                };
                readonly maxResponseHeadersToShowInTryIt: {
                    readonly type: 'number';
                    readonly minimum: 0;
                };
                readonly scrollYOffset: {
                    readonly oneOf: readonly [{
                        readonly type: 'number';
                    }, {
                        readonly type: 'string';
                    }];
                };
                readonly searchAutoExpand: {
                    readonly type: 'boolean';
                };
                readonly searchFieldLevelBoost: {
                    readonly type: 'number';
                    readonly minimum: 0;
                };
                readonly searchMaxDepth: {
                    readonly type: 'number';
                    readonly minimum: 1;
                };
                readonly searchMode: {
                    readonly type: 'string';
                    readonly enum: readonly ["default", "path-only"];
                };
                readonly searchOperationTitleBoost: {
                    readonly type: 'number';
                };
                readonly searchTagTitleBoost: {
                    readonly type: 'number';
                };
                readonly sendXUserAgentInTryIt: {
                    readonly type: 'boolean';
                };
                readonly showChangeLayoutButton: {
                    readonly type: 'boolean';
                };
                readonly showConsole: {
                    readonly type: 'boolean';
                };
                readonly showNextButton: {
                    readonly type: 'boolean';
                };
                readonly showRightPanelToggle: {
                    readonly type: 'boolean';
                };
                readonly showSecuritySchemeType: {
                    readonly type: 'boolean';
                };
                readonly showWebhookVerb: {
                    readonly type: 'boolean';
                };
                readonly showObjectSchemaExamples: {
                    readonly type: 'boolean';
                };
                readonly disableTryItRequestUrlEncoding: {
                    readonly type: 'boolean';
                };
                readonly sidebarLinks: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly beforeInfo: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'object';
                                readonly properties: {
                                    readonly label: {
                                        readonly type: 'string';
                                    };
                                    readonly link: {
                                        readonly type: 'string';
                                    };
                                    readonly target: {
                                        readonly type: 'string';
                                    };
                                };
                                readonly required: readonly ["label", "link"];
                            };
                        };
                        readonly end: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'object';
                                readonly properties: {
                                    readonly label: {
                                        readonly type: 'string';
                                    };
                                    readonly link: {
                                        readonly type: 'string';
                                    };
                                    readonly target: {
                                        readonly type: 'string';
                                    };
                                };
                                readonly required: readonly ["label", "link"];
                            };
                        };
                    };
                };
                readonly sideNavStyle: {
                    readonly type: 'string';
                    readonly enum: readonly ["summary-only", "path-first", "id-only", "path-only"];
                };
                readonly simpleOneOfTypeLabel: {
                    readonly type: 'boolean';
                };
                readonly sortEnumValuesAlphabetically: {
                    readonly type: 'boolean';
                };
                readonly sortOperationsAlphabetically: {
                    readonly type: 'boolean';
                };
                readonly sortPropsAlphabetically: {
                    readonly type: 'boolean';
                };
                readonly sortTagsAlphabetically: {
                    readonly type: 'boolean';
                };
                readonly suppressWarnings: {
                    readonly type: 'boolean';
                };
                readonly unstable_externalDescription: {
                    readonly type: 'boolean';
                };
                readonly unstable_ignoreMimeParameters: {
                    readonly type: 'boolean';
                };
                readonly untrustedDefinition: {
                    readonly type: 'boolean';
                };
                readonly showAccessMode: {
                    readonly type: 'boolean';
                };
                readonly preserveOriginalExtensionsName: {
                    readonly type: 'boolean';
                };
                readonly markdownHeadingsAnchorLevel: {
                    readonly type: 'number';
                };
            };
        };
        readonly asyncapi: {
            readonly type: 'object';
            readonly properties: {
                readonly downloadUrls: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly title: {
                                readonly type: 'string';
                            };
                            readonly url: {
                                readonly type: 'string';
                            };
                        };
                        readonly required: readonly ["url"];
                        readonly additionalProperties: false;
                    };
                };
                readonly apiLogo: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly imageUrl: {
                            readonly type: 'string';
                        };
                        readonly href: {
                            readonly type: 'string';
                        };
                        readonly altText: {
                            readonly type: 'string';
                        };
                        readonly backgroundColor: {
                            readonly type: 'string';
                        };
                    };
                };
                readonly jsonSamplesDepth: {
                    readonly type: 'number';
                };
                readonly excludeFromSearch: {
                    readonly type: 'boolean';
                };
                readonly samplesMaxInlineArgs: {
                    readonly type: 'number';
                };
                readonly fieldExpandLevel: {
                    readonly type: 'number';
                };
                readonly baseUrlPath: {
                    readonly type: 'string';
                };
                readonly feedback: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                        readonly type: {
                            readonly type: 'string';
                            readonly enum: readonly ["rating", "sentiment", "comment", "reasons", "mood", "scale"];
                        };
                        readonly settings: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly label: {
                                    readonly type: 'string';
                                };
                                readonly submitText: {
                                    readonly type: 'string';
                                };
                                readonly buttonText: {
                                    readonly type: 'string';
                                };
                                readonly component: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["radio", "checkbox"];
                                };
                                readonly items: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'string';
                                    };
                                    readonly minItems: 1;
                                };
                                readonly leftScaleLabel: {
                                    readonly type: 'string';
                                };
                                readonly rightScaleLabel: {
                                    readonly type: 'string';
                                };
                                readonly reasons: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly component: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["radio", "checkbox"];
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly like: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                        readonly dislike: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                        readonly satisfied: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                        readonly neutral: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                        readonly dissatisfied: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly comment: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly likeLabel: {
                                            readonly type: 'string';
                                        };
                                        readonly dislikeLabel: {
                                            readonly type: 'string';
                                        };
                                        readonly satisfiedLabel: {
                                            readonly type: 'string';
                                        };
                                        readonly neutralLabel: {
                                            readonly type: 'string';
                                        };
                                        readonly dissatisfiedLabel: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly optionalEmail: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly placeholder: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                            };
                            readonly additionalProperties: false;
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly layout: {
                    readonly type: 'string';
                    readonly enum: readonly ["stacked", "three-panel"];
                };
            };
            readonly additionalProperties: false;
        };
        readonly graphql: {
            readonly type: 'object';
            readonly properties: {
                readonly menu: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly requireExactGroups: {
                            readonly type: 'boolean';
                        };
                        readonly groups: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'object';
                                readonly properties: {
                                    readonly name: {
                                        readonly type: 'string';
                                    };
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly properties: {
                                            readonly includeByName: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly excludeByName: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                    readonly queries: {
                                        readonly type: 'object';
                                        readonly properties: {
                                            readonly includeByName: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly excludeByName: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                    readonly mutations: {
                                        readonly type: 'object';
                                        readonly properties: {
                                            readonly includeByName: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly excludeByName: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                    readonly subscriptions: {
                                        readonly type: 'object';
                                        readonly properties: {
                                            readonly includeByName: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly excludeByName: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                    readonly types: {
                                        readonly type: 'object';
                                        readonly properties: {
                                            readonly includeByName: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly excludeByName: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                    readonly directives: {
                                        readonly type: 'object';
                                        readonly properties: {
                                            readonly includeByName: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly excludeByName: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly required: readonly ["name"];
                                readonly additionalProperties: false;
                            };
                        };
                        readonly otherItemsGroupName: {
                            readonly type: 'string';
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly downloadUrls: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly title: {
                                readonly type: 'string';
                            };
                            readonly url: {
                                readonly type: 'string';
                            };
                        };
                        readonly required: readonly ["url"];
                        readonly additionalProperties: false;
                    };
                };
                readonly apiLogo: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly imageUrl: {
                            readonly type: 'string';
                        };
                        readonly href: {
                            readonly type: 'string';
                        };
                        readonly altText: {
                            readonly type: 'string';
                        };
                        readonly backgroundColor: {
                            readonly type: 'string';
                            readonly uiHint: 'color';
                        };
                    };
                };
                readonly jsonSamplesDepth: {
                    readonly type: 'number';
                };
                readonly samplesMaxInlineArgs: {
                    readonly type: 'number';
                };
                readonly licenseKey: {
                    readonly type: 'string';
                };
                readonly fieldExpandLevel: {
                    readonly type: 'number';
                };
                readonly baseUrlPath: {
                    readonly type: 'string';
                };
                readonly metadata: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly apiId: {
                            readonly type: 'string';
                        };
                    };
                    readonly additionalProperties: true;
                };
                readonly feedback: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly hide: {
                            readonly type: 'boolean';
                        };
                        readonly type: {
                            readonly type: 'string';
                            readonly enum: readonly ["rating", "sentiment", "comment", "reasons", "mood", "scale"];
                        };
                        readonly settings: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly label: {
                                    readonly type: 'string';
                                };
                                readonly submitText: {
                                    readonly type: 'string';
                                };
                                readonly buttonText: {
                                    readonly type: 'string';
                                };
                                readonly component: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["radio", "checkbox"];
                                };
                                readonly items: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'string';
                                    };
                                    readonly minItems: 1;
                                };
                                readonly leftScaleLabel: {
                                    readonly type: 'string';
                                };
                                readonly rightScaleLabel: {
                                    readonly type: 'string';
                                };
                                readonly reasons: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly component: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["radio", "checkbox"];
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly items: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly like: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                        readonly dislike: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                        readonly satisfied: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                        readonly neutral: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                        readonly dissatisfied: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly hide: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly component: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["radio", "checkbox"];
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                            };
                                            readonly additionalProperties: false;
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly comment: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly likeLabel: {
                                            readonly type: 'string';
                                        };
                                        readonly dislikeLabel: {
                                            readonly type: 'string';
                                        };
                                        readonly satisfiedLabel: {
                                            readonly type: 'string';
                                        };
                                        readonly neutralLabel: {
                                            readonly type: 'string';
                                        };
                                        readonly dissatisfiedLabel: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                                readonly optionalEmail: {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly placeholder: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                            };
                            readonly additionalProperties: false;
                        };
                    };
                    readonly additionalProperties: false;
                };
                readonly layout: {
                    readonly type: 'string';
                    readonly enum: readonly ["stacked", "three-panel"];
                };
                readonly showBuiltInScalars: {
                    readonly type: 'boolean';
                };
                readonly showBuiltInDirectives: {
                    readonly type: 'boolean';
                };
                readonly excludeFromSearch: {
                    readonly type: 'boolean';
                };
                readonly info: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly title: {
                            readonly type: 'string';
                        };
                        readonly version: {
                            readonly type: 'string';
                        };
                        readonly description: {
                            readonly type: 'string';
                            readonly uiHint: 'textarea';
                        };
                        readonly termsOfService: {
                            readonly type: 'string';
                            readonly format: 'uri';
                        };
                        readonly contact: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly name: {
                                    readonly type: 'string';
                                };
                                readonly url: {
                                    readonly type: 'string';
                                    readonly format: 'uri';
                                };
                                readonly email: {
                                    readonly type: 'string';
                                    readonly format: 'email';
                                };
                            };
                            readonly additionalProperties: false;
                        };
                        readonly license: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly name: {
                                    readonly type: 'string';
                                };
                                readonly url: {
                                    readonly type: 'string';
                                    readonly format: 'uri';
                                };
                                readonly identifier: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProperties: false;
                        };
                    };
                    readonly additionalProperties: false;
                };
            };
            readonly additionalProperties: false;
        };
        readonly analytics: {
            readonly type: 'object';
            readonly properties: {
                readonly adobe: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly includeInDevelopment: {
                            readonly type: 'boolean';
                        };
                        readonly scriptUrl: {
                            readonly type: 'string';
                        };
                        readonly pageViewEventName: {
                            readonly type: 'string';
                        };
                    };
                    readonly additionalProperties: false;
                    readonly required: readonly ["scriptUrl"];
                };
                readonly amplitude: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly includeInDevelopment: {
                            readonly type: 'boolean';
                        };
                        readonly apiKey: {
                            readonly type: 'string';
                        };
                        readonly head: {
                            readonly type: 'boolean';
                        };
                        readonly respectDNT: {
                            readonly type: 'boolean';
                        };
                        readonly exclude: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'string';
                            };
                        };
                        readonly outboundClickEventName: {
                            readonly type: 'string';
                        };
                        readonly pageViewEventName: {
                            readonly type: 'string';
                        };
                        readonly amplitudeConfig: {
                            readonly type: 'object';
                            readonly additionalProperties: true;
                        };
                    };
                    readonly additionalProperties: false;
                    readonly required: readonly ["apiKey"];
                };
                readonly fullstory: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly includeInDevelopment: {
                            readonly type: 'boolean';
                        };
                        readonly orgId: {
                            readonly type: 'string';
                        };
                    };
                    readonly additionalProperties: false;
                    readonly required: readonly ["orgId"];
                };
                readonly heap: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly includeInDevelopment: {
                            readonly type: 'boolean';
                        };
                        readonly appId: {
                            readonly type: 'string';
                        };
                    };
                    readonly additionalProperties: false;
                    readonly required: readonly ["appId"];
                };
                readonly rudderstack: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly includeInDevelopment: {
                            readonly type: 'boolean';
                        };
                        readonly writeKey: {
                            readonly type: 'string';
                            readonly minLength: 10;
                        };
                        readonly trackPage: {
                            readonly type: 'boolean';
                        };
                        readonly dataPlaneUrl: {
                            readonly type: 'string';
                        };
                        readonly controlPlaneUrl: {
                            readonly type: 'string';
                        };
                        readonly sdkUrl: {
                            readonly type: 'string';
                        };
                        readonly loadOptions: {
                            readonly type: 'object';
                            readonly additionalProperties: true;
                        };
                    };
                    readonly additionalProperties: false;
                    readonly required: readonly ["writeKey"];
                };
                readonly segment: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly includeInDevelopment: {
                            readonly type: 'boolean';
                        };
                        readonly writeKey: {
                            readonly type: 'string';
                            readonly minLength: 10;
                        };
                        readonly trackPage: {
                            readonly type: 'boolean';
                        };
                        readonly includeTitleInPageCall: {
                            readonly type: 'boolean';
                        };
                        readonly host: {
                            readonly type: 'string';
                        };
                    };
                    readonly additionalProperties: false;
                    readonly required: readonly ["writeKey"];
                };
                readonly gtm: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly includeInDevelopment: {
                            readonly type: 'boolean';
                        };
                        readonly trackingId: {
                            readonly type: 'string';
                        };
                        readonly gtmAuth: {
                            readonly type: 'string';
                        };
                        readonly gtmPreview: {
                            readonly type: 'string';
                        };
                        readonly defaultDataLayer: {
                            readonly type: 'object';
                            readonly additionalProperties: true;
                        };
                        readonly dataLayerName: {
                            readonly type: 'string';
                        };
                        readonly enableWebVitalsTracking: {
                            readonly type: 'boolean';
                        };
                        readonly selfHostedOrigin: {
                            readonly type: 'string';
                        };
                        readonly pageViewEventName: {
                            readonly type: 'string';
                        };
                    };
                    readonly additionalProperties: false;
                    readonly required: readonly ["trackingId"];
                };
                readonly ga: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly includeInDevelopment: {
                            readonly type: 'boolean';
                        };
                        readonly trackingId: {
                            readonly type: 'string';
                        };
                        readonly conversionId: {
                            readonly type: 'string';
                        };
                        readonly floodlightId: {
                            readonly type: 'string';
                        };
                        readonly head: {
                            readonly type: 'boolean';
                        };
                        readonly respectDNT: {
                            readonly type: 'boolean';
                        };
                        readonly exclude: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'string';
                            };
                        };
                        readonly optimizeId: {
                            readonly type: 'string';
                        };
                        readonly anonymizeIp: {
                            readonly type: 'boolean';
                        };
                        readonly cookieExpires: {
                            readonly type: 'number';
                        };
                        readonly trackers: {
                            readonly type: 'object';
                            readonly additionalProperties: {
                                readonly type: 'object';
                                readonly properties: {
                                    readonly includeInDevelopment: {
                                        readonly type: 'boolean';
                                    };
                                    readonly trackingId: {
                                        readonly type: 'string';
                                    };
                                    readonly conversionId: {
                                        readonly type: 'string';
                                    };
                                    readonly floodlightId: {
                                        readonly type: 'string';
                                    };
                                    readonly optimizeId: {
                                        readonly type: 'string';
                                    };
                                    readonly exclude: {
                                        readonly type: 'array';
                                        readonly items: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly additionalProperties: false;
                                readonly required: readonly ["trackingId"];
                            };
                        };
                    };
                    readonly additionalProperties: false;
                    readonly required: readonly ["trackingId"];
                };
            };
        };
        readonly userMenu: {
            readonly type: 'object';
            readonly properties: {
                readonly hide: {
                    readonly type: 'boolean';
                };
                readonly items: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly label: {
                                readonly type: 'string';
                            };
                            readonly external: {
                                readonly type: 'boolean';
                            };
                            readonly link: {
                                readonly type: 'string';
                            };
                            readonly separatorLine: {
                                readonly type: 'boolean';
                            };
                        };
                        readonly additionalProperties: true;
                    };
                };
                readonly hideLoginButton: {
                    readonly type: 'boolean';
                };
            };
            readonly additionalProperties: false;
        };
        readonly versionPicker: {
            readonly type: 'object';
            readonly properties: {
                readonly hide: {
                    readonly type: 'boolean';
                };
                readonly showForUnversioned: {
                    readonly type: 'boolean';
                };
            };
        };
        readonly breadcrumbs: {
            readonly type: 'object';
            readonly properties: {
                readonly hide: {
                    readonly type: 'boolean';
                };
                readonly prefixItems: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly label: {
                                readonly type: 'string';
                            };
                            readonly labelTranslationKey: {
                                readonly type: 'string';
                            };
                            readonly page: {
                                readonly type: 'string';
                                readonly format: 'uri-reference';
                            };
                            readonly icon: {
                                readonly type: 'string';
                            };
                        };
                        readonly additionalProperties: false;
                    };
                };
            };
            readonly additionalProperties: false;
        };
        /**
         * @deprecated Should use `catalogClassic` instead
         */
        readonly catalog: {
            readonly type: 'object';
            readonly patternProperties: {
                readonly '.*': {
                    readonly type: 'object';
                    readonly additionalProperties: true;
                    readonly required: readonly ["slug", "items"];
                    readonly properties: {
                        readonly show: {
                            readonly type: 'boolean';
                        };
                        readonly slug: {
                            readonly type: 'string';
                        };
                        readonly filters: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'object';
                                readonly additionalProperties: false;
                                readonly required: readonly ["title", "property"];
                                readonly properties: {
                                    readonly type: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["select", "checkboxes", "date-range"];
                                    };
                                    readonly title: {
                                        readonly type: 'string';
                                    };
                                    readonly titleTranslationKey: {
                                        readonly type: 'string';
                                    };
                                    readonly property: {
                                        readonly type: 'string';
                                    };
                                    readonly parentFilter: {
                                        readonly type: 'string';
                                    };
                                    readonly valuesMapping: {
                                        readonly type: 'object';
                                        readonly additionalProperties: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly missingCategoryName: {
                                        readonly type: 'string';
                                    };
                                    readonly missingCategoryNameTranslationKey: {
                                        readonly type: 'string';
                                    };
                                    readonly options: {
                                        readonly type: 'array';
                                        readonly items: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                            };
                        };
                        readonly groupByFirstFilter: {
                            readonly type: 'boolean';
                        };
                        readonly filterValuesCasing: {
                            readonly type: 'string';
                            readonly enum: readonly ["sentence", "original", "lowercase", "uppercase"];
                        };
                        readonly items: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'object';
                                readonly properties: {
                                    readonly page: {
                                        readonly type: 'string';
                                        readonly format: 'uri-reference';
                                        readonly uiHint: 'file';
                                    };
                                    readonly directory: {
                                        readonly type: 'string';
                                        readonly format: 'uri-reference';
                                        readonly uiHint: 'file';
                                    };
                                    readonly disconnect: {
                                        readonly type: 'boolean';
                                    };
                                    readonly group: {
                                        readonly type: 'string';
                                    };
                                    readonly label: {
                                        readonly type: 'string';
                                    };
                                    readonly href: {
                                        readonly type: 'string';
                                    };
                                    readonly external: {
                                        readonly type: 'boolean';
                                    };
                                    readonly labelTranslationKey: {
                                        readonly type: 'string';
                                    };
                                    readonly groupTranslationKey: {
                                        readonly type: 'string';
                                    };
                                    readonly icon: {
                                        readonly oneOf: readonly [{
                                            readonly type: 'string';
                                        }, {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly srcSet: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly required: readonly ["srcSet"];
                                        }];
                                    };
                                    readonly separator: {
                                        readonly type: 'string';
                                    };
                                    readonly separatorLine: {
                                        readonly type: 'boolean';
                                    };
                                    readonly linePosition: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["top", "bottom"];
                                    };
                                    readonly version: {
                                        readonly type: 'string';
                                    };
                                    readonly menuStyle: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["drilldown"];
                                    };
                                    readonly expanded: {
                                        readonly type: 'string';
                                        readonly const: 'always';
                                    };
                                    readonly selectFirstItemOnExpand: {
                                        readonly type: 'boolean';
                                    };
                                    readonly flatten: {
                                        readonly type: 'boolean';
                                    };
                                    readonly includeByMetadata: {
                                        readonly type: 'object';
                                        readonly additionalProperties: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                    };
                                    readonly linkedSidebars: {
                                        readonly type: 'array';
                                        readonly items: {
                                            readonly type: 'string';
                                            readonly format: 'uri-reference';
                                        };
                                    };
                                    readonly rbac: {
                                        readonly type: 'object';
                                        readonly additionalProperties: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly additionalProps: {
                                        readonly type: 'object';
                                        readonly additionalProperties: true;
                                    };
                                    readonly items: {
                                        readonly type: 'array';
                                        readonly items: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly page: {
                                                    readonly type: 'string';
                                                    readonly format: 'uri-reference';
                                                    readonly uiHint: 'file';
                                                };
                                                readonly directory: {
                                                    readonly type: 'string';
                                                    readonly format: 'uri-reference';
                                                    readonly uiHint: 'file';
                                                };
                                                readonly disconnect: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly group: {
                                                    readonly type: 'string';
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly href: {
                                                    readonly type: 'string';
                                                };
                                                readonly external: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly labelTranslationKey: {
                                                    readonly type: 'string';
                                                };
                                                readonly groupTranslationKey: {
                                                    readonly type: 'string';
                                                };
                                                readonly icon: {
                                                    readonly oneOf: readonly [{
                                                        readonly type: 'string';
                                                    }, {
                                                        readonly type: 'object';
                                                        readonly properties: {
                                                            readonly srcSet: {
                                                                readonly type: 'string';
                                                            };
                                                        };
                                                        readonly required: readonly ["srcSet"];
                                                    }];
                                                };
                                                readonly separator: {
                                                    readonly type: 'string';
                                                };
                                                readonly separatorLine: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly linePosition: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["top", "bottom"];
                                                };
                                                readonly version: {
                                                    readonly type: 'string';
                                                };
                                                readonly menuStyle: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["drilldown"];
                                                };
                                                readonly expanded: {
                                                    readonly type: 'string';
                                                    readonly const: 'always';
                                                };
                                                readonly selectFirstItemOnExpand: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly flatten: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly includeByMetadata: {
                                                    readonly type: 'object';
                                                    readonly additionalProperties: {
                                                        readonly type: 'array';
                                                        readonly items: {
                                                            readonly type: 'string';
                                                        };
                                                    };
                                                };
                                                readonly linkedSidebars: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                        readonly format: 'uri-reference';
                                                    };
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'object';
                                                        readonly additionalProperties: true;
                                                    };
                                                };
                                                readonly rbac: {
                                                    readonly type: 'object';
                                                    readonly additionalProperties: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                                readonly additionalProps: {
                                                    readonly type: 'object';
                                                    readonly additionalProperties: true;
                                                };
                                            };
                                        };
                                    };
                                };
                            };
                        };
                        readonly requiredPermission: {
                            readonly type: 'string';
                        };
                        readonly separateVersions: {
                            readonly type: 'boolean';
                        };
                        readonly title: {
                            readonly type: 'string';
                        };
                        readonly titleTranslationKey: {
                            readonly type: 'string';
                        };
                        readonly description: {
                            readonly type: 'string';
                        };
                        readonly descriptionTranslationKey: {
                            readonly type: 'string';
                        };
                    };
                };
            };
        };
        readonly entitiesCatalog: {
            readonly type: 'object';
            readonly properties: {
                readonly show: {
                    readonly type: 'boolean';
                };
                readonly entityTypes: {
                    readonly type: 'object';
                    readonly additionalProperties: {
                        readonly type: 'object';
                        readonly required: readonly ["name", "description", "metadataSchema"];
                        readonly properties: {
                            readonly name: {
                                readonly type: 'string';
                                readonly description: 'Display name of the entity type';
                            };
                            readonly description: {
                                readonly type: 'string';
                                readonly description: 'Description of the entity type';
                            };
                            readonly metadataSchema: {
                                readonly type: 'object';
                                readonly required: readonly ["type", "properties"];
                                readonly properties: {
                                    readonly type: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["object"];
                                    };
                                    readonly description: {
                                        readonly type: 'string';
                                    };
                                    readonly properties: {
                                        readonly type: 'object';
                                        readonly additionalProperties: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly type: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["string", "number", "boolean", "array", "object"];
                                                };
                                                readonly description: {
                                                    readonly type: 'string';
                                                };
                                                readonly example: {
                                                    readonly oneOf: readonly [{
                                                        readonly type: 'string';
                                                    }, {
                                                        readonly type: 'number';
                                                    }, {
                                                        readonly type: 'boolean';
                                                    }, {
                                                        readonly type: 'array';
                                                    }, {
                                                        readonly type: 'object';
                                                    }];
                                                };
                                                readonly enum: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                                readonly pattern: {
                                                    readonly type: 'string';
                                                };
                                                readonly format: {
                                                    readonly type: 'string';
                                                };
                                                readonly minimum: {
                                                    readonly type: 'number';
                                                };
                                                readonly maximum: {
                                                    readonly type: 'number';
                                                };
                                                readonly items: {
                                                    readonly type: 'object';
                                                };
                                            };
                                            readonly additionalProperties: true;
                                        };
                                    };
                                    readonly required: {
                                        readonly type: 'array';
                                        readonly items: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly additionalProperties: {
                                        readonly type: 'boolean';
                                    };
                                };
                                readonly additionalProperties: true;
                            };
                            readonly icon: {
                                readonly type: 'object';
                                readonly properties: {
                                    readonly src: {
                                        readonly type: 'string';
                                        readonly format: 'uri-reference';
                                    };
                                    readonly srcSet: {
                                        readonly type: 'string';
                                    };
                                };
                                readonly additionalProperties: false;
                            };
                        };
                        readonly additionalProperties: false;
                    };
                };
                readonly catalogs: {
                    readonly type: 'object';
                    readonly properties: {
                        readonly all: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly slug: {
                                    readonly type: 'string';
                                };
                                readonly hide: {
                                    readonly type: 'boolean';
                                };
                                readonly includes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["type"];
                                        readonly properties: {
                                            readonly type: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly excludes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["key"];
                                        readonly properties: {
                                            readonly key: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly filters: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["property", "title"];
                                        readonly properties: {
                                            readonly property: {
                                                readonly type: 'string';
                                            };
                                            readonly hide: {
                                                readonly type: 'boolean';
                                            };
                                            readonly label: {
                                                readonly type: 'string';
                                            };
                                            readonly options: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly type: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["select", "checkboxes", "date-range"];
                                            };
                                            readonly title: {
                                                readonly type: 'string';
                                            };
                                            readonly titleTranslationKey: {
                                                readonly type: 'string';
                                            };
                                            readonly parentFilter: {
                                                readonly type: 'string';
                                            };
                                            readonly valuesMapping: {
                                                readonly type: 'object';
                                                readonly additionalProperties: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly titleTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly descriptionTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly catalogSwitcherLabelTranslationKey: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProperties: false;
                        };
                        readonly services: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly slug: {
                                    readonly type: 'string';
                                };
                                readonly hide: {
                                    readonly type: 'boolean';
                                };
                                readonly includes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["type"];
                                        readonly properties: {
                                            readonly type: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly excludes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["key"];
                                        readonly properties: {
                                            readonly key: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly filters: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["property", "title"];
                                        readonly properties: {
                                            readonly property: {
                                                readonly type: 'string';
                                            };
                                            readonly hide: {
                                                readonly type: 'boolean';
                                            };
                                            readonly label: {
                                                readonly type: 'string';
                                            };
                                            readonly options: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly type: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["select", "checkboxes", "date-range"];
                                            };
                                            readonly title: {
                                                readonly type: 'string';
                                            };
                                            readonly titleTranslationKey: {
                                                readonly type: 'string';
                                            };
                                            readonly parentFilter: {
                                                readonly type: 'string';
                                            };
                                            readonly valuesMapping: {
                                                readonly type: 'object';
                                                readonly additionalProperties: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly titleTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly descriptionTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly catalogSwitcherLabelTranslationKey: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProperties: false;
                        };
                        readonly domains: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly slug: {
                                    readonly type: 'string';
                                };
                                readonly hide: {
                                    readonly type: 'boolean';
                                };
                                readonly includes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["type"];
                                        readonly properties: {
                                            readonly type: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly excludes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["key"];
                                        readonly properties: {
                                            readonly key: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly filters: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["property", "title"];
                                        readonly properties: {
                                            readonly property: {
                                                readonly type: 'string';
                                            };
                                            readonly hide: {
                                                readonly type: 'boolean';
                                            };
                                            readonly label: {
                                                readonly type: 'string';
                                            };
                                            readonly options: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly type: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["select", "checkboxes", "date-range"];
                                            };
                                            readonly title: {
                                                readonly type: 'string';
                                            };
                                            readonly titleTranslationKey: {
                                                readonly type: 'string';
                                            };
                                            readonly parentFilter: {
                                                readonly type: 'string';
                                            };
                                            readonly valuesMapping: {
                                                readonly type: 'object';
                                                readonly additionalProperties: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly titleTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly descriptionTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly catalogSwitcherLabelTranslationKey: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProperties: false;
                        };
                        readonly teams: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly slug: {
                                    readonly type: 'string';
                                };
                                readonly hide: {
                                    readonly type: 'boolean';
                                };
                                readonly includes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["type"];
                                        readonly properties: {
                                            readonly type: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly excludes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["key"];
                                        readonly properties: {
                                            readonly key: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly filters: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["property", "title"];
                                        readonly properties: {
                                            readonly property: {
                                                readonly type: 'string';
                                            };
                                            readonly hide: {
                                                readonly type: 'boolean';
                                            };
                                            readonly label: {
                                                readonly type: 'string';
                                            };
                                            readonly options: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly type: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["select", "checkboxes", "date-range"];
                                            };
                                            readonly title: {
                                                readonly type: 'string';
                                            };
                                            readonly titleTranslationKey: {
                                                readonly type: 'string';
                                            };
                                            readonly parentFilter: {
                                                readonly type: 'string';
                                            };
                                            readonly valuesMapping: {
                                                readonly type: 'object';
                                                readonly additionalProperties: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly titleTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly descriptionTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly catalogSwitcherLabelTranslationKey: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProperties: false;
                        };
                        readonly users: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly slug: {
                                    readonly type: 'string';
                                };
                                readonly hide: {
                                    readonly type: 'boolean';
                                };
                                readonly includes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["type"];
                                        readonly properties: {
                                            readonly type: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly excludes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["key"];
                                        readonly properties: {
                                            readonly key: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly filters: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["property", "title"];
                                        readonly properties: {
                                            readonly property: {
                                                readonly type: 'string';
                                            };
                                            readonly hide: {
                                                readonly type: 'boolean';
                                            };
                                            readonly label: {
                                                readonly type: 'string';
                                            };
                                            readonly options: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly type: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["select", "checkboxes", "date-range"];
                                            };
                                            readonly title: {
                                                readonly type: 'string';
                                            };
                                            readonly titleTranslationKey: {
                                                readonly type: 'string';
                                            };
                                            readonly parentFilter: {
                                                readonly type: 'string';
                                            };
                                            readonly valuesMapping: {
                                                readonly type: 'object';
                                                readonly additionalProperties: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly titleTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly descriptionTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly catalogSwitcherLabelTranslationKey: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProperties: false;
                        };
                        readonly apiDescriptions: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly slug: {
                                    readonly type: 'string';
                                };
                                readonly hide: {
                                    readonly type: 'boolean';
                                };
                                readonly includes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["type"];
                                        readonly properties: {
                                            readonly type: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly excludes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["key"];
                                        readonly properties: {
                                            readonly key: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly filters: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["property", "title"];
                                        readonly properties: {
                                            readonly property: {
                                                readonly type: 'string';
                                            };
                                            readonly hide: {
                                                readonly type: 'boolean';
                                            };
                                            readonly label: {
                                                readonly type: 'string';
                                            };
                                            readonly options: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly type: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["select", "checkboxes", "date-range"];
                                            };
                                            readonly title: {
                                                readonly type: 'string';
                                            };
                                            readonly titleTranslationKey: {
                                                readonly type: 'string';
                                            };
                                            readonly parentFilter: {
                                                readonly type: 'string';
                                            };
                                            readonly valuesMapping: {
                                                readonly type: 'object';
                                                readonly additionalProperties: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly titleTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly descriptionTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly catalogSwitcherLabelTranslationKey: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProperties: false;
                        };
                        readonly dataSchemas: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly slug: {
                                    readonly type: 'string';
                                };
                                readonly hide: {
                                    readonly type: 'boolean';
                                };
                                readonly includes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["type"];
                                        readonly properties: {
                                            readonly type: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly excludes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["key"];
                                        readonly properties: {
                                            readonly key: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly filters: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["property", "title"];
                                        readonly properties: {
                                            readonly property: {
                                                readonly type: 'string';
                                            };
                                            readonly hide: {
                                                readonly type: 'boolean';
                                            };
                                            readonly label: {
                                                readonly type: 'string';
                                            };
                                            readonly options: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly type: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["select", "checkboxes", "date-range"];
                                            };
                                            readonly title: {
                                                readonly type: 'string';
                                            };
                                            readonly titleTranslationKey: {
                                                readonly type: 'string';
                                            };
                                            readonly parentFilter: {
                                                readonly type: 'string';
                                            };
                                            readonly valuesMapping: {
                                                readonly type: 'object';
                                                readonly additionalProperties: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly titleTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly descriptionTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly catalogSwitcherLabelTranslationKey: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProperties: false;
                        };
                        readonly apiOperations: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly slug: {
                                    readonly type: 'string';
                                };
                                readonly hide: {
                                    readonly type: 'boolean';
                                };
                                readonly includes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["type"];
                                        readonly properties: {
                                            readonly type: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly excludes: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["key"];
                                        readonly properties: {
                                            readonly key: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly filters: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'object';
                                        readonly required: readonly ["property", "title"];
                                        readonly properties: {
                                            readonly property: {
                                                readonly type: 'string';
                                            };
                                            readonly hide: {
                                                readonly type: 'boolean';
                                            };
                                            readonly label: {
                                                readonly type: 'string';
                                            };
                                            readonly options: {
                                                readonly type: 'array';
                                                readonly items: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly type: {
                                                readonly type: 'string';
                                                readonly enum: readonly ["select", "checkboxes", "date-range"];
                                            };
                                            readonly title: {
                                                readonly type: 'string';
                                            };
                                            readonly titleTranslationKey: {
                                                readonly type: 'string';
                                            };
                                            readonly parentFilter: {
                                                readonly type: 'string';
                                            };
                                            readonly valuesMapping: {
                                                readonly type: 'object';
                                                readonly additionalProperties: {
                                                    readonly type: 'string';
                                                };
                                            };
                                        };
                                        readonly additionalProperties: false;
                                    };
                                };
                                readonly titleTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly descriptionTranslationKey: {
                                    readonly type: 'string';
                                };
                                readonly catalogSwitcherLabelTranslationKey: {
                                    readonly type: 'string';
                                };
                            };
                            readonly additionalProperties: false;
                        };
                    };
                    readonly additionalProperties: {
                        readonly type: 'object';
                        readonly properties: {
                            readonly slug: {
                                readonly type: 'string';
                            };
                            readonly hide: {
                                readonly type: 'boolean';
                            };
                            readonly includes: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'object';
                                    readonly required: readonly ["type"];
                                    readonly properties: {
                                        readonly type: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                            };
                            readonly excludes: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'object';
                                    readonly required: readonly ["key"];
                                    readonly properties: {
                                        readonly key: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                            };
                            readonly filters: {
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'object';
                                    readonly required: readonly ["property", "title"];
                                    readonly properties: {
                                        readonly property: {
                                            readonly type: 'string';
                                        };
                                        readonly hide: {
                                            readonly type: 'boolean';
                                        };
                                        readonly label: {
                                            readonly type: 'string';
                                        };
                                        readonly options: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                        readonly type: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["select", "checkboxes", "date-range"];
                                        };
                                        readonly title: {
                                            readonly type: 'string';
                                        };
                                        readonly titleTranslationKey: {
                                            readonly type: 'string';
                                        };
                                        readonly parentFilter: {
                                            readonly type: 'string';
                                        };
                                        readonly valuesMapping: {
                                            readonly type: 'object';
                                            readonly additionalProperties: {
                                                readonly type: 'string';
                                            };
                                        };
                                    };
                                    readonly additionalProperties: false;
                                };
                            };
                            readonly titleTranslationKey: {
                                readonly type: 'string';
                            };
                            readonly descriptionTranslationKey: {
                                readonly type: 'string';
                            };
                            readonly catalogSwitcherLabelTranslationKey: {
                                readonly type: 'string';
                            };
                        };
                        readonly additionalProperties: false;
                    };
                };
            };
            readonly additionalProperties: false;
        };
        readonly catalogClassic: {
            readonly type: 'object';
            readonly patternProperties: {
                readonly '.*': {
                    readonly type: 'object';
                    readonly additionalProperties: true;
                    readonly required: readonly ["slug", "items"];
                    readonly properties: {
                        readonly show: {
                            readonly type: 'boolean';
                        };
                        readonly slug: {
                            readonly type: 'string';
                        };
                        readonly filters: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'object';
                                readonly additionalProperties: false;
                                readonly required: readonly ["title", "property"];
                                readonly properties: {
                                    readonly type: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["select", "checkboxes", "date-range"];
                                    };
                                    readonly title: {
                                        readonly type: 'string';
                                    };
                                    readonly titleTranslationKey: {
                                        readonly type: 'string';
                                    };
                                    readonly property: {
                                        readonly type: 'string';
                                    };
                                    readonly parentFilter: {
                                        readonly type: 'string';
                                    };
                                    readonly valuesMapping: {
                                        readonly type: 'object';
                                        readonly additionalProperties: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly missingCategoryName: {
                                        readonly type: 'string';
                                    };
                                    readonly missingCategoryNameTranslationKey: {
                                        readonly type: 'string';
                                    };
                                    readonly options: {
                                        readonly type: 'array';
                                        readonly items: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                            };
                        };
                        readonly groupByFirstFilter: {
                            readonly type: 'boolean';
                        };
                        readonly filterValuesCasing: {
                            readonly type: 'string';
                            readonly enum: readonly ["sentence", "original", "lowercase", "uppercase"];
                        };
                        readonly items: {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'object';
                                readonly properties: {
                                    readonly page: {
                                        readonly type: 'string';
                                        readonly format: 'uri-reference';
                                        readonly uiHint: 'file';
                                    };
                                    readonly directory: {
                                        readonly type: 'string';
                                        readonly format: 'uri-reference';
                                        readonly uiHint: 'file';
                                    };
                                    readonly disconnect: {
                                        readonly type: 'boolean';
                                    };
                                    readonly group: {
                                        readonly type: 'string';
                                    };
                                    readonly label: {
                                        readonly type: 'string';
                                    };
                                    readonly href: {
                                        readonly type: 'string';
                                    };
                                    readonly external: {
                                        readonly type: 'boolean';
                                    };
                                    readonly labelTranslationKey: {
                                        readonly type: 'string';
                                    };
                                    readonly groupTranslationKey: {
                                        readonly type: 'string';
                                    };
                                    readonly icon: {
                                        readonly oneOf: readonly [{
                                            readonly type: 'string';
                                        }, {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly srcSet: {
                                                    readonly type: 'string';
                                                };
                                            };
                                            readonly required: readonly ["srcSet"];
                                        }];
                                    };
                                    readonly separator: {
                                        readonly type: 'string';
                                    };
                                    readonly separatorLine: {
                                        readonly type: 'boolean';
                                    };
                                    readonly linePosition: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["top", "bottom"];
                                    };
                                    readonly version: {
                                        readonly type: 'string';
                                    };
                                    readonly menuStyle: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["drilldown"];
                                    };
                                    readonly expanded: {
                                        readonly type: 'string';
                                        readonly const: 'always';
                                    };
                                    readonly selectFirstItemOnExpand: {
                                        readonly type: 'boolean';
                                    };
                                    readonly flatten: {
                                        readonly type: 'boolean';
                                    };
                                    readonly includeByMetadata: {
                                        readonly type: 'object';
                                        readonly additionalProperties: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'string';
                                            };
                                        };
                                    };
                                    readonly linkedSidebars: {
                                        readonly type: 'array';
                                        readonly items: {
                                            readonly type: 'string';
                                            readonly format: 'uri-reference';
                                        };
                                    };
                                    readonly rbac: {
                                        readonly type: 'object';
                                        readonly additionalProperties: {
                                            readonly type: 'string';
                                        };
                                    };
                                    readonly additionalProps: {
                                        readonly type: 'object';
                                        readonly additionalProperties: true;
                                    };
                                    readonly items: {
                                        readonly type: 'array';
                                        readonly items: {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly page: {
                                                    readonly type: 'string';
                                                    readonly format: 'uri-reference';
                                                    readonly uiHint: 'file';
                                                };
                                                readonly directory: {
                                                    readonly type: 'string';
                                                    readonly format: 'uri-reference';
                                                    readonly uiHint: 'file';
                                                };
                                                readonly disconnect: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly group: {
                                                    readonly type: 'string';
                                                };
                                                readonly label: {
                                                    readonly type: 'string';
                                                };
                                                readonly href: {
                                                    readonly type: 'string';
                                                };
                                                readonly external: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly labelTranslationKey: {
                                                    readonly type: 'string';
                                                };
                                                readonly groupTranslationKey: {
                                                    readonly type: 'string';
                                                };
                                                readonly icon: {
                                                    readonly oneOf: readonly [{
                                                        readonly type: 'string';
                                                    }, {
                                                        readonly type: 'object';
                                                        readonly properties: {
                                                            readonly srcSet: {
                                                                readonly type: 'string';
                                                            };
                                                        };
                                                        readonly required: readonly ["srcSet"];
                                                    }];
                                                };
                                                readonly separator: {
                                                    readonly type: 'string';
                                                };
                                                readonly separatorLine: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly linePosition: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["top", "bottom"];
                                                };
                                                readonly version: {
                                                    readonly type: 'string';
                                                };
                                                readonly menuStyle: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["drilldown"];
                                                };
                                                readonly expanded: {
                                                    readonly type: 'string';
                                                    readonly const: 'always';
                                                };
                                                readonly selectFirstItemOnExpand: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly flatten: {
                                                    readonly type: 'boolean';
                                                };
                                                readonly includeByMetadata: {
                                                    readonly type: 'object';
                                                    readonly additionalProperties: {
                                                        readonly type: 'array';
                                                        readonly items: {
                                                            readonly type: 'string';
                                                        };
                                                    };
                                                };
                                                readonly linkedSidebars: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'string';
                                                        readonly format: 'uri-reference';
                                                    };
                                                };
                                                readonly items: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'object';
                                                        readonly additionalProperties: true;
                                                    };
                                                };
                                                readonly rbac: {
                                                    readonly type: 'object';
                                                    readonly additionalProperties: {
                                                        readonly type: 'string';
                                                    };
                                                };
                                                readonly additionalProps: {
                                                    readonly type: 'object';
                                                    readonly additionalProperties: true;
                                                };
                                            };
                                        };
                                    };
                                };
                            };
                        };
                        readonly requiredPermission: {
                            readonly type: 'string';
                        };
                        readonly separateVersions: {
                            readonly type: 'boolean';
                        };
                        readonly title: {
                            readonly type: 'string';
                        };
                        readonly titleTranslationKey: {
                            readonly type: 'string';
                        };
                        readonly description: {
                            readonly type: 'string';
                        };
                        readonly descriptionTranslationKey: {
                            readonly type: 'string';
                        };
                    };
                };
            };
        };
        /**
         * @deprecated Should use `scorecardClassic` instead
         */
        readonly scorecard: {
            readonly nodeTypeName: "ScorecardClassic";
            readonly description: 'Add and create sets of rules and test your API description files against them. With these rules you can maintain quality across your existing APIs and ensure that newly-added or updated APIs match your criteria. An API scorecard can include multiple sets of rules, corresponding to different quality levels.';
            readonly documentationLink: 'https://redocly.com/docs/realm/config/scorecard-classic';
            readonly type: 'object';
            readonly additionalProperties: true;
            readonly required: readonly [];
            readonly properties: {
                readonly ignoreNonCompliant: {
                    readonly type: 'boolean';
                };
                readonly teamMetadataProperty: {
                    readonly nodeTypeName: "ScorecardClassicTeamMetadataProperty";
                    readonly description: 'Provide custom team label and team metadata property.';
                    readonly documentationLink: 'https://redocly.com/docs/realm/config/scorecard-classic#team-metadata-object';
                    readonly type: 'object';
                    readonly properties: {
                        readonly property: {
                            readonly type: 'string';
                        };
                        readonly label: {
                            readonly type: 'string';
                        };
                        readonly default: {
                            readonly type: 'string';
                        };
                    };
                };
                readonly levels: {
                    readonly nodeTypeName: "ScorecardClassicLevelList";
                    readonly description: 'List of levels to score against.';
                    readonly type: 'array';
                    readonly items: {
                        readonly nodeTypeName: "ScorecardClassicLevel";
                        readonly documentationLink: 'https://redocly.com/docs/realm/config/scorecard-classic#level-object';
                        readonly type: 'object';
                        readonly required: readonly ["name"];
                        readonly properties: {
                            readonly rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly oas2Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly oas3_0Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly oas3_1Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly oas3_2Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly async2Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly async3Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly arazzo1Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly arazzo1_1Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly overlay1Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly openrpc1Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly graphqlRules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas2Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas3_0Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas3_1Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas3_2Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly async2Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly async3Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly arazzo1Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly arazzo1_1Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly overlay1Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly openrpc1Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas2Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas3_0Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas3_1Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas3_2Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly async2Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly async3Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly arazzo1Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly arazzo1_1Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly overlay1Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly openrpc1Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly extends: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'string';
                                };
                                readonly description: 'Use extends to inherit rules and their configurations from other rulesets.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/extends';
                            };
                            readonly name: {
                                readonly type: 'string';
                            };
                            readonly color: {
                                readonly type: 'string';
                            };
                        };
                        readonly additionalProperties: false;
                    };
                };
                readonly targets: {
                    readonly nodeTypeName: "ScorecardClassicTargetList";
                    readonly description: 'Provide custom `minimumLevel` for specific targets.';
                    readonly type: 'array';
                    readonly items: {
                        readonly nodeTypeName: "ScorecardClassicTarget";
                        readonly type: 'object';
                        readonly required: readonly ["where"];
                        readonly properties: {
                            readonly minimumLevel: {
                                readonly type: 'string';
                            };
                            readonly rules: {
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly where: {
                                readonly nodeTypeName: "ScorecardClassicTargetWhere";
                                readonly description: 'Specify which API descriptions to apply the `minimumLevel` to based on the metadata.';
                                readonly documentationLink: 'https://redocly.com/docs/realm/config/scorecard-classic#where-object';
                                readonly type: 'object';
                                readonly required: readonly ["metadata"];
                                readonly properties: {
                                    readonly metadata: {
                                        readonly nodeTypeName: "ScorecardClassicTargetWhereMetadata";
                                        readonly type: 'object';
                                        readonly additionalProperties: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly additionalProperties: false;
                            };
                        };
                        readonly additionalProperties: false;
                    };
                };
                readonly ignore: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                        readonly format: 'glob';
                        readonly uiHint: 'file';
                    };
                };
                readonly fromProjectUrl: {
                    readonly type: 'string';
                    readonly format: 'uri';
                };
            };
        };
        readonly scorecardClassic: {
            readonly nodeTypeName: "ScorecardClassic";
            readonly description: 'Add and create sets of rules and test your API description files against them. With these rules you can maintain quality across your existing APIs and ensure that newly-added or updated APIs match your criteria. An API scorecard can include multiple sets of rules, corresponding to different quality levels.';
            readonly documentationLink: 'https://redocly.com/docs/realm/config/scorecard-classic';
            readonly type: 'object';
            readonly additionalProperties: true;
            readonly required: readonly [];
            readonly properties: {
                readonly ignoreNonCompliant: {
                    readonly type: 'boolean';
                };
                readonly teamMetadataProperty: {
                    readonly nodeTypeName: "ScorecardClassicTeamMetadataProperty";
                    readonly description: 'Provide custom team label and team metadata property.';
                    readonly documentationLink: 'https://redocly.com/docs/realm/config/scorecard-classic#team-metadata-object';
                    readonly type: 'object';
                    readonly properties: {
                        readonly property: {
                            readonly type: 'string';
                        };
                        readonly label: {
                            readonly type: 'string';
                        };
                        readonly default: {
                            readonly type: 'string';
                        };
                    };
                };
                readonly levels: {
                    readonly nodeTypeName: "ScorecardClassicLevelList";
                    readonly description: 'List of levels to score against.';
                    readonly type: 'array';
                    readonly items: {
                        readonly nodeTypeName: "ScorecardClassicLevel";
                        readonly documentationLink: 'https://redocly.com/docs/realm/config/scorecard-classic#level-object';
                        readonly type: 'object';
                        readonly required: readonly ["name"];
                        readonly properties: {
                            readonly rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly oas2Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly oas3_0Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly oas3_1Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly oas3_2Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly async2Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly async3Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly arazzo1Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly arazzo1_1Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly overlay1Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly openrpc1Rules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly graphqlRules: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: {
                                    readonly oneOf: readonly [{
                                        readonly type: 'string';
                                    }, {
                                        readonly type: 'object';
                                    }];
                                };
                                readonly description: 'The rules configuration blocks set up linting rules and their severity. You can configure built-in rules, add configurable rules, and rules from plugins.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/rules#rules';
                            };
                            readonly preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas2Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas3_0Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas3_1Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas3_2Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly async2Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly async3Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly arazzo1Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly arazzo1_1Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly overlay1Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly openrpc1Preprocessors: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas2Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas3_0Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas3_1Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly oas3_2Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly async2Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly async3Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly arazzo1Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly arazzo1_1Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly overlay1Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly openrpc1Decorators: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly extends: {
                                readonly nodeTypeName: undefined;
                                readonly type: 'array';
                                readonly items: {
                                    readonly type: 'string';
                                };
                                readonly description: 'Use extends to inherit rules and their configurations from other rulesets.';
                                readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/extends';
                            };
                            readonly name: {
                                readonly type: 'string';
                            };
                            readonly color: {
                                readonly type: 'string';
                            };
                        };
                        readonly additionalProperties: false;
                    };
                };
                readonly targets: {
                    readonly nodeTypeName: "ScorecardClassicTargetList";
                    readonly description: 'Provide custom `minimumLevel` for specific targets.';
                    readonly type: 'array';
                    readonly items: {
                        readonly nodeTypeName: "ScorecardClassicTarget";
                        readonly type: 'object';
                        readonly required: readonly ["where"];
                        readonly properties: {
                            readonly minimumLevel: {
                                readonly type: 'string';
                            };
                            readonly rules: {
                                readonly type: 'object';
                                readonly additionalProperties: true;
                            };
                            readonly where: {
                                readonly nodeTypeName: "ScorecardClassicTargetWhere";
                                readonly description: 'Specify which API descriptions to apply the `minimumLevel` to based on the metadata.';
                                readonly documentationLink: 'https://redocly.com/docs/realm/config/scorecard-classic#where-object';
                                readonly type: 'object';
                                readonly required: readonly ["metadata"];
                                readonly properties: {
                                    readonly metadata: {
                                        readonly nodeTypeName: "ScorecardClassicTargetWhereMetadata";
                                        readonly type: 'object';
                                        readonly additionalProperties: {
                                            readonly type: 'string';
                                        };
                                    };
                                };
                                readonly additionalProperties: false;
                            };
                        };
                        readonly additionalProperties: false;
                    };
                };
                readonly ignore: {
                    readonly type: 'array';
                    readonly items: {
                        readonly type: 'string';
                        readonly format: 'glob';
                        readonly uiHint: 'file';
                    };
                };
                readonly fromProjectUrl: {
                    readonly type: 'string';
                    readonly format: 'uri';
                };
            };
        };
        readonly scorecards: {
            readonly type: 'array';
            readonly items: {
                readonly type: 'object';
                readonly properties: {
                    readonly name: {
                        readonly type: 'string';
                    };
                    readonly key: {
                        readonly type: 'string';
                    };
                    readonly description: {
                        readonly type: 'string';
                    };
                    readonly entities: {
                        readonly oneOf: readonly [{
                            readonly type: 'array';
                            readonly items: {
                                readonly oneOf: readonly [{
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly field: {
                                            readonly type: 'string';
                                        };
                                        readonly operator: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                        };
                                        readonly value: {
                                            readonly oneOf: readonly [{
                                                readonly type: 'boolean';
                                            }, {
                                                readonly type: 'string';
                                            }, {
                                                readonly type: 'number';
                                            }];
                                        };
                                        readonly modifier: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["not"];
                                        };
                                        readonly match: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly type: 'object';
                                                readonly properties: {
                                                    readonly field: {
                                                        readonly type: 'string';
                                                    };
                                                    readonly operator: {
                                                        readonly type: 'string';
                                                        readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                    };
                                                    readonly value: {
                                                        readonly oneOf: readonly [{
                                                            readonly type: 'boolean';
                                                        }, {
                                                            readonly type: 'string';
                                                        }, {
                                                            readonly type: 'number';
                                                        }];
                                                    };
                                                    readonly modifier: {
                                                        readonly type: 'string';
                                                        readonly enum: readonly ["not"];
                                                    };
                                                };
                                            };
                                        };
                                    };
                                }, {
                                    readonly type: 'object';
                                    readonly properties: {
                                        readonly operator: {
                                            readonly type: 'string';
                                            readonly enum: readonly ["and", "or"];
                                        };
                                        readonly conditions: {
                                            readonly type: 'array';
                                            readonly items: {
                                                readonly oneOf: readonly [{
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly field: {
                                                            readonly type: 'string';
                                                        };
                                                        readonly operator: {
                                                            readonly type: 'string';
                                                            readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                        };
                                                        readonly value: {
                                                            readonly oneOf: readonly [{
                                                                readonly type: 'boolean';
                                                            }, {
                                                                readonly type: 'string';
                                                            }, {
                                                                readonly type: 'number';
                                                            }];
                                                        };
                                                        readonly modifier: {
                                                            readonly type: 'string';
                                                            readonly enum: readonly ["not"];
                                                        };
                                                        readonly match: {
                                                            readonly type: 'array';
                                                            readonly items: {
                                                                readonly type: 'object';
                                                                readonly properties: {
                                                                    readonly field: {
                                                                        readonly type: 'string';
                                                                    };
                                                                    readonly operator: {
                                                                        readonly type: 'string';
                                                                        readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                    };
                                                                    readonly value: {
                                                                        readonly oneOf: readonly [{
                                                                            readonly type: 'boolean';
                                                                        }, {
                                                                            readonly type: 'string';
                                                                        }, {
                                                                            readonly type: 'number';
                                                                        }];
                                                                    };
                                                                    readonly modifier: {
                                                                        readonly type: 'string';
                                                                        readonly enum: readonly ["not"];
                                                                    };
                                                                };
                                                            };
                                                        };
                                                    };
                                                }, {
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly operator: {
                                                            readonly type: 'string';
                                                            readonly enum: readonly ["and", "or"];
                                                        };
                                                        readonly conditions: {
                                                            readonly type: 'array';
                                                            readonly items: {
                                                                readonly type: 'object';
                                                                readonly properties: {
                                                                    readonly field: {
                                                                        readonly type: 'string';
                                                                    };
                                                                    readonly operator: {
                                                                        readonly type: 'string';
                                                                        readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                    };
                                                                    readonly value: {
                                                                        readonly oneOf: readonly [{
                                                                            readonly type: 'boolean';
                                                                        }, {
                                                                            readonly type: 'string';
                                                                        }, {
                                                                            readonly type: 'number';
                                                                        }];
                                                                    };
                                                                    readonly modifier: {
                                                                        readonly type: 'string';
                                                                        readonly enum: readonly ["not"];
                                                                    };
                                                                    readonly match: {
                                                                        readonly type: 'array';
                                                                        readonly items: {
                                                                            readonly type: 'object';
                                                                            readonly properties: {
                                                                                readonly field: {
                                                                                    readonly type: 'string';
                                                                                };
                                                                                readonly operator: {
                                                                                    readonly type: 'string';
                                                                                    readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                                };
                                                                                readonly value: {
                                                                                    readonly oneOf: readonly [{
                                                                                        readonly type: 'boolean';
                                                                                    }, {
                                                                                        readonly type: 'string';
                                                                                    }, {
                                                                                        readonly type: 'number';
                                                                                    }];
                                                                                };
                                                                                readonly modifier: {
                                                                                    readonly type: 'string';
                                                                                    readonly enum: readonly ["not"];
                                                                                };
                                                                            };
                                                                        };
                                                                    };
                                                                };
                                                            };
                                                        };
                                                    };
                                                    readonly required: readonly ["operator", "conditions"];
                                                    readonly additionalProperties: false;
                                                }];
                                            };
                                        };
                                    };
                                    readonly required: readonly ["operator", "conditions"];
                                    readonly additionalProperties: false;
                                }];
                            };
                        }, {
                            readonly type: 'object';
                            readonly properties: {
                                readonly operator: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["and", "or"];
                                };
                                readonly conditions: {
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly oneOf: readonly [{
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly field: {
                                                    readonly type: 'string';
                                                };
                                                readonly operator: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                };
                                                readonly value: {
                                                    readonly oneOf: readonly [{
                                                        readonly type: 'boolean';
                                                    }, {
                                                        readonly type: 'string';
                                                    }, {
                                                        readonly type: 'number';
                                                    }];
                                                };
                                                readonly modifier: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["not"];
                                                };
                                                readonly match: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'object';
                                                        readonly properties: {
                                                            readonly field: {
                                                                readonly type: 'string';
                                                            };
                                                            readonly operator: {
                                                                readonly type: 'string';
                                                                readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                            };
                                                            readonly value: {
                                                                readonly oneOf: readonly [{
                                                                    readonly type: 'boolean';
                                                                }, {
                                                                    readonly type: 'string';
                                                                }, {
                                                                    readonly type: 'number';
                                                                }];
                                                            };
                                                            readonly modifier: {
                                                                readonly type: 'string';
                                                                readonly enum: readonly ["not"];
                                                            };
                                                        };
                                                    };
                                                };
                                            };
                                        }, {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly operator: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["and", "or"];
                                                };
                                                readonly conditions: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly oneOf: readonly [{
                                                            readonly type: 'object';
                                                            readonly properties: {
                                                                readonly field: {
                                                                    readonly type: 'string';
                                                                };
                                                                readonly operator: {
                                                                    readonly type: 'string';
                                                                    readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                };
                                                                readonly value: {
                                                                    readonly oneOf: readonly [{
                                                                        readonly type: 'boolean';
                                                                    }, {
                                                                        readonly type: 'string';
                                                                    }, {
                                                                        readonly type: 'number';
                                                                    }];
                                                                };
                                                                readonly modifier: {
                                                                    readonly type: 'string';
                                                                    readonly enum: readonly ["not"];
                                                                };
                                                                readonly match: {
                                                                    readonly type: 'array';
                                                                    readonly items: {
                                                                        readonly type: 'object';
                                                                        readonly properties: {
                                                                            readonly field: {
                                                                                readonly type: 'string';
                                                                            };
                                                                            readonly operator: {
                                                                                readonly type: 'string';
                                                                                readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                            };
                                                                            readonly value: {
                                                                                readonly oneOf: readonly [{
                                                                                    readonly type: 'boolean';
                                                                                }, {
                                                                                    readonly type: 'string';
                                                                                }, {
                                                                                    readonly type: 'number';
                                                                                }];
                                                                            };
                                                                            readonly modifier: {
                                                                                readonly type: 'string';
                                                                                readonly enum: readonly ["not"];
                                                                            };
                                                                        };
                                                                    };
                                                                };
                                                            };
                                                        }, {
                                                            readonly type: 'object';
                                                            readonly properties: {
                                                                readonly operator: {
                                                                    readonly type: 'string';
                                                                    readonly enum: readonly ["and", "or"];
                                                                };
                                                                readonly conditions: {
                                                                    readonly type: 'array';
                                                                    readonly items: {
                                                                        readonly type: 'object';
                                                                        readonly properties: {
                                                                            readonly field: {
                                                                                readonly type: 'string';
                                                                            };
                                                                            readonly operator: {
                                                                                readonly type: 'string';
                                                                                readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                            };
                                                                            readonly value: {
                                                                                readonly oneOf: readonly [{
                                                                                    readonly type: 'boolean';
                                                                                }, {
                                                                                    readonly type: 'string';
                                                                                }, {
                                                                                    readonly type: 'number';
                                                                                }];
                                                                            };
                                                                            readonly modifier: {
                                                                                readonly type: 'string';
                                                                                readonly enum: readonly ["not"];
                                                                            };
                                                                            readonly match: {
                                                                                readonly type: 'array';
                                                                                readonly items: {
                                                                                    readonly type: 'object';
                                                                                    readonly properties: {
                                                                                        readonly field: {
                                                                                            readonly type: 'string';
                                                                                        };
                                                                                        readonly operator: {
                                                                                            readonly type: 'string';
                                                                                            readonly enum: readonly ["eq", "in", "gt", "gte", "lt", "lte", "contains", "startsWith", "endsWith", "exists", "isEmpty", "between", "matches", "some", "every", "none"];
                                                                                        };
                                                                                        readonly value: {
                                                                                            readonly oneOf: readonly [{
                                                                                                readonly type: 'boolean';
                                                                                            }, {
                                                                                                readonly type: 'string';
                                                                                            }, {
                                                                                                readonly type: 'number';
                                                                                            }];
                                                                                        };
                                                                                        readonly modifier: {
                                                                                            readonly type: 'string';
                                                                                            readonly enum: readonly ["not"];
                                                                                        };
                                                                                    };
                                                                                };
                                                                            };
                                                                        };
                                                                    };
                                                                };
                                                            };
                                                            readonly required: readonly ["operator", "conditions"];
                                                            readonly additionalProperties: false;
                                                        }];
                                                    };
                                                };
                                            };
                                            readonly required: readonly ["operator", "conditions"];
                                            readonly additionalProperties: false;
                                        }];
                                    };
                                };
                            };
                            readonly required: readonly ["operator", "conditions"];
                            readonly additionalProperties: false;
                        }];
                    };
                    readonly levels: {
                        readonly type: 'array';
                        readonly items: {
                            readonly type: 'object';
                            readonly properties: {
                                readonly name: {
                                    readonly type: 'string';
                                };
                                readonly extends: {
                                    readonly nodeTypeName: undefined;
                                    readonly type: 'array';
                                    readonly items: {
                                        readonly type: 'string';
                                    };
                                    readonly description: 'Use extends to inherit rules and their configurations from other rulesets.';
                                    readonly documentationLink: 'https://redocly.com/docs/cli/configuration/reference/extends';
                                };
                                readonly rules: {
                                    readonly type: 'object';
                                    readonly additionalProperties: {
                                        readonly oneOf: readonly [{
                                            readonly type: 'string';
                                        }, {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly severity: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["error", "warn", "off"];
                                                };
                                                readonly weight: {
                                                    readonly type: 'number';
                                                };
                                            };
                                            readonly additionalProperties: true;
                                        }, {
                                            readonly type: 'object';
                                            readonly properties: {
                                                readonly title: {
                                                    readonly type: 'string';
                                                };
                                                readonly subject: {
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly type: {
                                                            readonly type: 'string';
                                                            readonly enum: readonly ["Entity", "EntityMetadata", "EntityRelations", "EntityRelation"];
                                                        };
                                                        readonly property: {
                                                            readonly type: 'string';
                                                        };
                                                    };
                                                    readonly required: readonly ["type", "property"];
                                                    readonly additionalProperties: false;
                                                };
                                                readonly severity: {
                                                    readonly type: 'string';
                                                    readonly enum: readonly ["error", "warn", "off"];
                                                };
                                                readonly message: {
                                                    readonly type: 'string';
                                                };
                                                readonly assertions: {
                                                    readonly type: 'object';
                                                    readonly properties: {
                                                        readonly defined: {
                                                            readonly type: 'boolean';
                                                        };
                                                        readonly nonEmpty: {
                                                            readonly type: 'boolean';
                                                        };
                                                        readonly eq: {
                                                            readonly oneOf: readonly [{
                                                                readonly type: 'boolean';
                                                            }, {
                                                                readonly type: 'string';
                                                            }, {
                                                                readonly type: 'number';
                                                            }];
                                                        };
                                                        readonly gt: {
                                                            readonly type: 'number';
                                                        };
                                                        readonly gte: {
                                                            readonly type: 'number';
                                                        };
                                                        readonly lt: {
                                                            readonly type: 'number';
                                                        };
                                                        readonly lte: {
                                                            readonly type: 'number';
                                                        };
                                                        readonly const: {
                                                            readonly oneOf: readonly [{
                                                                readonly type: 'boolean';
                                                            }, {
                                                                readonly type: 'string';
                                                            }, {
                                                                readonly type: 'number';
                                                            }];
                                                        };
                                                    };
                                                    readonly additionalProperties: false;
                                                };
                                                readonly where: {
                                                    readonly type: 'array';
                                                    readonly items: {
                                                        readonly type: 'object';
                                                        readonly properties: {
                                                            readonly subject: {
                                                                readonly type: 'object';
                                                                readonly properties: {
                                                                    readonly type: {
                                                                        readonly type: 'string';
                                                                        readonly enum: readonly ["Entity", "EntityMetadata", "EntityRelations", "EntityRelation"];
                                                                    };
                                                                    readonly property: {
                                                                        readonly type: 'string';
                                                                    };
                                                                };
                                                                readonly required: readonly ["type", "property"];
                                                                readonly additionalProperties: false;
                                                            };
                                                            readonly assertions: {
                                                                readonly type: 'object';
                                                                readonly properties: {
                                                                    readonly defined: {
                                                                        readonly type: 'boolean';
                                                                    };
                                                                    readonly nonEmpty: {
                                                                        readonly type: 'boolean';
                                                                    };
                                                                    readonly eq: {
                                                                        readonly oneOf: readonly [{
                                                                            readonly type: 'boolean';
                                                                        }, {
                                                                            readonly type: 'string';
                                                                        }, {
                                                                            readonly type: 'number';
                                                                        }];
                                                                    };
                                                                    readonly gt: {
                                                                        readonly type: 'number';
                                                                    };
                                                                    readonly gte: {
                                                                        readonly type: 'number';
                                                                    };
                                                                    readonly lt: {
                                                                        readonly type: 'number';
                                                                    };
                                                                    readonly lte: {
                                                                        readonly type: 'number';
                                                                    };
                                                                    readonly const: {
                                                                        readonly oneOf: readonly [{
                                                                            readonly type: 'boolean';
                                                                        }, {
                                                                            readonly type: 'string';
                                                                        }, {
                                                                            readonly type: 'number';
                                                                        }];
                                                                    };
                                                                };
                                                                readonly additionalProperties: false;
                                                            };
                                                        };
                                                        readonly required: readonly ["subject", "assertions"];
                                                        readonly additionalProperties: false;
                                                    };
                                                };
                                                readonly weight: {
                                                    readonly type: 'number';
                                                };
                                            };
                                            readonly required: readonly ["subject", "assertions"];
                                            readonly additionalProperties: false;
                                        }];
                                    };
                                };
                            };
                            readonly required: readonly ["name"];
                            readonly additionalProperties: false;
                        };
                        readonly minItems: 1;
                    };
                    readonly trigger: {
                        readonly oneOf: readonly [{
                            readonly type: 'object';
                            readonly properties: {
                                readonly event: {
                                    readonly type: 'string';
                                    readonly enum: readonly ["runtime", "manual"];
                                };
                            };
                            readonly required: readonly ["event"];
                            readonly additionalProperties: false;
                        }, {
                            readonly type: 'array';
                            readonly items: {
                                readonly type: 'object';
                                readonly properties: {
                                    readonly event: {
                                        readonly type: 'string';
                                        readonly enum: readonly ["runtime", "manual"];
                                    };
                                };
                                readonly required: readonly ["event"];
                                readonly additionalProperties: false;
                            };
                        }];
                    };
                };
                readonly required: readonly ["name", "key", "entities", "levels"];
                readonly additionalProperties: false;
            };
        };
    };
    readonly additionalProperties: true;
};
